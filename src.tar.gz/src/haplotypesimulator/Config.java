
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */


package haplotypesimulator;

/**
 *
 * @author harry
 * @param code from http://www.javadb.com/loading-configuration-parameters-from-textfile-into-a-program
 * Loads configuration parameters from a textfile
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;

public class Config {

    public Properties config;

   public Config(String file) {
      config = new Properties();
      try {
         loadConfigFile(file);
      }
      catch (IOException ex) {
         ex.printStackTrace();
         return;
      }

      Integer popSize = Integer.parseInt(config.getProperty("popSize")) * Integer.parseInt(config.getProperty("ploidy"));
      config.setProperty("popSize", popSize.toString());
      return;
   }

   public Config(HashMap<String, Object> values) {
      config = new Properties();

      Iterator itr = values.keySet().iterator();
      while (itr.hasNext()) {
         String k = (String) itr.next();
         config.setProperty(k, values.get(k).toString());
      }


   }

   /**
    * @param Loads configuration parameters from a textfile
    */
   public void loadConfigFile(String filename) throws IOException {

      //Load configuration file

      //config = new Properties();

      try {

         config.load(new FileInputStream(filename));

      }
      catch (FileNotFoundException ex) {
         Scanner in = new Scanner(System.in);
	   System.out.print(filename + " not found. Enter filename including path: ");
	   filename = in.nextLine();
           loadConfigFile(filename);
         //ex.printStackTrace();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }

   }
  }
