
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */


package haplotypesimulator;

import java.util.Random;

/**
 *
 * @author harry
 */
public class RandomGenerators {

   private static Random randChrGenerator;
   private static Random randBreakCountGenerator;
   private static Random randBreakCount;

   public RandomGenerators() {
      setRandChrGenerator();
      setRandBreakCountGenerator();


   }

   //Random generators here becuase they should not be reset at each replicate
   public void setRandBreakCountGenerator() {
      randBreakCountGenerator = new Random();
   }

   public static synchronized Double getRandBreakCount() {
      return randBreakCountGenerator.nextDouble();
   }

   public void setRandChrGenerator() {
      randChrGenerator = new Random();
   }

   public static synchronized Integer getRandChr(Integer parentChroArraySize) {
      //Apparently this will return a number between 0 and popSize - 1
      //http://www.cs.geneseo.edu/~baldwin/reference/random.html
      return randChrGenerator.nextInt(parentChroArraySize);
   }
}
