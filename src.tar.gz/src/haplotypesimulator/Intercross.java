
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import dataAnalysis.DataArray;
import java.util.Properties;
import dataAnalysis.StartAnalysis;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author harry
 */
public class Intercross extends Thread {

   private Params p;
   private Properties config;
   private DataArray dArray;
   private ArrayList<Thread> analysisThreads;

   public Intercross(Properties config, Params params) {
      this.config = config;
      p = params;
   }

   /**
    * @param config
    * @param params
    * @param parentChros
    * @param childChros
    */
   public void run() {

      int generations = Integer.parseInt(config.getProperty("generations"));
      int startGeneration = Integer.parseInt(config.getProperty("startGeneration"));
      Integer numberOfThreads = Integer.parseInt(config.getProperty("numberOfThreads"));
      Integer popSize = p.getPopSize();
      //create object for array of child chromosomes
      //and populate it with first geration data
      ChildChros childChros = new ChildChros(config);
      ParentChros parentChros = new ParentChros(popSize);


      Thread[] threads;
      analysisThreads = new ArrayList<Thread>(generations);
      //Number of recombinations to be simulated in each thread
      Integer numRecomsPerThread = (int) Math.floor(popSize / numberOfThreads);
      //If popSize is not divisible by number of threads then run a final thread for those
      Integer lastNumRecomsPerThread = popSize % numberOfThreads;
      Integer statisticsInterval = Integer.parseInt(config.getProperty("statisticInterval"));
      //Have a single pool of thread and Simulation objects to reduce memory useage
      Simulator[] simulators = new Simulator[numberOfThreads + 1];
      for (int j = 0; j < numberOfThreads; j++) {
         simulators[j] = new Simulator(config, p, parentChros, childChros, numRecomsPerThread);
      }
      //Final lot of simulations
      simulators[numberOfThreads] = new Simulator(config, p, parentChros, childChros, lastNumRecomsPerThread);


      //Create first generation
      new IntercrossInput(config, p, parentChros, simulators[0]);

      for (int i = startGeneration; i <= generations; i++) {
         threads = new Thread[numberOfThreads + 1];
         //run cancellation mechanism
         if (p.getGeneration() >= generations) {
            i = generations;
            break;
         }
         else {
            p.setGeneration(i);
         }

         if (i % statisticsInterval == 0) {
            HashMap<Integer, Integer> chromosomeCounts = (HashMap<Integer, Integer>) parentChros.getChromosomeCounts().clone();
            parentChros.resetChromosomeCounts();
            analyseData(childChros, chromosomeCounts, i);
         }

         if (p.getPloidy() == 2) {
            //create an array of randomly ordered chromosome numbers so that pairs can be used as diploids
            p.setOrderedChr();
         }

         //Make child chromosomes parent chromosomes
         //swap child chromosome arrays into parent arrays
         //Assumes that the object that initiates the arrays leaves fully populated child chromosome arrays

         parentChros.setParentChrArrays(childChros.getChildChrHapArray(), childChros.getChildChrPosArray());
         //F2 has been created by IntercrossInput so needs analysis before starting main loop
         childChros.clearChildHapArray();
         childChros.clearChildPosArray();
 
         for (int j = 0; j < numberOfThreads; j++) {
            threads[j] = new Thread(new Simulator(config, p, parentChros, childChros, numRecomsPerThread));
            threads[j].start();
         }
         threads[numberOfThreads] = new Thread(new Simulator(config, p, parentChros, childChros, lastNumRecomsPerThread));
         threads[numberOfThreads].start();
         //wait for simulations to terminate

         for (int k = 0; k <= numberOfThreads; k++) {
            try {
               threads[k].join();
            }
            catch (InterruptedException ignore) {
            }
         }
      }

      //wait for analyses to terminate
      for (Thread thread : analysisThreads) {
         try {
            thread.join();
         }
         catch (InterruptedException ignore) {
         }
      }
   }

   private void analyseData(ChildChros childChros, HashMap<Integer, Integer> chromosomeCounts, int gen) {
      //Have to clone childArray for analysis becuase it is about to be deleted
       ArrayList<int[]> childPosClone = (ArrayList<int[]>) childChros.getChildChrPosArray().clone();
      ArrayList<int[]> childHapClone = (ArrayList<int[]>) childChros.getChildChrHapArray().clone();
      Thread analysis = new Thread(new StartAnalysis(p, childPosClone, childHapClone, chromosomeCounts,gen));
      analysis.start();
      analysisThreads.add(analysis);
   }
}
