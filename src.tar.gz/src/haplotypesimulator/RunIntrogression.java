/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

/**
 *
 * @author harry
 */
public class RunIntrogression extends Thread {

   protected Properties config;
   protected Params p;
   protected ArrayList<Integer> brPos;//array of breakpoint positions
   protected Integer chrLength;
   protected Integer numberOfRecombinations;
   protected ParentChros parentChros;
   protected ChildChros childChros;
   protected int[] hapArray1;
   protected int[] hapArray2;
   protected int[] posArray1;
   protected int[] posArray2;
   private Integer familySize;
   private Integer fSize;
   private Integer lastRecombinations;
   private Random rn;//random number generator that determines order of recombination of chromsomes in families
   private StringBuilder diploidPairs;
   private ArrayList<Integer> orderedChr; //list of random chromsomes pairs for use if diploid
   private Integer popSize;
   private Integer peakMarker;//position of marker used for selection
   private int[] backcrossPos;
   private int[] backcrossHap;
   private Simulator sim;
   //private int success;
   private Integer maxGen;
   private Integer flankingMarker;
   private HashMap<Integer, int[]> chroArrays;//holds current instances of hap and pos parent arrays

   public RunIntrogression(Properties config, Params params, ParentChros pC, ChildChros cC) {
      this.config = config;
      p = params;
      parentChros = pC;
      childChros = cC;
      chrLength = Integer.parseInt(config.getProperty("chrLength"));
      familySize = Integer.parseInt(config.getProperty("familySize"));
      peakMarker = Integer.parseInt(config.getProperty("peakMarker"));
      maxGen = Integer.parseInt(config.getProperty("generations"));
      flankingMarker = Integer.parseInt(config.getProperty("flankingMarker"));
      //backcross is recurrent parent
      backcrossPos = new int[2];
      backcrossHap = new int[2];
      backcrossPos[0] = 0;
      backcrossPos[1] = chrLength;
      backcrossHap[0] = p.getGeneration();
      backcrossHap[1] = p.getGeneration();
      if (familySize == null) {
         familySize = 1;
      }
      brPos = new ArrayList<Integer>();
      rn = new Random();
      popSize = p.getPopSize();
      sim = new Simulator(config, p, childChros, 0);
      chroArrays = new HashMap<Integer, int[]>(4);
   }

   @Override
   public void run() {
      diploidPairs = new StringBuilder();
      orderedChr = p.getOrderedChr();
      diploidPairs.append(orderedChr.toString() + "\n");
      fSize = familySize;
      while (childChros.getChildArraySize() < popSize) {
         //System.out.println("Current Intrgressed Chro" + p.getCurrentCountIntrogressedChros());
         recombineNextBackcrossChr();
         p.setCountIntrogressedChrosGenerated();
      }

   }

   public void recombineNextBackcrossChr() {
      Integer i = RunSimulation.ranGen.getRandChr(popSize);

      for (int k = 1; k <= fSize; k++) {
         //swap order of recombination at random since first haplotype is taken from from first chromosome specified
         Double rand = rn.nextDouble();
         if (rand < 0.5) {
            //The first is the array of positions the second is the array of haplotypes
            //parentChros carries donor allele being introgressed
            //backcrossPos carries recurrent parent
            chroArrays.put(0, parentChros.getChrPosArray(i));
            chroArrays.put(1, parentChros.getChrHapArray(i));

            chroArrays.put(2, backcrossPos);
            chroArrays.put(3, backcrossHap);

         }
         else {
            //The first is the array of positions the second is the array of haplotypes
            chroArrays.put(0, backcrossPos);
            chroArrays.put(1, backcrossHap);

            chroArrays.put(2, parentChros.getChrPosArray(i));
            chroArrays.put(3, parentChros.getChrHapArray(i));

         }
         HashMap<Integer, int[]> childArrays = sim.recombine(chroArrays);

         //check if child array contains marker position
         //childArrays.get(0) returns positions
         //childArrays.get(1) returns haplotypes
         //childArrays.get(0)[0] always = 0 at start of chromosome

         //find position of frist break after peak marker
         int j = 0;
         while (childArrays.get(0)[j] < peakMarker) {
            j++;
         }
         //introgressed (donor) haplotype is always 0;
         // checks if next non-zero haplotype position starts between peak marker and flanking marker
         //does not actually check haplotye at flanking marker position
         // flanking marker is negative marker and chromsomes carrying it will be excluded
 /*        if (childArrays.get(1)[j - 1] != 0) {
            childChros.addChildChros(childArrays.get(0), childArrays.get(1));
            p.setCountIntrogressedChros();
         }

*/
         if (childArrays.get(1)[j - 1] == 0) {

            if (p.getGeneration() < 3) {
               if (childArrays.get(0)[j - 1] > peakMarker - flankingMarker ||
                     childArrays.get(0)[j] < peakMarker + flankingMarker) {
                  childChros.addChildChros(childArrays.get(0), childArrays.get(1));
                  p.setCountIntrogressedChros();
               }
            }
            else if (childArrays.get(0)[j - 1] >= peakMarker - flankingMarker &&
                  childArrays.get(0)[j] <= peakMarker + flankingMarker) {
               childChros.addChildChros(childArrays.get(0), childArrays.get(1));
               p.setCountIntrogressedChros();
            }
         }

         /* if (p.getMaxGeneration().intValue() == p.getMaxGeneration()) {
         printHaplotypes(chroArrays.get(0), chroArrays.get(1));
         printHaplotypes(chroArrays.get(2), chroArrays.get(3));
         printHaplotypes(childArrays.get(0), childArrays.get(1));
         System.out.println(" ");
         }*/

      }
   }

   //not used retained for debugging
   private void printHaplotypes(int[] posArray, int[] hapArray) {
      StringBuilder posString = new StringBuilder();
      int prePos = -1;
      for (int j = 0; j < posArray.length; j++) {
         int pos = posArray[j];
         int hap = hapArray[j];
         if (pos > prePos) {
            prePos = pos;
            posString.append(pos + ":" + hap + ", ");
         }
      }
      System.out.println("Chr; " + posString.toString());

   }
}
