
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import dataAnalysis.DataArray;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 *
 * @author harry
 * code from http://www.javadb.com/loading-configuration-parameters-from-textfile-into-a-program
 */
public class Params {

   private int generation; //Current generation
   private Integer maxGeneration;//total number of generations to simulate
   private HashMap<Integer, Float> breakDistribution; //distribution of 0, 1, 2, 3 breaks
   private Double breakFrequency; //mean number of breaks per generation obtained from breakDistirbution
   //private int popSize;//imported from config and chnaged to maximum even number <= value in config file
   private Double breakTotal; //sum of values of breakDistributions for use in calculating relative numbers of breaks
   private Properties config; //Config parameters from GUI or file
   private final DataArray dataArray; //Used to hold results of simulation
   private Integer popSize;
   private ArrayList<int[]> childArray;
   private long startTime;
   private ChildChros childChros;
   private Integer replicateCount; //number of replicate simulations to run for given set of condiitons
   private Integer currentReplicate; //number of curent replicate between 1 and replicateCount
   private ParentChros parentChros;
   private ArrayList<Integer> orderedChr;//randomly ordered list of chromosome numbers
   private Random rn;//random generator for sorting chromosomes for random access to orderedChr
   private HashMap<Double, Integer> randomNumbers;//random ordering for diploid pairs
   private TreeMap<Double, Integer> sortedMap;////ordered list of random pairs
   private Integer ploidy;
   private String modelName;
   private HashMap<Integer, ArrayList<Integer>> countIntrogressedChros;//used by introgression
   private HashMap<Integer, ArrayList<Integer>> countIntrogressedChrosGenerated;//number of attempts to create introgressed chromosomes

   public Params(DataArray darray, Properties config) {
      this.dataArray = darray;
      this.config = config;
      startTime = System.currentTimeMillis();
      setPopSize();
      replicateCount = Integer.parseInt(config.getProperty("replicateCount"));
      //System.out.println("Construcotor Replicate Count" + replicateCount);
      setBreakDistribution(config.getProperty("breakDistribution"));
      setBreakFrequency();
      popSize = Integer.parseInt(config.getProperty("popSize"));
      this.ploidy = Integer.parseInt(config.getProperty("ploidy"));
      maxGeneration = Integer.parseInt(config.getProperty("generations"));
      rn = new Random();//random generator for sorting chromosomes for random access
      orderedChr = new ArrayList<Integer>(popSize);
      randomNumbers = new HashMap<Double, Integer>(popSize);
      sortedMap = new TreeMap();
      countIntrogressedChros = initialiseHashMap();
      countIntrogressedChrosGenerated = initialiseHashMap();
      setCurrentReplicate(0);
   }

   public void initialise(int replicate) {
      setPopSize();
      setGeneration(Integer.parseInt(config.getProperty("startGeneration")));
      setCurrentReplicate(replicate);
      //countIntrogressedChros = 0;
   }

   private HashMap<Integer, ArrayList<Integer>> initialiseHashMap() {
      HashMap<Integer, ArrayList<Integer>> hm = new HashMap<Integer, ArrayList<Integer>>(replicateCount);
      for (int i = 0; i <= replicateCount; i++) {
         ArrayList<Integer> al = new ArrayList<Integer>(maxGeneration +1);
         for (int j = 0; j <= maxGeneration; j++) {
            al.add(0);
         }
         hm.put(i, al);
      }
      return hm;
   }

   private void setBreakFrequency() {
      breakFrequency = 0.0;
      Double total = 0.0;//recalculate breakTotal here becuase do not know when it is initalised
      for (int i = 0; i < 4; i++) {
         total += breakDistribution.get(i);
      }
      for (int i = 0; i < 4; i++) {
         breakFrequency += ((i * breakDistribution.get(i)) / total);
      }

   }

   public Integer getMaxGeneration() {
      return maxGeneration;
   }

   public Integer getPopSize() {
      return popSize;
   }

   public Double getBreakFrequency() {
      return breakFrequency;
   }

   public Double getElapsedTime() {
      Double elapsedTime = (int) (System.currentTimeMillis() - startTime) * 0.001;
      return elapsedTime;
   }

   public Properties getConfig() {
      return config;
   }

   public void setPopSize() {
      this.popSize = Integer.parseInt(config.getProperty("popSize"));
   }

   public DataArray getDataArray() {
      return dataArray;
   }

   public ChildChros getChildChros() {
      return childChros;
   }

   public Integer getReplicateCount() {
      return replicateCount;
   }

   public Integer getCurrentReplicate() {
      return currentReplicate;
   }

   public synchronized ArrayList<Integer> getOrderedChr() {
      return orderedChr;
   }

   public Integer getPloidy() {
      return ploidy;
   }

   public String getModelName() {
      return modelName;
   }

   public HashMap<Integer, ArrayList<Integer>> getCountIntrogressedChros() {
      return countIntrogressedChros;
   }

   public Integer getCurrentCountIntrogressedChros() {
      return countIntrogressedChros.get(currentReplicate).get(generation);
   }

   public synchronized void setCountIntrogressedChros() {

      countIntrogressedChros.get(currentReplicate).set(generation,
            countIntrogressedChros.get(currentReplicate).get(generation) + 1);
   }

   /*public synchronized void resetCountIntrogressedChros() {
   countIntrogressedChros = 0;
   }*/
   public HashMap<Integer, ArrayList<Integer>> getCountIntrogressedChrosGenerated() {
      return this.countIntrogressedChrosGenerated;
   }

   public synchronized void setCountIntrogressedChrosGenerated() {

      countIntrogressedChrosGenerated.get(currentReplicate).set(generation,
            countIntrogressedChrosGenerated.get(currentReplicate).get(generation) + 1);
   }

   public void setModelName(String modelName) {
      this.modelName = modelName;
   }

   public void setPloidy(Integer ploidy) {
      this.ploidy = ploidy;
   }

   public void setOrderedChr() {
      orderedChr.clear();
      randomNumbers.clear();
      sortedMap.clear();
      for (Integer r = 0; r < popSize; r++) {
         randomNumbers.put(rn.nextDouble(), r);
      }

      sortedMap.putAll(randomNumbers);

      for (Map.Entry<Double, Integer> entry : sortedMap.entrySet()) {
         Integer value = entry.getValue();
         orderedChr.add(value);
      }
   }

   public void setCurrentReplicate(Integer currentReplicate) {
      this.currentReplicate = currentReplicate;
      //return this.currentReplicate;
   }

   public void setReplicateCount(Integer replicateCount) {
      this.replicateCount = replicateCount;
   }

   public void setChildChros(ChildChros childChros) {
      this.childChros = childChros;
   }

   public ParentChros getParentChros() {
      return parentChros;
   }

   public void setParentChros(ParentChros parentChros) {
      this.parentChros = parentChros;
   }

   /**
    *
    * @return
    */
   public int getGeneration() {
      return generation;
   }

   /**
    *
    * @param generation
    */
   public void setGeneration(int generation) {
      this.generation = generation;
   }

   /**
    *
    * @return
    */
   public HashMap getBreakDistribution() {
      return breakDistribution;
   }

   /**
    *
    * @param bD
    */
   public void setBreakDistribution(String bD) {
      breakDistribution = setIntFloatHashMap(bD);
   }

   /**
    *
    * @return
    */
   public Double getBreakTotal() {
      return breakTotal;
   }

   public ArrayList<int[]> getChildArray() {
      return childArray;
   }

   public void setChildArray(ArrayList<int[]> childArray) {
      this.childArray = childArray;
   }

   //Converts String to ArrayList
   //Input format 1,3.3,4.5,2
   /**
    *
    * @param input
    * @return
    */
   public ArrayList<Double> setDoubleArray(String input) {

      ArrayList<Double> array = new ArrayList<Double>();
      String[] temp = input.split(",");
      for (String t : temp) {
         array.add(Double.parseDouble(t));
      }
      return array;
   }

   /**
    * Converts String to ArrayList
    * Example Input format 1,3,4,2
    * @param input
    * @return
    */
   public ArrayList<Integer> setIntegerArray(String input) {
      ArrayList<Integer> array = new ArrayList<Integer>();
      String[] temp = input.split(",");
      for (String t : temp) {
         array.add(Integer.parseInt(t));
      }
      return array;
   }

   /**
    * Converts string to HashMap
    * example input format 0=>2.3,1=>1,2=>0.8
    * @param Converts string to HashMap
    * example input format 0=>2.3,1=>1,2=>0.8
    * @return
    */
   public HashMap setIntFloatHashMap(String input) {
      breakTotal = 0.0;
      HashMap<Integer, Float> hash = new HashMap<Integer, Float>();

      String[] temp = input.split(",");
      for (String t : temp) {
         String[] temp2 = t.split("=>");
         hash.put(Integer.parseInt(temp2[0]), Float.parseFloat(temp2[1]));
         breakTotal += Double.parseDouble(temp2[1]);
      }
      return hash;
   }

   public BufferedWriter getOutputFile(String filename) {
      BufferedWriter analysisFile = null;
      //Get package name
      String packageName = Params.class.getPackage().getName();
      //Get the full absolute path to the Package
      ClassLoader loader = Params.class.getClassLoader();
      URL path = loader.getResource(packageName);
      String jarPath = path.toString();
      //trim path to remove package name that is within jar file
      String jarFileName = "HaplotypeSimulatorGUI.jar";
      int endIndex = jarPath.length() - packageName.length() - 2 - jarFileName.length();
      //trim path to remove leading "jar:file:"
      String jcl = jarPath.substring(9, endIndex);

      jcl = jcl + filename;

      try {

         FileWriter fstream = new FileWriter(jcl);
         analysisFile = new BufferedWriter(fstream);

      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }
}




