
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */


package haplotypesimulator;

import java.util.ArrayList;
import java.util.Properties;

/**
 *
 * @author harry arrays
 * @param Holds arrays of arrays of parental break point positions and haplotypes
 */
public class ChildChros {

   private ArrayList<int[]> childChrPosArray;
   private ArrayList<int[]> childChrHapArray;
   private Integer popSize;

   /**
    *
    * @param config
    * initialise arrays of positions and haplotypes
    */
   public ChildChros(Properties config) {
      popSize =Integer.parseInt(config.getProperty("popSize"));
      childChrHapArray = new ArrayList<int[]>(Integer.parseInt(config.getProperty("popSize")));
      childChrPosArray = new ArrayList<int[]>(Integer.parseInt(config.getProperty("popSize")));
   }

   /**
    *
    * @param childChrPos
    */
   public synchronized void addChildChros(int[] childChrPos, int[] childChrHap) {
      this.childChrPosArray.add(childChrPos);
      this.childChrHapArray.add(childChrHap);
   }

   /**
    *
    * @param childChrHap
    */
   public synchronized void addChildChrHap(int[] childChrHap) {
      this.childChrHapArray.add(childChrHap);
   }

   public Integer getChildArraySize(){
      return childChrPosArray.size();
   }

   /**
    *
    * @return
    */
   public ArrayList<int[]> getChildChrPosArray() {
      return childChrPosArray;
   }

   public int[] getChildChrPos(Integer index) {
      return childChrPosArray.get(index);
   }

   public int[] getChildChrHap(Integer index) {
      return childChrHapArray.get(index);
   }

   /**
    *
    * @return
    */
   public ArrayList<int[]> getChildChrHapArray() {
      return childChrHapArray;
   }

   /**
    *
    */
   public void clearChildPosArray() {
      childChrPosArray.clear();
      //childChrPosArray = new ArrayList<int[]>(popSize);

   }

   /**
    *
    */
   public void clearChildHapArray() {
      childChrHapArray.clear();
      //childChrHapArray = new ArrayList<int[]>(popSize);
   }

   public int getChildSize() {
      return childChrHapArray.size();
   }
}
