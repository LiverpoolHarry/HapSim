
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import JavaClassLoader.JarClassLoader;
import java.util.Enumeration;
import java.util.Properties;
import dataAnalysis.DataArray;
import dataAnalysis.DataPrinter;
import dataAnalysis.ProgressMonitor;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.SwingUtilities;
/*import java.util.concurrent.TimeUnit;
 */

/**
 * Main.java
 *
 * @author www.javadb.com
 */
public class RunSimulation extends Thread {

   private Params p;
   private Params tempP;
   private Properties config;
   private final DataArray dArray;
   private Intercross intercross;
   private IntercrossDemo intercrossDemo;
   private ChildChros childChros;
   private ParentChros parentChros;
   public static RandomGenerators ranGen;
   private ProgressMonitor pm;
   private String currentModelName;
   private boolean useProgressMonitor = true;
   private DataPrinter printer;
   private long startTime;
   private String startDate;
   private String finishDate;
   private JarClassLoader jarLoader;
   private boolean printOutput = false;

   public RunSimulation(DataArray dA, HashMap<String, Object> values, String cModName) {
      this.dArray = dA;
      this.currentModelName = cModName;
      //Add variables from gui to config file

      Config con = new Config(values);
      config = con.config;
      Integer popSize = Integer.parseInt(config.getProperty("popSize"));

      ranGen = new RandomGenerators();
      setParams();
      pm = new ProgressMonitor(p, dArray);

   }

   public RunSimulation(String filename) {

      Config con = new Config(filename);
      config = con.config;
      currentModelName = config.getProperty("modelName");
      ranGen = new RandomGenerators();
      dArray = new DataArray(Integer.parseInt(config.getProperty("replicateCount")));
      setParams();
      useProgressMonitor = false;
      printOutput = true;
   }

   public void run() {
      if (useProgressMonitor) {
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               pm.startProgressMonitor();
            }
         });
      }
      int replicateCount = p.getReplicateCount();
      p.setCurrentReplicate(0);
      String filename = "HaplotypeSimulatorLog.txt";
      printer.setLogFile(filename);
      printer.printLog(filename, Calendar.getInstance().getTimeInMillis() - startTime, 0);

      for (int i = 1; i <= replicateCount; i++) {
         //cancelation of the run will set currentReplicate to max value
         if (p.getCurrentReplicate() <= replicateCount) {
            p.initialise(i);
            //instantiate and start chosen class
            loadModelClasses(currentModelName);
            dArray.updateMeanBreaksReplicates();
            printer.printLog(filename, Calendar.getInstance().getTimeInMillis() - startTime, i);
         }
      }

      dArray.mergeReplicates();
      finishDate = getDateTime();
      if(printOutput == true){
         printToFile(config.getProperty("filename"));
      }
   }

   public void printToFile(String filename) {
      printer.printAnalysis(startDate, finishDate, filename);
   }

   private void initialiseTime() {
      startTime = Calendar.getInstance().getTimeInMillis();
      startDate = getDateTime();
      Integer cChrGen = p.getCurrentCountIntrogressedChros();
      if(cChrGen > 0){
         cChrGen = cChrGen/(p.getReplicateCount() * Integer.parseInt(config.getProperty("generations")));
         System.out.println(cChrGen + " chromosomes were generated to get " + config.getProperty("popSize") + " introgressed chromosomes");
      }
   }

   public void disposeProgressMonitor() {
      pm.disposeWindow();
   }

   private void setParams() {
      //testConfig(config);
      //Initialise object for local variables
      p = new Params(dArray, config);
      p.setModelName(currentModelName);
      initialiseTime();
      dArray.setParams(p);
      printer = new DataPrinter(dArray, config, p);
      getJarLoader();
      //tutorials.jenkov.com/java-reflection/dynamic-class-loading-reloading.html
   }

   public void cancelSimulation() {
      p.setGeneration(Integer.parseInt(config.getProperty("generations")));
      p.setCurrentReplicate(p.getReplicateCount() + 1);
   }

   private static void testConfig(Properties p) {
      //Print out the configuration parameters
      Enumeration en = p.keys();

      System.out.println("********** System configuration **********");
      while (en.hasMoreElements()) {

         String key = (String) en.nextElement();
         System.out.println(key + " => " + p.get(key));

      }

   }

   /*loads and instance of a clas that takes config and params parameters and
    * starts it running in a thread
    */
   public void getJarLoader() {

      //Get package name
      String packageName = Params.class.getPackage().getName();

      //Get the full absolute path to the Package
      ClassLoader loader = Params.class.getClassLoader();
      URL path = loader.getResource(packageName);
      String jarPath = path.toString();
      //trim path to remove package name that is within jar file
      int endIndex = jarPath.length() - packageName.length() - 2;
      //trim path to remove leading "jar:file:"
      String pathToJarfile = jarPath.substring(9, endIndex);
      // get path including "jar:file:" and trailing "!/"
      String jp = jarPath.substring(0, endIndex + 2);
      //Instantiate the third party JarClassLoader
      //System.out.println("Path:  " + jcl);
      jarLoader = new JarClassLoader(pathToJarfile);

   }

   public void loadModelClasses(String modelName) {

      Class[] parameterTypes = new Class[2];
      parameterTypes[0] = config.getClass();
      parameterTypes[1] = p.getClass();
      Object[] classParams = new Object[]{config, p};
      modelName = "haplotypesimulator." + modelName;

      try {

         String className = modelName.replace("/", ".");
         // use third party jarLoader to get requested class (className)
         //http://www.javaworld.com/javaworld/javatips/jw-javatip70.html
         Class c = jarLoader.loadClass(className, true);

         //Get constructor for the class
         //tutorials.jenkov.com/java-reflection/dynamic-class-loading-reloading.html
         Constructor constructor = c.getConstructor(parameterTypes);

         //Instantiate the class with classParams and cast it as a Thread object
         //instantiation from tutorials.jenkov.com; casting as thread my idea
         Thread modelObject = (Thread) constructor.newInstance(classParams);

         //start thread for requested model
         modelObject.start();
         modelObject.join();

         //jarfile.close();


      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }

   private String getDateTime() {
      DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss z");
      Date date = new Date();
      return dateFormat.format(date);
   }
}
