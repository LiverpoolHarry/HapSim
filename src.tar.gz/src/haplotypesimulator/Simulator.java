
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import java.io.BufferedWriter;
import java.util.Properties;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author harry
 */
public class Simulator extends Thread {
   //Variables are protected to make them available to subclass

   protected Properties config;
   protected Params p;
   //protected Random generator;
   protected ArrayList<Integer> brPos;//array of breakpoint positions
   protected Integer hotspotInterval;
   protected Integer chrLength;
   protected Integer numberOfRecombinations;
   protected ParentChros parentChros;
   protected ChildChros childChros;
   protected int c1Start = 0;
   protected int c1End = 0;
   protected int c2Start = 0;
   protected int c2End = 0;
   protected int arraySize;
   protected int[] hapArray1;
   protected int[] hapArray2;
   protected int[] posArray1;
   protected int[] posArray2;
   protected int[] newHapArray;
   protected int[] newPosArray;
   protected int newArrayEnd;
   private Integer familySize;
   private Integer fSize;
   private Integer lastRecombinations;
   private Random rn;//random number genrator that determines order of recombination of chromsomes in families
   private Integer ploidy;//if diploid = 2 then the same pair of chromosomes will always be used together ina given generation
   private StringBuilder diploidPairs;
   private ArrayList<Integer> orderedChr; //list of random chromsomes pairs for use if diploid
   private BufferedWriter out;
   private Integer popSize;
   private int[] backcrossPos;
   private int[] backcrossHap;
   private HashMap<Integer, int[]> chroArrays;//holds current instances of hap and pos parent arrays

   /**
    *
    * @param config
    * @param params
    * @param pC
    * @param cC
    */
   public Simulator(Properties config, Params params, ParentChros pC, ChildChros cC, Integer numRecoms) {
      this.config = config;
      p = params;
      parentChros = pC;
      childChros = cC;
      this.numberOfRecombinations = numRecoms;
      initialiseVariables();
   }

   public Simulator(Properties config, Params params, ChildChros cC, Integer numRecoms) {
      this.config = config;
      p = params;
      childChros = cC;
      this.numberOfRecombinations = numRecoms;
      initialiseVariables();
   }

   private void initialiseVariables() {
      chrLength = Integer.parseInt(config.getProperty("chrLength"));
      familySize = Integer.parseInt(config.getProperty("familySize"));
      if (familySize == null) {
         familySize = 1;
      }

      numberOfRecombinations = (int) java.lang.Math.floor(numberOfRecombinations / familySize);
      lastRecombinations = numberOfRecombinations % familySize;
      brPos = new ArrayList<Integer>();
      rn = new Random();
      popSize = p.getPopSize();
      ploidy = p.getPloidy();
      chroArrays = new HashMap<Integer, int[]>(4);
      // BufferedWriter out = p.getOutputFile("ChromosomePairs.txt");

   }

   @Override
   public void run() {

      if (ploidy == 2) {
         diploidPairs = new StringBuilder();
         orderedChr = p.getOrderedChr();
         diploidPairs.append(orderedChr.toString() + "\n");
      }
      fSize = familySize;
      for (int i = 0; i < numberOfRecombinations; i++) {
         recombineNextChr();
      }
      //mop up last family if number of recombinations is not divisible by family size
      fSize = lastRecombinations;
      recombineNextChr();

   }

   public void recombineNextChr() {
      Integer i = RunSimulation.ranGen.getRandChr(popSize);
      Integer j;
      if (ploidy == 2) {
         if (i % 2 == 0) {

            j = orderedChr.get(i + 1);
            i = orderedChr.get(i);
         }
         else {
            //the even numbered chromosome can be either first or second. If it is always first it will depress break count
            j = orderedChr.get(i - 1);
            i = orderedChr.get(i);
         }
      }
      else {
         j = RunSimulation.ranGen.getRandChr(popSize);
      }

      for (int k = 1; k <= fSize; k++) {
         //swap order of recombination at random since first haplotype is taken from from first chromosome specified
         Double rand = rn.nextDouble();
         if (rand < 0.5) {
            //The first is the array of positions the second is the array of haplotypes
            chroArrays.put(0, parentChros.getChrPosArray(i));
            chroArrays.put(1, parentChros.getChrHapArray(i));

            chroArrays.put(2, parentChros.getChrPosArray(j));
            chroArrays.put(3, parentChros.getChrHapArray(j));
         }
         else {
            //The first is the array of positions the second is the array of haplotypes
            chroArrays.put(0, parentChros.getChrPosArray(j));
            chroArrays.put(1, parentChros.getChrHapArray(j));

            chroArrays.put(2, parentChros.getChrPosArray(i));
            chroArrays.put(3, parentChros.getChrHapArray(i));
         }
         HashMap<Integer, int[]> childArrays = recombine(chroArrays);
         childChros.addChildChros(childArrays.get(0), childArrays.get(1));

      }
   }

   public void recombineSpecifiedChros(int i, int j) {
      //The first is the array of positions the second is the array of haplotypes
      chroArrays.put(0, parentChros.getChrPosArray(i));
      chroArrays.put(1, parentChros.getChrHapArray(i));

      chroArrays.put(2, parentChros.getChrPosArray(j));
      chroArrays.put(3, parentChros.getChrHapArray(j));

      HashMap<Integer, int[]> childArrays = recombine(chroArrays);
      childChros.addChildChros(childArrays.get(0), childArrays.get(1));
   }

   /**
    *
    * @param i index in array parent chromosome arrays of first chromosome
    * @param j index in array parent chromosome arrays of second chromosome
    *
    */
   public HashMap<Integer, int[]> recombine(HashMap<Integer, int[]> arrays) {
      //The first is the array of positions the second is the array of haplotypes
      posArray1 = arrays.get(0);
      hapArray1 = arrays.get(1);

      //chrArrays = parentChros.getChrArrays(j);
      posArray2 = arrays.get(2);
      hapArray2 = arrays.get(3);


      //get the number of breaks for this recombination
      int breakCount = getBreakCount();
      //initialises brPos which is array of break positions
      getBreakPositions(breakCount);

      //Need to make sure that array is larger than the number of possible breaks
      //The number of breaks will be at a mximum in a large population with a large number of haplotypes
      //The expected number of breaks in such cases will be population size x recombination rate
      arraySize = (int) Math.round(p.getGeneration() * 1.5 * p.getBreakFrequency()) + 10;
      newHapArray = new int[arraySize];
      newPosArray = new int[arraySize];


      c1Start = 0;
      c1End = 0;
      c2Start = 0;
      c2End = 0;
      newArrayEnd = 0;//tracks size of array

      for (int bp = 1; bp < brPos.size(); bp++) {
         Integer breakPos = brPos.get(bp);
         //Replicate the active strand on the new chromosome  up to the crossover
         while (posArray1[c1End] < breakPos) {
            newPosArray[newArrayEnd] = posArray1[c1End];
            newHapArray[newArrayEnd] = hapArray1[c1End];
            c1End++;
            newArrayEnd++;
         }


         //Find index before crossover for inactive strand
         while (posArray2[c2End] < breakPos) {
            c2End++;
         }

         /*The conditional decides whether to include the crossover point in the
         new chromosome because the two strands are different either side of the crossover
         If neither existing crossover is the same as the new crossover then
         if haplotypes are different insert a new crossover
          */

         checkBreakPoint(breakPos, c1End, c2End);

         //Swap chromosome strands
         c1Start = c2End;
         c2Start = c1End;

         c1End = c2End;
         c2End = c2Start;

         int[] tempHapArray = hapArray1;
         hapArray1 = hapArray2;
         hapArray2 = tempHapArray;

         int[] tempPosArray = posArray1;
         posArray1 = posArray2;
         posArray2 = tempPosArray;
      }

      //Add chromosome end if it has got lost using chromosome end and
      // last haplotype which is always the same as the  penultimate haplotype
      if (newPosArray[newArrayEnd - 1] != chrLength) {
         newPosArray[newArrayEnd] = chrLength;
         newHapArray[newArrayEnd] = newHapArray[newArrayEnd - 1];
      }
      HashMap<Integer, int[]> newChildArrays = new HashMap<Integer, int[]>(2);
      newChildArrays.put(0, newPosArray);
      newChildArrays.put(1, newHapArray);
      return (newChildArrays);
      //
   }

   protected void checkBreakPoint(Integer breakPos, int cEnd1, int cEnd2) {
      if (posArray1[c1End] != breakPos) {
         if (posArray2[cEnd2] != breakPos) {
            if (hapArray1[cEnd1 - 1] != hapArray2[cEnd2 - 1]) {
   
               newPosArray[newArrayEnd] = breakPos;
               newHapArray[newArrayEnd] = hapArray2[cEnd2 - 1];
               newArrayEnd++;
             }
         }
      }
      //If crossover position is same as a previous crossover on chromosome 1
      //else if (posArray1[c1End] != int) &&
      else if (posArray1[c1End] == breakPos &&
            posArray2[cEnd2] != breakPos &&
            hapArray1[cEnd1 - 1] != hapArray2[cEnd2 - 1]) {

         newPosArray[newArrayEnd] = breakPos;
         newHapArray[newArrayEnd] = hapArray2[cEnd2 - 1];
         newArrayEnd++;

      }
      //If crossover position is same as a previous crossover on chromosome 2
      //else if (!posArray1[c1End].equals(null) &&
      else if (posArray1[c1End] != breakPos &&
            posArray2[cEnd2] == breakPos &&
            hapArray1[cEnd1 - 1] == hapArray2[cEnd2 - 1]) {
         newPosArray[newArrayEnd] = posArray2[cEnd2];
         newHapArray[newArrayEnd] = hapArray2[cEnd2];
         newArrayEnd++;
      }
      //If crossover position is same as a previous crossover on both chromosomes
      //else if (!posArray1[c1End].equals(null) &&
      else if (posArray1[c1End] == breakPos &&
            posArray2[cEnd2] == breakPos &&
            hapArray1[cEnd1 - 1] == hapArray2[cEnd2 - 1]) {
         newPosArray[newArrayEnd] = breakPos;
         newHapArray[newArrayEnd] = hapArray2[cEnd2 - 1];
         newArrayEnd++;

      }

   }

   /**
    *
    * @param get the number of breakpoints to be applied to this chromosome
    * It iterates through the hash of the distribution of break points
    * summing the values until they are more than a random number;
    */
   protected int getBreakCount() {
      Double generator = RunSimulation.ranGen.getRandBreakCount();
      //breakTotal is the sum of the values of the hash of breakDistribution
      Double breakTotal = p.getBreakTotal();
      int breakCount = 0;
      Double breakRandom = generator * breakTotal;
      HashMap<Integer, Float> breakDist = p.getBreakDistribution();

      Float breaks = breakDist.get(0);
      while (breakRandom >= breaks) {
         breakCount++;
         breaks +=
               breakDist.get(breakCount);
      }
      return breakCount;
   }

   /**
    * @param Create array of positions of break points
    */
   protected void getBreakPositions(Integer bC) {
      hotspotInterval = Integer.parseInt(config.getProperty("hotspotInterval"));
      insertBreakPositions(bC);

      //Check if any recombinations are within prohibited interference interval
      // If they are create a new set
      if (bC > 1) {
         while (minDistCheck() < Integer.parseInt(config.getProperty("minDistance"))) {
            insertBreakPositions(bC);
         }
      }
   }

   /**
    * @param Check that positions are at least the minimum interference distance apart
    */
   protected Integer minDistCheck() {
      Integer distance = 2000;
      for (int d = 2; d <
            brPos.size(); d++) {
         if (brPos.get(d) - brPos.get(d - 1) < distance) {
            distance = brPos.get(d) - brPos.get(d - 1);
         }

      }
      return distance;
   }

   /**
    * @param Enter bC (breakCount) positions into brPos array
    */
   protected void insertBreakPositions(Integer bC) {
      brPos.clear();
      brPos.add(0);
      for (Integer i = 1; i <=
            bC; i++) {
         Double nextPos = (RunSimulation.ranGen.getRandBreakCount() * chrLength - 2 * Integer.parseInt(config.getProperty("telomereLength")));
         nextPos = ((nextPos / hotspotInterval) * hotspotInterval);
         Integer nP = (int) Math.floor(nextPos);
         brPos.add(nP);
      }

      brPos.add(chrLength);
      Collections.sort(brPos);
      if (brPos.get(1) < hotspotInterval) {
         insertBreakPositions(bC);
      }

   }

   public ArrayList<Integer> getBrPos() {
      return brPos;
   }
}
