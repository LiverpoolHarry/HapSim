
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

/**
 *
 * @author harry
 * @params Create pairs of F0 chromosomes with random haplotypes
 * Then cross them to create F1s
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

/**
 *
 * @author harry
 */
public class BackcrossInput {

   private Properties config;
   private Params params;
   private Integer chrLength;
   private Simulator sim;
   private Random generator;
   private ParentChros parentChros;
   private ChildChros childChros;
   private int arraySize;
   private ArrayList<Integer> haplotypes;
   private Integer popSize;
   //private PrintWriter pw;

   /**
    * @param Build array of F1 chromosomes
    * @param config Loaded from config file
    * @param params parameters set by programme
    * @param pC array of parent chromosomes
    * @param cC array of child chromsomes
    */
   public BackcrossInput(Properties config, Params params, ParentChros pC, Simulator sim) {
      this.config = config;
      parentChros = pC;
      this.params = params;
      chrLength = Integer.parseInt(config.getProperty("chrLength"));
      popSize = Integer.parseInt(config.getProperty("popSize"));
      arraySize = 6;

 
      params.setGeneration(1);
      generator = new Random();

      //get F0 chromosomes and recombine to get F1

      for (Integer i = 0; i < popSize  *2 ; i += 2) {
         //Create F0 chromosomes and add them to parentChros array
         buildIntercrossInput(i);
         //use simulator to recombine the newly created chromosomes
         sim.recombineSpecifiedChros(i, i + 1);
      }
   }

   /**
    * @param Create F0 chromosomes
    * and add them to parentChros array
    * where they can be retrieved by simulator
    */
   public void buildIntercrossInput(int i) {
   

      //Build array of positions eg 0,100
      int[] posArray1 = new int[arraySize];
      posArray1[0] = 0;
      posArray1[1] = chrLength;
      //Build haplotype1 eg 0,0
      int[] hapArray1 = new int[arraySize];
      hapArray1[0] = 0;
      hapArray1[1] = 0;


      int[] posArray2 = new int[arraySize];
      posArray2[0] = 0;
      posArray2[1] = chrLength;
      int[] hapArray2 = new int[arraySize];
      hapArray2[0] = 1;
      hapArray2[1] = 1;

      parentChros.addChrArrays(posArray1, hapArray1);
      parentChros.addChrArrays(posArray2, hapArray2);


   }
}


