
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author harry
 * @param Holds arrays of arrays of parental break point positions and haplotypes
 */
public class ParentChros {

   private ArrayList<int[]> parentChrPosArray;
   private ArrayList<int[]> parentChrHapArray;
   //chromosome counts is used to obtain variance of number of chromosomes
   //contributed by each individual to next generation
   //variance is calculated but not currently used.
   private HashMap<Integer, Integer> chromosomeCounts;
   private int popSize;

   /**
    * @param initialise arrays of positions and haplotypes
    */
   public ParentChros(int popSize) {
      this.popSize = popSize;
      parentChrHapArray = new ArrayList<int[]>();
      parentChrPosArray = new ArrayList<int[]>();
      chromosomeCounts = new HashMap<Integer, Integer>();
      for (Integer i = 0; i <= popSize; i++) {
         chromosomeCounts.put(i, 0);
      }
   }

   private synchronized void setChromosomeCounts(Integer index) {
      if (chromosomeCounts.get(index) == null) {
         chromosomeCounts.put(index, 0);
      }
      Integer val = chromosomeCounts.get(index) + 1;
      chromosomeCounts.put(index, val);
   }

   public HashMap<Integer, Integer> getChromosomeCounts() {
      return chromosomeCounts;
   }

   public void resetChromosomeCounts() {
      chromosomeCounts.clear();
      for (Integer i = 0; i <= popSize; i++) {
         chromosomeCounts.put(i, 0);
      }
   }

   public synchronized int[] getParentChrPos(Integer index) {
      setChromosomeCounts(index);
      return parentChrPosArray.get(index);
   }

   public int[] getParentChrHap(Integer index) {
      return parentChrHapArray.get(index);
   }

   /**
    * @param parentChrArrays used to swap child chromosome haplotypes and postions into parent chromosomes
    */
   public void setParentChrArrays(ArrayList<int[]> childChrHapArray, ArrayList<int[]> childChrPosArray) {
      parentChrPosArray.clear();
      this.parentChrPosArray.addAll(childChrPosArray);
      this.parentChrHapArray.clear();
      this.parentChrHapArray.addAll(childChrHapArray);
   }

   /**
    *
    * @param parentChrHap only used for initialisation by IntercrossInput
    */
   public synchronized void addChrHapArray(int[] parentChrHap) {
      this.parentChrHapArray.add(parentChrHap);
   }

   public Integer size() {
      return parentChrPosArray.size();
   }

   /**
    *
    * @param parentChrPos only used for initialisation by IntercrossInput
    */
   public synchronized void addChrArrays(int[] parentChrPos, int[] parentChrHap) {
      this.parentChrPosArray.add(parentChrPos);
      this.parentChrHapArray.add(parentChrHap);

   }

   /**
    *
    * @param id of array to be retrieved
    * @return array of parental haplotypes
    */
   public synchronized int[] getChrPosArray(Integer id) {
      setChromosomeCounts(id);
      // if (parentChrPosArray.size() > id) {
      //try {
         return parentChrPosArray.get(id);
     /* }
      catch (IndexOutOfBoundsException iobe) {
         System.err.println(id);
         int[] emptyArray = new int[10];
         return emptyArray;
      }*/

   }

   public synchronized int[] getChrHapArray(Integer id) {
      return parentChrHapArray.get(id);
   }
}
