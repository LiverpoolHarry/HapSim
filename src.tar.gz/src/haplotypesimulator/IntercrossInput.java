
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

/**
 *
 * @author harry
 * @params Create pairs of F0 chromosomes with random haplotypes
 * Then cross them to create F1s
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

/**
 *
 * @author harry
 */
public class IntercrossInput {

   private Properties config;
   private Params params;
   private int[] founderHaplotypes;
   private Integer noOfHaplotypes;
   private Integer chrLength;
   private Simulator sim;
   private Random generator;
   private ParentChros parentChros;
   private ChildChros childChros;
   private int arraySize;
   private ArrayList<Integer> haplotypes;
   private Integer popSize;
   //private PrintWriter pw;

   /**
    * @param Build array of F1 chromosomes
    * @param config Loaded from config file
    * @param params parameters set by programme
    * @param pC array of parent chromosomes
    * @param cC array of child chromsomes
    */
   public IntercrossInput(Properties config, Params params, ParentChros pC, Simulator sim) {
      this.config = config;
      parentChros = pC;
      this.params = params;
      noOfHaplotypes = Integer.parseInt(config.getProperty("noOfHaplotypes"));
      chrLength = Integer.parseInt(config.getProperty("chrLength"));
      popSize = Integer.parseInt(config.getProperty("popSize"));
      Integer ploidy = Integer.parseInt(config.getProperty("ploidy"));
      founderHaplotypes = new int[noOfHaplotypes];
      arraySize = 6;

      //build ArrayList with haplotype numbers present in proportion to their
      //required abundance
      haplotypes = new ArrayList<Integer>(popSize + 1);
      //Haplotypes may have different frequencies
      //This will build an ordered repeating array of haplotypes at specified frequencies
      //eg for 4 haps (1,2,3,4,1,2,3,4)
      //hapCounts is hash of frequency of each haplotype
      HashMap<Integer, Integer> hapCounts = new HashMap<Integer, Integer>(noOfHaplotypes);
      for (int i = 1; i <= noOfHaplotypes; i++) {
         String hap = "hap" + i;
         hapCounts.put(i, Integer.parseInt(config.getProperty(hap)));

      }
      int k = 0;
      //System.out.println("k= " + k);
      //int target = popSize;
      while (k < popSize ) {
         //System.out.println("k= " + k + "; target = " + target);
         for (int i = 1; i <= noOfHaplotypes; i++) {
            if (hapCounts.get(i) > 0) {
               haplotypes.add(i - 1);
               k++;
               hapCounts.put(i, hapCounts.get(i) - 1);
            }
         }

      }

      for (int i = 0; i < noOfHaplotypes; i++) {
         founderHaplotypes[i] = i;
      }

      params.setGeneration(1);
      generator = new Random();

      //get F0 chromosomes and recombine to get F1

      for (Integer i = 0; i < popSize  *2 ; i += 2) {
         //Create F0 chromosomes and add them to parentChros array
         buildIntercrossInput(i);
         //use simulator to recombine the newly created chromosomes
         sim.recombineSpecifiedChros(i, i + 1);
      }
   }

   /**
    * @param Create F0 chromosomes
    * and add them to parentChros array
    * where they can be retrieved by simulator
    */
   public void buildIntercrossInput(int i) {
      Integer orderedHaplotypes = Integer.parseInt(config.getProperty("orderedHaplotypes"));
      int hap1 = 0;
      int hap2 = 1;
      if (orderedHaplotypes == 0) {
         int pos = generator.nextInt(popSize);
         hap1 = haplotypes.get(pos);
         pos = generator.nextInt(popSize);
         hap2 = haplotypes.get(pos);
      }
      else {
       
         hap1 = haplotypes.get(i % popSize );
         hap2 = haplotypes.get((i + 1) % popSize);
      }
      //founders = 0; Start from inbred lines in F0 and structure cross to ensure heterozygotes in F1
      //founders = 1; Start from outbred lines in F0 and structure cross to ensure heterozygotes in F0
      //founders = 2; Start from outbred lines in F0 and allow random assignment of haplotypes in F0

      Integer founders = Integer.parseInt(config.getProperty("founders"));
      if (founders.equals(0)) {
         while (hap1 == hap2) {
            hap2 = haplotypes.get(generator.nextInt(popSize));
         }
      }




      //Build array of positions eg 0,100
      int[] posArray1 = new int[arraySize];
      posArray1[0] = 0;
      posArray1[1] = chrLength;
      //Build haplotype1 eg 0,0
      int[] hapArray1 = new int[arraySize];
      hapArray1[0] = founderHaplotypes[hap1];
      hapArray1[1] = founderHaplotypes[hap1];


      int[] posArray2 = new int[arraySize];
      posArray2[0] = 0;
      posArray2[1] = chrLength;
      int[] hapArray2 = new int[arraySize];
      hapArray2[0] = founderHaplotypes[hap2];
      hapArray2[1] = founderHaplotypes[hap2];

      parentChros.addChrArrays(posArray1, hapArray1);
      parentChros.addChrArrays(posArray2, hapArray2);


   }
}


