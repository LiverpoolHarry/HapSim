/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

/**
 *
 * @author harry
 */
public class RunBackcross extends Thread {

   protected Properties config;
   protected Params p;
   protected ArrayList<Integer> brPos;//array of breakpoint positions
   protected Integer chrLength;
   protected Integer numberOfRecombinations;
   protected ParentChros parentChros;
   protected ChildChros childChros;
   protected int[] hapArray1;
   protected int[] hapArray2;
   protected int[] posArray1;
   protected int[] posArray2;
   private Integer familySize;
   private Integer fSize;
   private Integer lastRecombinations;
   private Random rn;//random number generator that determines order of recombination of chromsomes in families
   private StringBuilder diploidPairs;
   private ArrayList<Integer> orderedChr; //list of random chromsomes pairs for use if diploid
   private Integer popSize;
   private int[] backcrossPos;
   private int[] backcrossHap;
   private Simulator sim;
   private HashMap<Integer, int[]> chroArrays;//holds current instances of hap and pos parent arrays

   public RunBackcross(Properties config, Params params, ParentChros pC, ChildChros cC, Integer numRecoms) {
      this.config = config;
      p = params;
      parentChros = pC;
      childChros = cC;
      this.numberOfRecombinations = numRecoms;
      chrLength = Integer.parseInt(config.getProperty("chrLength"));
      familySize = Integer.parseInt(config.getProperty("familySize"));
      backcrossPos = new int[2];
      backcrossHap = new int[2];
      backcrossPos[0] = 0;
      backcrossPos[1] = chrLength;
      backcrossHap[0] = 0;
      backcrossHap[1] = 0;
      if (familySize == null) {
         familySize = 1;
      }
      numberOfRecombinations = (int) java.lang.Math.floor(numberOfRecombinations / familySize);
      lastRecombinations = numberOfRecombinations % familySize;
      brPos = new ArrayList<Integer>();
      rn = new Random();
      popSize = p.getPopSize();
      sim = new Simulator(config, p, childChros, numRecoms);
      chroArrays = new HashMap<Integer, int[]>(4);
   }

   @Override
   public void run() {
      diploidPairs = new StringBuilder();
      orderedChr = p.getOrderedChr();
      diploidPairs.append(orderedChr.toString() + "\n");
      fSize = familySize;
      for (int i = 0; i < numberOfRecombinations; i++) {
         recombineNextBackcrossChr();
      }
      //mop up last family if number of recombinations is not divisible by family size
      fSize = lastRecombinations;
      recombineNextBackcrossChr();

   }

   public void recombineNextBackcrossChr() {
      Integer i = RunSimulation.ranGen.getRandChr(popSize);
      for (int k = 1; k <= fSize; k++) {
         //swap order of recombination at random since first haplotype is taken from from first chromosome specified
         Double rand = rn.nextDouble();
         if (rand < 0.5) {
            //The first is the array of positions the second is the array of haplotypes
            chroArrays.put(0, parentChros.getChrPosArray(i));
            chroArrays.put(1, parentChros.getChrHapArray(i));

            chroArrays.put(2, backcrossPos);
            chroArrays.put(3, backcrossHap);

         }
         else {
            //The first is the array of positions the second is the array of haplotypes
            chroArrays.put(0, backcrossPos);
            chroArrays.put(1, backcrossHap);

            chroArrays.put(2, parentChros.getChrPosArray(i));
            chroArrays.put(3, parentChros.getChrHapArray(i));

         }
         HashMap<Integer, int[]> childArrays = sim.recombine(chroArrays);
         childChros.addChildChros(childArrays.get(0), childArrays.get(1));
     }
   }
}
