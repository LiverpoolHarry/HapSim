
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package haplotypesimulator;

import dataAnalysis.DataPrinter;
import dataAnalysis.DataArray;
import java.util.Properties;
import dataAnalysis.StartAnalysis;
import java.util.ArrayList;

/**
 *
 * @author harry
 */
public class IntercrossDemo extends Thread {

   private Params p;
   private Properties config;
   private DataArray dArray;
   //private RunIntercross runInt;
   private ParentChros parentChros;
   private ChildChros childChros;
   private DataPrinter dAnalyser;
   private Integer delay;
   private ArrayList<Integer> brPosClone;
   private int generations;
   private Integer popSize;
   //private ArrayList<int[]> demoData;

   public IntercrossDemo(Properties config, Params params) {
      this.config = config;
      p = params;
      generations = Integer.parseInt(config.getProperty("generations"));
      popSize = Integer.parseInt(config.getProperty("popSize"));

      //create object for array of child chromosomes
      //and populate it with first geration data
      childChros = new ChildChros(config);
      parentChros = new ParentChros(popSize);
      delay = Integer.parseInt(config.getProperty("delay"));
      brPosClone = new ArrayList<Integer>(4);
   }

   /**
    *
    * @param config
    * @param params
    * @param parentChros
    * @param childChros
    */
   @Override
   public void run() {


      //Initialise simulator object
      Integer numberOfRecombinations = 1;//codge to avoid having two different constructors for Simulator

      Simulator sim = new Simulator(config, p, parentChros, childChros, numberOfRecombinations);

      //Intercross input initalises arrays with empty chromosomes and then does first recombination
      new IntercrossInput(config, p, parentChros, sim);


      for (int i = 2; i <= generations; i++) {
         //System.out.println("Generation: " + i);
         //run cancellation mechanism
         if (p.getGeneration() == generations) {
            i = generations;
            break;
         }
         else {
            p.setGeneration(i);
         }
         //F2 has been created by IntercroosInput so needs analysis before starting main loop
         //analyseData();
         setDemoData(i);
         try {
            Thread.sleep(delay * 1000); // do nothing for 1000 miliseconds (1 second)
         }
         catch (InterruptedException e) {
            e.printStackTrace();
         }
         //Make child chromosomes parent chromosomes
         //swap child chromosome arrays into parent arrays
         //Assumes that the object that initiates the arrays leaves fully populated child chromosome arrays
         parentChros.setParentChrArrays(childChros.getChildChrHapArray(), childChros.getChildChrPosArray());

         childChros.clearChildHapArray();
         childChros.clearChildPosArray();

         //The first recombination is used by the demo so need
         //known parents. Child will be at 0.
         //Cannot use 0 as that will inbreed
         sim.recombineSpecifiedChros(2, 3);
         brPosClone = (ArrayList<Integer>) sim.getBrPos().clone();
         //setDemoData();

         //Recombine rest of population
         for (int j = 1; j <= popSize; j++) {
            // Integer m = p.getRandChr(parentChros.size());
            // Integer n = p.getRandChr(parentChros.size());
            Integer m = RunSimulation.ranGen.getRandChr(parentChros.size());
            Integer n = RunSimulation.ranGen.getRandChr(parentChros.size());

            sim.recombineSpecifiedChros(m, n);
         }
      }
   }

   private void setDemoData(int gen) {
      //Create array for display of recombined chromosomes in IntercrossDemo
      //Convert ArrayList<Integer> to int[] (there must be a better way?
      int[] breaks = new int[5];
      if (!brPosClone.isEmpty()) {
         int j = 0;
         for (Integer i : brPosClone) {
            breaks[j] = (int) i;
            j++;
         }
      }
      //Generation 2 is created by IntercrossInput class not this one so
      //at generation two the breaks are the same as the break positions in the
      //child chromosome. Also uses parents 0 and 1 to generate child 0;
      int p1 = 2;
      int p2 = 3;
      if (gen == 2) {
         breaks = childChros.getChildChrPos(0);
         p1 = 0;
         p2 = 1;
      }
      //demoData is used to plot chromosome diagrams by gui.ChromosomeDemo
      //but it gets past along the line to StartAnalysis aand then to DataArray
      //to be accessible to gui.ChromosomeDemo
      ArrayList<int[]> demoData = new ArrayList<int[]>(7);
      demoData.add(breaks);
      demoData.add(parentChros.getParentChrPos(p1));
      demoData.add(parentChros.getParentChrHap(p1));
      demoData.add(parentChros.getParentChrPos(p2));
      demoData.add(parentChros.getParentChrHap(p2));
      demoData.add(childChros.getChildChrPos(0));
      demoData.add(childChros.getChildChrHap(0));

      //Have to clone childArray for analysis becuase it is about to be deleted
      ArrayList<int[]> childChrosClone = new ArrayList<int[]>();
      childChrosClone = (ArrayList<int[]>) childChros.getChildChrPosArray().clone();
      Thread analysisThread = new Thread(new StartAnalysis(p, childChrosClone, demoData, gen));

      analysisThread.start();
   }
}
