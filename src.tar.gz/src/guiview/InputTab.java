
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.swing.ButtonGroup;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.util.Map;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * FormattedTextFieldDemo.java requires no other files. *
 * It implements a mortgage calculator that uses four
 * JFormattedTextFields.
 * also used Java tutorial http://download.oracle.com/javase/tutorial/uiswing/components/formattedtextfield.html
 */
public class InputTab extends Observable implements PropertyChangeListener {

   //Formats to format and parse numbers
   private NumberFormat integerFormat;
   private NumberFormat doubleFormat;
   private JRadioButton mouseButton;
   private JRadioButton humanButton;
   private JRadioButton defaultButton;
   //HashMaps of components of display
   private HashMap<String, JFormattedTextField> textFields;
   private HashMap<String, NumberFormat> integerFormats;
   private HashMap<String, JLabel> fieldLabels;
   private HashMap<String, Object> values;
   private HashMap<String, Integer> minValues;//Min permitted values for fields
   private HashMap<String, Integer> maxValues;//Max permitted values for fields
   private HashMap<String, String> fieldLabelsText;
   private String cardName;
   private HashMap<String, Integer> defaults;
   //List of field names
   private ArrayList<String> names;
   //Maximum size of text boxes
   private Dimension fieldSize = new Dimension(200, 30);
   private Params p;

   public InputTab(Params p, String cardName) {

      this.p = p;
      this.cardName = cardName;
      //Set up integer and double formats for JFormattedTextField
      setUpFormats();
      //The order of all the elements in the arrays is critical
      //since elements at the same position are assumed to apply to the same parameter
      String[] fieldNames = {"generations", "initialPopSize", "chrLength", "noOfHaplotypes", "ploidy", "familySize",
         "founders", "orderedHaplotypes", "recom0", "recom1", "recom2", "recom3", "hotspotInterval",
         "telomereLength", "minDistance", "statisticInterval", "numberOfThreads", "replicateCount", "binSize"};
      //Field labels
      String[] labels = {"Number Of Generations", "Population Size", "Chromosome Length",
         "Number Of Haplotypes", "Ploidy; Diploid = 2, Haploid = 1", "Family Size",
         "F1 Heterozygotes = 0, F1 Randomised = 1",
         "Founder haplotypes assigned at random (0) or sequentially (1)",
         "Zero Recombinations", "One Recombination",
         "Two Recombinations", "Three Recombinations", "Hotspot Interval",
         "Telomere Length", "Interference Interval", "Output Interval (Generations)",
         "Number of parallel processes (threads)",
         "Number of Replicates",
         "Size of Bins for Haplotype Length Frequency Plot"
      //"Delay between generations (s)"
      };

      //Max and Min permitted values for fields in same order as filednames and labels
      int[] minIntValues = {2, 2, 10, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1};
      int[] maxIntValues = {10000, 10000, 1000000000, 1000, 2, 100, 2, 1, 1000, 1000, 1000, 1000, 50000000, 10000000, 100000000, 1000, 4, 100, 100000000};

      String[] toolTips = {"Number of generations to simulate (Min 2, Max 10,000 )",
         "Haploid Population Size (2 x Diploid population size) (Min 2, Max 10,000)",
         "Length of chromosome to model (Min 10, Max 1,000,000,000)",
         "Number of founder haplotypes (Min 2, Max 1,000)",
         "Model a diploid or a haploid organism",
         "Number of offspring from each pair of parents",
         "Structure mating to ensure heterozygotes in F1 (0) or randomise mating and allow homozygotes in F1 (1). Using sequential assignment of haplotypes (below) will enforce heterozygotes in F1",
         "Assign haplotypes to individuals at random to simulate a natural population or sequentially to simulate structured mating schemes",
         "Relative frequency of zero recombinations (Integer, Min 0, Max 1,000)",
         "Relative frequency of one recombination (Integer, Min 0, Max 1,000)",
         "Relative frequency of two recombinations (Integer, Min 0, Max 1,000)",
         "Relative frequency of three recombinations (Integer, Min 0, Max 1,000)",
         "Interval between recombination hotspots (Integer, Min 0, Max 50,000,000)",
         "Length of telomere in which recombinations are prohibited (Min 1, Max 10,000,000)",
         "Minimum distance between adjacent crossovers in a single meiosis (Min 0, Max 100,000,000)",
         "Number of generations between outputs (Min 1, Max 1,000)",
         "Number of parallel processes (threads) to run (Min 1, Max 4 More does not increase speed)",
         "Number of replicate simulations for a given set of conditions",
         "Size  of Bins for Haplotype Length Frequency Plot"
      };

      //Default values of text fields
      Integer[] defaultVals = {10, 100, 100000000, 2, 2, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 2, 10, 1000000};

      defaults = new HashMap<String, Integer>(defaultVals.length);
      for (int i = 0; i < defaultVals.length; i++) {
         defaults.put(fieldNames[i], defaultVals[i]);
      }
      //Create Hash of textFields
      textFields = new HashMap<String, JFormattedTextField>();
      values = new HashMap<String, Object>();
      fieldLabels = new HashMap<String, JLabel>();
      names = new ArrayList<String>();
      minValues = new HashMap<String, Integer>();
      maxValues = new HashMap<String, Integer>();
      fieldLabelsText = new HashMap<String, String>();
      //Create text fields and arrays
      int i = 0;
      for (String fn : fieldNames) {
         addTextField(fn, toolTips[i], defaultVals[i], labels[i], minIntValues[i], maxIntValues[i]);
         minValues.put(fn, minIntValues[i]);
         maxValues.put(fn, maxIntValues[i]);
         fieldLabelsText.put(fn, labels[i]);
         i++;
      }
      //set default start generation as dependent on the founders type and not in a field
      values.put("startGeneration", 2);

   }

   public void setMinMaxValues(String name, Integer min, Integer max) {
      minValues.put(name, min);
      maxValues.put(name, max);
   }

   //Update default values in fields
   public void setDefaultValue(String field, Integer val) {
      textFields.get(field).setValue(val);
   }

   public void addTextField(String name, String toolTipText, Integer defaultValue,
         String label, Integer minValue, Integer maxValue) {
      textFields.put(name, new JFormattedTextField(integerFormat));
      textFields.get(name).setToolTipText(toolTipText);
      textFields.get(name).setValue(defaultValue);
      textFields.get(name).addPropertyChangeListener("value", this);
      textFields.get(name).setColumns(p.getColumnWidth());
      textFields.get(name).setMaximumSize(fieldSize);
      if (name.contentEquals("initialPopSize")) {
         values.put("popSize", (Integer) defaults.get("ploidy") * defaultValue);
      }
      values.put(name, defaultValue);
      fieldLabels.put(name, new JLabel(label));
      names.add(name);
      minValues.put(name, minValue);
      maxValues.put(name, maxValue);
      //System.out.println("adTextField; Name: " + name + "; value: " + defaultValue);

      //Pass values to hash in params so that correct set of
      //values is called by MVController when start is pressed.
      p.setModelValues(cardName, values);

   }

   /** Called when a field's "value" property changes. */
   public void propertyChange(PropertyChangeEvent e) {
      Object source = e.getSource();
      Iterator itr = names.iterator();
      boolean noOfHaplotypesChanged = false;
      boolean noOfGenerationsChanged = false;

      while (itr.hasNext()) {
         String name = (String) itr.next();
         if (source == textFields.get(name)) {
            int value = ((Number) textFields.get(name).getValue()).intValue();
            //check if new value is outside accepted range if it is reset to previous value
            if (value < minValues.get(name)) {
               textFields.get(name).setValue(values.get(name));

            }
            else if (value > maxValues.get(name)) {
               textFields.get(name).setValue(values.get(name));
            }
            else {

               if (name.contentEquals("initialPopSize") || name.contentEquals("ploidy")) {
                  value = ((Number) textFields.get("ploidy").getValue()).intValue() * ((Number) textFields.get("initialPopSize").getValue()).intValue();
                  values.put("popSize", value);
                  noOfHaplotypesChanged = true;
               }
               //sanity check that there will be at least 10 places for recombination given hotspot interval and chrLength
               else if (name.contentEquals("chrLength") || name.contentEquals("hotspotInterval")) {
                  if (((Number) textFields.get("chrLength").getValue()).intValue() / ((Number) textFields.get("hotspotInterval").getValue()).intValue() > 10) {
                     values.put(name, value);
                  }
                  else {
                     textFields.get(name).setValue(values.get(name));
                  }
               }
               //check if that telomeres do not extend too far and leave at least 10 recombination positions
               else if (name.contentEquals("chrLength") || name.contentEquals("telomereLength")) {
                  if ((((Number) textFields.get("chrLength").getValue()).intValue() - 2 * ((Number) textFields.get("telomereLength").getValue()).intValue()) /
                        ((Number) textFields.get("hotspotInterval").getValue()).intValue() > 10) {
                     values.put(name, value);
                  }
                  else {
                     textFields.get(name).setValue(values.get(name));
                  }

               }
               else if (name.contentEquals("chrLength") || name.contentEquals("minDistance")) {
                  if (((Number) textFields.get("chrLength").getValue()).intValue() / ((Number) textFields.get("minDistance").getValue()).intValue() > 4) {
                     values.put(name, value);
                  }
                  else {
                     textFields.get(name).setValue(values.get(name));
                  }

               }
               else if (name.contentEquals("founders")) {
                  if (((Number) textFields.get("founders").getValue()).intValue() == 0) {
                     values.put("startGeneration", 2);
                  }
                  else {
                     values.put("startGeneration", 1);
                  }
                  values.put(name, value);
               }
               else if (name.contentEquals("noOfHaplotypes")) {
                  //notify observer in IntercrossView that number of haplotypes ahs changed so that
                  // haplotype frequencies box can change number of entries
                  values.put(name, value);
                  noOfHaplotypesChanged = true;
               }
               else if (name.contentEquals("generations")) {
                  //notify observer in IntrogressionsView that number of haplotypes ahs changed so that
                  // haplotype frequencies box can change number of entries
                  values.put(name, value);
                  noOfGenerationsChanged = true;
               }
               else {
                  values.put(name, value);
               }
            }
         }
      }
      //Update hashMap of array values for passing to simulator
      p.setModelValues(cardName, values);
      if (noOfHaplotypesChanged == true) {
         setChanged();
         notifyObservers("noOfHaplotypesChanged");
         // System.err.println("Observer notified");
      }
      if (noOfGenerationsChanged == true) {
         setChanged();
         notifyObservers("noOfGenerationsChanged");
         // System.err.println("Observer notified");
      }

   }

   //Create and set up number formats. These objects also
   //parse numbers input by user.
   private void setUpFormats() {
      integerFormat = NumberFormat.getIntegerInstance();
      doubleFormat = NumberFormat.getNumberInstance();
   }

   public HashMap<String, JLabel> getFieldLabels() {
      return fieldLabels;
   }

   public HashMap<String, JFormattedTextField> getTextFields() {
      return textFields;
   }

   public ArrayList<String> getNames() {
      return names;
   }

   public JPanel getRatioBox() {
      //Create boxes for layout of recombination ratios
      //create the buttons
      setSpeciesRadioButton();

      String[] recomRatios = {"recom0", "recom1", "recom2", "recom3"};

      JPanel ratioBox = new JPanel();
      ratioBox.setBorder(BorderFactory.createEtchedBorder(0));
      GridBagLayout gridbag = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();
      c.gridwidth = 1;
      c.gridx = 0;
      c.gridy = 0;

      ratioBox.add(new JLabel("Relative counts of each number of crossovers"), c);
      for (String ratio : recomRatios) {
         c.gridy++;
         ratioBox.add(fieldLabels.get(ratio), c);
         c.gridy++;
         ratioBox.add(textFields.get(ratio), c);
      }
      c.gridy++;
      c.gridx = 0;
      ratioBox.add(mouseButton, c);
      c.gridy++;
      c.gridx = 0;
      ratioBox.add(humanButton, c);
      c.gridy++;
      c.gridx = 0;
      ratioBox.add(defaultButton, c);

      return ratioBox;
   }

   public JPanel getHapFreqs() {
      //JPanel hapFreqOuterBox = new JPanel();

      JPanel hapFreqPanel = new JPanel();
      hapFreqPanel.setBorder(BorderFactory.createEtchedBorder(0));

      GridBagLayout gridbag = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();
      c.gridwidth = 1;
      hapFreqPanel.setLayout(gridbag);


      //Integer ploidy = (Integer) values.get("ploidy");
      Integer pop = (Integer) values.get("popSize");
      Integer haps = (Integer) values.get("noOfHaplotypes");
      Integer def = (int) (pop / haps);
      Integer maxVal = pop - haps + 1;
      Integer freqsTotal = 0;

      hapFreqPanel.setMaximumSize(new Dimension(350, 100 + haps * 25));

      c.gridwidth = 2;
      c.gridx = 0;
      c.gridy = 0;
      hapFreqPanel.add(new JLabel("Counts of each number of haplotypes"), c);
      c.gridy = 1;
      hapFreqPanel.add(new JLabel("Must sum to number of chromosomes (" + pop + ")"), c);
      c.insets = new Insets(5, 0, 0, 0);//vertical padding
      clearOldHaps();//otherwise may have haps with zero frequency in printouts
      for (Integer hap = 1; hap < haps; hap++) {
         setHapFreqs(hap, def, maxVal, hapFreqPanel, c);
         freqsTotal += def;
      }
      //Adjust last value to make sure that all defaults sum to pop * ploidy
      def = def + pop % haps;
      setHapFreqs(haps, def, maxVal, hapFreqPanel, c);
      freqsTotal += def;
      c.gridwidth = 2;
      c.gridx = 0;
      c.gridy = haps + 2;
      hapFreqPanel.add(new JLabel("Frequency total (" + freqsTotal + ") should sum to"), c);
      c.insets = new Insets(0, 0, 0, 0);//vertical padding

      // c.gridx = 0;
      c.gridy = haps + 3;
      hapFreqPanel.add(new JLabel("number of chromosomes (" + pop + ")"), c);


      return hapFreqPanel;
   }

   private void setHapFreqs(Integer hap, Integer def, Integer maxVal, JPanel hapFreqPanel, GridBagConstraints c) {
      String hapName = "hap" + hap;
      String tooltip = "Number of chromosomes with haplotype number " + hap;
      String label = "Haplotype " + hap;

      Integer minVal = 1;
      // System.out.println("SetHapfreqs; hap: " + hapName + "; value: " + def);
      addTextField(hapName, tooltip, def, label, minVal, maxVal);
      textFields.get(hapName).setPreferredSize(new Dimension(60, 20));
      c.gridwidth = 1;
      c.gridx = 0;
      c.gridy = hap + 1;
      hapFreqPanel.add(fieldLabels.get(hapName), c);
      c.gridx = 1;
      c.gridy = hap + 1;
      hapFreqPanel.add(textFields.get(hapName), c);
   }

   //If the number of haplotypes are reduced the entries will still exist in the array
   //although they will be set at 0
   private void clearOldHaps() {

      Iterator iter = values.entrySet().iterator();
      while (iter.hasNext()) {
         Map.Entry pairs = (Map.Entry) iter.next();
         String key = (String) pairs.getKey();
         if (key.startsWith("hap")) {
            iter.remove();
         }
      }
   }

   //Data from Broman, et al Genetics 160, 1123-31 (2002).
   public void setMouseRatios() {
      // mouse recom_ratios = (0=> 77.6,1=>94.4,2=>15.8, 3=>0.21);
      // 0=>370, 1=>450, 2=>75, 3=>1
      String[] recoms = {"recom0", "recom1", "recom2", "recom3"};
      int[] vals = {370, 450, 75, 1};
      for (int i = 0; i < 4; i++) {
         //values.put(recoms[i], vals[i]);
         setDefaultValue(recoms[i], vals[i]);
      }
   }

   public void setHumanRatios() {
      // mouse recom_ratios = (0=> 77.6,1=>94.4,2=>15.8, 3=>0.21);
      // 0=>370, 1=>450, 2=>75, 3=>1
      setDefaultValue("recom0", 51);
      setDefaultValue("recom1", 110);
      setDefaultValue("recom2", 100);
      setDefaultValue("recom3", 10);
   }

   public void setDefaultRatios() {
      // mouse recom_ratios = (0=> 77.6,1=>94.4,2=>15.8, 3=>0.21);
      // 0=>370, 1=>450, 2=>75, 3=>1
      setDefaultValue("recom0", 0);
      setDefaultValue("recom1", 1);
      setDefaultValue("recom2", 0);
      setDefaultValue("recom3", 0);
   }

   //Buttons to select known ratios for different species
   public void setSpeciesRadioButton() {
      //Create the radio buttons.
      mouseButton = new JRadioButton("Use mouse ratios");
      mouseButton.setActionCommand("mouse");
      //mouseButton.setSelected(true);

      humanButton = new JRadioButton("Use human ratios");
      humanButton.setActionCommand("human");

      defaultButton = new JRadioButton("Use default ratios");
      defaultButton.setActionCommand("default");

      //Group the radio buttons.
      ButtonGroup group = new ButtonGroup();
      group.add(mouseButton);
      group.add(humanButton);
      group.add(defaultButton);

      //Register a listener for the radio buttons.
      ButtonActions ba = new ButtonActions();
      mouseButton.addActionListener(ba);
      humanButton.addActionListener(ba);
      defaultButton.addActionListener(ba);
   }

   private class ButtonActions implements ActionListener {

      public void actionPerformed(ActionEvent e) {
         String ac = e.getActionCommand();
         if (ac.endsWith("mouse")) {
            setMouseRatios();
         }
         else if (ac.endsWith("human")) {
            setHumanRatios();
         }
         else if (ac.endsWith("default")) {
            setDefaultRatios();
         }
      }
   }

//Check that the number of each haplotype equals the population size times ploidy
   public Integer validateFreqs(String currentModelName) {
      Integer pop = (Integer) p.getModelValues(currentModelName).get("popSize");
      if (!p.getCurrentViewName().contentEquals("Introgression")) {

         Integer haps = (Integer) p.getModelValues(currentModelName).get("noOfHaplotypes");
         Integer freqsTotal = 0;
         Double meanHapFreq = 0.0;
         for (Integer hap = 1; hap <= haps; hap++) {
            String hapName = "hap" + hap;
            Integer hapCount = (Integer) p.getModelValues(currentModelName).get(hapName);
            freqsTotal += hapCount;
            meanHapFreq += (1 - (hapCount * 1.0) / (pop * 1.0)) * (((hapCount * 1.0) / (pop * 1.0)));
         }
         p.setMeanHapFreq(meanHapFreq);
         return freqsTotal;
      }
      else{
         p.setMeanHapFreq(0.25);
         return(pop );
      }
   }
}

