
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import javax.swing.Box;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author harry
 */
public class IntrogressionView extends ViewTemplate implements Observer {

   //public HashMap<String, Object> values;
   private InputTab input;
   private JPanel inputPanel;
   private Box rightPanel;
   private JPanel ratioBox;
   private JPanel hapFreqsPanel;
   private JScrollPane scrollpane;

   public IntrogressionView(String name, Params p) {
      super(name, p);

      //Get and set the card with tabbed panes
      //getCard is a method of the parent class that creates a card panel with two tabbed panes
      p.getViewPanel().setCard(name, getCard(name));

      setInputTab();
      //pass output panel up to Params
      p.setOutputPanels(name, getBreaksOutputPanel());
      p.setOutputPanels(name, getHapsOutputPanel());
   }

   public IntrogressionView() {
      name = "Introgression";
      p = Params.p;
      //super(name, p);

      //Get and set the card with tabbed panes
      //getCard is a method of the parent class that creates a card panel with two tabbed panes
      p.getViewPanel().setCard(name, getCard(name));
      setInputTab();
      //pass output panels up to Params

      p.setOutputPanels(name, getBreaksOutputPanel());
      p.setOutputPanels(name, getHapsOutputPanel());

   }

   private void setInputTab() {
      //Initialise class which defines text fields
      input = new InputTab(p, name);
      p.setInputTab(input);
      input.addObserver(this);
      //List of neames pf fileds required for this wimdow
      String[] fieldNames = {"generations", "initialPopSize", "chrLength", "peakMarker", "flankingMarker",
         "familySize", "founders", "hotspotInterval", "telomereLength", "minDistance", "statisticInterval",
         "numberOfThreads", "replicateCount"};
      String[] recomRatios = {"recom0", "recom1", "recom2", "recom3"};

      input.addTextField("peakMarker", "Position of peak marker in base pairs", 50000000,
            "Postion of Positive Selection Marker (bp)", 1, 200000000);

      input.addTextField("flankingMarker", "Distance from peak marker of a flanking marker used for negative selection", 5000000,
            "Distance to Flanking Negative Selection Marker (bp)", 1, 200000000);


      //Get the text fields and labels
      HashMap<String, JLabel> labels = input.getFieldLabels();
      HashMap<String, JFormattedTextField> textFields = input.getTextFields();

      //get the JPanel for the text boxes from the superclass
      inputPanel = getInputPanel();

      //Create Box for text field layout and add labels and textboxes to the Box
      Box inputBox = Box.createVerticalBox();
      for (String fieldName : fieldNames) {
         inputBox.add(labels.get(fieldName));
         inputBox.add(textFields.get(fieldName));

      }
      //Enter default values
      p.getModelValues(name).put("ploidy", 2);
      p.getModelValues(name).put("noOfHaplotypes",  p.getModelValues(name).get("generations"));

      //Get box layout containing recombination ratios and Haplotype frequencies
      rightPanel = Box.createVerticalBox();
      rightPanel.setSize(new Dimension(360, 800));
      rightPanel.setAlignmentX(400);


      ratioBox = input.getRatioBox();
      ratioBox.setPreferredSize(new Dimension(350, 350));
      rightPanel.add(ratioBox, BorderLayout.NORTH);
      //hap freqs are ignored but need ot get them to satisfy  InputTab.validateFreqs
      //hapFreqsPanel = input.getHapFreqs();
      /*scrollpane = new JScrollPane();
      scrollpane.setViewportView(hapFreqsPanel);      
      ratioBox.setAlignmentY(scrollpane.CENTER_ALIGNMENT);
      rightPanel.add(scrollpane);
       */

      //Add boxes to JPanel
      inputPanel.add(inputBox, BorderLayout.WEST);
      inputPanel.add(rightPanel, BorderLayout.EAST);

   }

   //Observer for changes in number of haplotypes so that number of boxes 
   //for haplotype frequencies can be changed.
   //Observes observable in InputTab
   public void update(Observable in, Object field) {
      if (in == input) {
         if (field.equals("noOfGenerationsChanged")) {
            p.getModelValues(name).put("noOfHaplotypes",  p.getModelValues(name).get("generations"));
         }
      }

   }
}
