
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */


package guiview;

import java.util.HashMap;

/**
 *
 * @author harry
 * Rates from:
 * Comparative Recombination Rates in the Rat, Mouse, and Human Genomes
 * Michael I. Jensen-Seaman, Terrence S. Furey, Bret A. Payseur, Yontao Lu, Krishna M. Roskin, Chin-Fu Chen, Michael A. Thomas, David Haussler and Howard J. Jacob
 *  Genome Res. 2004 14: 528-538 Access the most recent version at doi:10.1101/gr.1970304
 */
public class RecomRatios {

   private HashMap<String, Double[]> mouseRatios;
   private HashMap<String, Double[]> humanRatios;
   private HashMap<String, Double[]> ratRatios;

   public RecomRatios() {
      //Double[] contain (chromosome length x 1,000,000, recombination rate)
      mouseRatios = new HashMap<String, Double[]>();
      ratRatios = new HashMap<String, Double[]>();
      humanRatios = new HashMap<String, Double[]>();

      mouseRatios.put("Chr1", new Double[]{267.4, 0.56});
      mouseRatios.put("Chr2", new Double[]{255.3, 0.44});
      mouseRatios.put("Chr3", new Double[]{166.0, 0.55});
      mouseRatios.put("Chr4", new Double[]{186.1, 0.55});
      mouseRatios.put("Chr5", new Double[]{171.6, 0.62});
      mouseRatios.put("Chr6", new Double[]{134.2, 0.63});
      mouseRatios.put("Chr7", new Double[]{141.6, 0.62});
      mouseRatios.put("Chr8", new Double[]{126.8, 0.66});
      mouseRatios.put("Chr9", new Double[]{109.5, 0.71});
      mouseRatios.put("Chr10", new Double[]{101.2, 0.92});
      mouseRatios.put("Chr11", new Double[]{73.6, 0.53});
      mouseRatios.put("Chr12", new Double[]{43.6, 1.19});
      mouseRatios.put("Chr13", new Double[]{75.1, 0.58});
      mouseRatios.put("Chr14", new Double[]{105.7, 0.67});
      mouseRatios.put("Chr15", new Double[]{106.1, 0.6});
      mouseRatios.put("Chr16", new Double[]{76.6, 0.59});
      mouseRatios.put("Chr17", new Double[]{91.0, 0.48});
      mouseRatios.put("Chr18", new Double[]{84.7, 0.62});
      mouseRatios.put("Chr19", new Double[]{56.4, 0.85});
      mouseRatios.put("ChrX", new Double[]{130.8, 0.34});
      mouseRatios.put("All", new Double[]{2553.9, 0.6});
      mouseRatios.put("Autosomes", new Double[]{2423.1, 0.62});

      ratRatios.put("Chr1", new Double[]{187.6, 0.61});
      ratRatios.put("Chr2", new Double[]{177.5, 0.54});
      ratRatios.put("Chr3", new Double[]{151.9, 0.44});
      ratRatios.put("Chr4", new Double[]{147.4, 0.54});
      ratRatios.put("Chr5", new Double[]{145.7, 0.56});
      ratRatios.put("Chr6", new Double[]{144.7, 0.45});
      ratRatios.put("Chr7", new Double[]{130.0, 0.52});
      ratRatios.put("Chr8", new Double[]{123.7, 0.61});
      ratRatios.put("Chr9", new Double[]{116.8, 0.58});
      ratRatios.put("Chr10", new Double[]{122.9, 0.61});
      ratRatios.put("Chr11", new Double[]{118.4, 0.68});
      ratRatios.put("Chr12", new Double[]{108.5, 0.51});
      ratRatios.put("Chr13", new Double[]{112.1, 0.52});
      ratRatios.put("Chr14", new Double[]{108.9, 0.64});
      ratRatios.put("Chr15", new Double[]{100.9, 0.63});
      ratRatios.put("Chr16", new Double[]{95.4, 0.54});
      ratRatios.put("Chr17", new Double[]{85.8, 0.57});
      ratRatios.put("Chr18", new Double[]{86.3, 0.46});
      ratRatios.put("Chr19", new Double[]{55.5, 1.04});
      ratRatios.put("Chr20", new Double[]{50.6, 0.95});
      ratRatios.put("ChrX", new Double[]{145.6, 0.4});
      ratRatios.put("All", new Double[]{2465.6, 0.56});
      ratRatios.put("Autosomes", new Double[]{2320.0, 0.57});

      humanRatios.put("Chr1", new Double[]{241.0, 1.12});
      humanRatios.put("Chr2", new Double[]{241.6, 1.07});
      humanRatios.put("Chr3", new Double[]{199.0, 1.11});
      humanRatios.put("Chr4", new Double[]{190.6, 1.07});
      humanRatios.put("Chr5", new Double[]{180.3, 1.14});
      humanRatios.put("Chr6", new Double[]{169.7, 1.12});
      humanRatios.put("Chr7", new Double[]{155.1, 1.16});
      humanRatios.put("Chr8", new Double[]{144.6, 1.15});
      humanRatios.put("Chr9", new Double[]{133.9, 1.2});
      humanRatios.put("Chr10", new Double[]{134.2, 1.31});
      humanRatios.put("Chr11", new Double[]{134.0, 1.14});
      humanRatios.put("Chr12", new Double[]{132.8, 1.3});
      humanRatios.put("Chr13", new Double[]{94.4, 1.37});
      humanRatios.put("Chr14", new Double[]{83.8, 1.41});
      humanRatios.put("Chr15", new Double[]{77.5, 1.66});
      humanRatios.put("Chr16", new Double[]{89.2, 1.45});
      humanRatios.put("Chr17", new Double[]{80.2, 1.68});
      humanRatios.put("Chr18", new Double[]{77.0, 1.57});
      humanRatios.put("Chr19", new Double[]{61.5, 1.78});
      humanRatios.put("Chr20", new Double[]{58.4, 1.69});
      humanRatios.put("Chr21", new Double[]{30.1, 2.06});
      humanRatios.put("Chr22", new Double[]{31.4, 2.1});
      humanRatios.put("ChrX", new Double[]{148.5, 1.21});
      humanRatios.put("All", new Double[]{2888.5, 1.26});
      humanRatios.put("Autosomes", new Double[]{2740.0, 1.26});
   }

   public HashMap<String, Double[]> getHumanRatios() {
      return humanRatios;
   }

   public HashMap<String, Double[]> getMouseRatios() {
      return mouseRatios;
   }

   public HashMap<String, Double[]> getRatRatios() {
      return ratRatios;
   }
}
