
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import JavaClassLoader.JarClassLoader;
import dataAnalysis.DataArray;
import java.awt.Dimension;
import java.awt.Font;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import org.jfree.chart.JFreeChart;

/**
 *
 * @author harry
 */
public class Params {

   private ArrayList<String> viewNames;//Names of types of simulation
   private HashMap<String, Object> viewClasses; //names of classes for each type of simulation
   private String modelRegEx = "View.class"; //regex to select classes that represent types of simulation
   private static ViewPanel vp;//Class that carries cards with each type of simulation input and output
   private HashMap<String, HashMap<String, Object>> modelValues;
   private String currentViewName; //name of top card
   private HashMap<String, JPanel> outputPanels;
   private HashMap<String, JPanel> inputPanels;
   private JScrollPane graphicScrollPane; //pane for chromosome diagram in Demonsttration
   private DataArray dArray;
   private HashMap<String, JFreeChart> jFreecharts;//Holds all plots from run for printing
   private HashMap<String, JTabbedPane> tabbedPanes;//cards holding input and output tab one for each model
   public static Params p;
   private MainWindow mainWindow;
   private InputTab inputTab;
   private String defaultViewName; //for window that displays on opening programme
   private Double meanHapFreq;
   private Double[] expecteds;//Array of theoretical numbers of break points
   //All dimensions are set from here
   private final Dimension frameSize = new Dimension(920, 880);
   private final Dimension topPanelSize = new Dimension(910, 50);
   private final Dimension viewPanelSize = new Dimension(910, 820);
   private final Dimension cardPanelSize = new Dimension(900, 775);
   private final Dimension meanBreaksTableSize = new Dimension(340, 325);
   private final Dimension meanBreaksPerGenerationPlotSize = new Dimension(650, 220);
   private final Dimension breaksDistributionChartSize = new Dimension(580, 390);
   private final Dimension meanHapLengthBarChartSize = new Dimension(650, 220);
   private final Dimension hapsDistributionChartSize = new Dimension(580, 390);
   private final Dimension chroDemoGraphicSize = new Dimension(500, 750);
   private final Font headerFont = new Font("SansSerif", Font.BOLD, 14);
   private final int columnWidth = 10; //width of FormmattedTextFields on input page

   public Params() {
      vp = new ViewPanel(this);
      p = this;
      modelValues = new HashMap<String, HashMap<String, Object>>();
      outputPanels = new HashMap<String, JPanel>();
      inputPanels = new HashMap<String, JPanel>();
      tabbedPanes = new HashMap<String, JTabbedPane>();
      viewNames = new ArrayList<String>();
      viewClasses = new HashMap<String, Object>();
      defaultViewName = "IntercrossDemo";
      jFreecharts = new HashMap<String, JFreeChart>();
      //setModels();
      //loadModelClasses(mp);
   }

   /* public void setViews() {

   /*The commented out lines in this method are a manual alternative
   for loading model classes. This is much simpler than the automated option
   but would require developers to edit this params file as well as their classes


   modelNames = new ArrayList<String>();
   modelNames.add("IntercrossDemo");
   modelNames.add("Intercross");
   modelClasses = new HashMap<String, Object>();
   modelClasses.put(modelNames.get(0), new IntercrossDemoModel("IntercrossDemo", this));
   modelClasses.put(modelNames.get(1), new IntercrossModel("Intercross", this));
   //Name of model that will be displayed on opening programme



   }*/
   public String getCurrentViewName() {
      return currentViewName;
   }

   public void setCurrentViewName(String modelName) {
      this.currentViewName = modelName;
   }

   /**
    * Convert individual recombination ratios to format expected by config
    *  and params in haplotype simulator
    * @param String name name of model for which values are set
    * @param HashMap<String, Object> hm  hashMap of name
    */
   public void setModelValues(String name, HashMap<String, Object> hm) {
      String breakDistribution = "0=>" + hm.get("recom0") + ",1=>" + hm.get("recom1") +
            ",2=>" + hm.get("recom2") + ",3=>" + hm.get("recom3");
      hm.put("breakDistribution", breakDistribution);
      modelValues.put(name, hm);
   }

   public DataArray getdArray() {
      return dArray;
   }

   public void setdArray(DataArray dArray) {
      this.dArray = dArray;
   }

   public ViewPanel getViewPanel() {
      return vp;
   }

   public Dimension getViewPanelSize() {
      return viewPanelSize;
   }

   public Dimension getTopPanelSize() {
      return topPanelSize;
   }

   public Dimension getCardPanelSize() {
      return cardPanelSize;
   }

   public Dimension getFrameSize() {
      return frameSize;
   }

   public Dimension getMeanBreaksTableSize() {
      return meanBreaksTableSize;
   }

   public Dimension getBreaksDistributionChartSize() {
      return breaksDistributionChartSize;
   }

   public Dimension getMeanBreaksPerGenerationPlotSize() {
      return meanBreaksPerGenerationPlotSize;
   }

   public Dimension getChroDemoGraphicSize() {
      return chroDemoGraphicSize;
   }

   public Font getHeaderFont() {
      return headerFont;
   }

   public HashMap<String, Object> getModelValues(String name) {
      return modelValues.get(name);
   }

   public ArrayList<String> getViewNames() {
      return viewNames;
   }

   public Object getView(String modelName) {
      return viewClasses.get(modelName);
   }

   public String getDefaultViewName() {
      return defaultViewName;
   }

   public HashMap<String, Object> getViewClasses() {
      return viewClasses;
   }

   public JPanel getOutputPanels(String name) {
      return outputPanels.get(name);
   }

   public ArrayList<String> getjFreechartsKeySet() {
      //Do alphanumeric sort, based on
      //http://stackoverflow.com/questions/5403334/how-to-sort-based-on-alphanumeric-values-using-java

      ArrayList<String> inputList = new ArrayList<String>(jFreecharts.keySet());
      Collections.sort(inputList, new ChartNameCompare());
      ArrayList<String> charts= new ArrayList<String>(inputList);
      return charts;
   }

   public JFreeChart getjFreechart(String key) {
      return jFreecharts.get(key);
   }

   public InputTab getInputTab() {
      return inputTab;
   }

   public Double getMeanHapFreq() {
      return meanHapFreq;
   }

   public Dimension getHapsDistributionChartSize() {
      return hapsDistributionChartSize;
   }

   public Dimension getMeanHapLengthBarChartSize() {
      return meanHapLengthBarChartSize;
   }

   //called by hapLengthOutputTab
   public Double[] getExpecteds() {
      return expecteds;
   }

   //set by MVController
   public void setExpecteds() {
      this.expecteds = calculateExpecteds();
   }

   //set by InputTab.validateFreqs
   public void setMeanHapFreq(Double meanHapFreq) {
      this.meanHapFreq = meanHapFreq;
   }

   public void setInputTab(InputTab inputTab) {
      this.inputTab = inputTab;
   }

   public void setjFreecharts(String title, JFreeChart jFreechart) {
      jFreecharts.put(title, jFreechart);
   }

   public void clearJFreecharts() {
      jFreecharts.clear();
   }

   public void setOutputPanels(String name, JPanel outputPanel) {
      outputPanels.put(name, outputPanel);
   }

   public JPanel getInputPanels(String name) {
      return inputPanels.get(name);
   }

   public MainWindow getMainWindow() {
      return mainWindow;
   }

   public void setMainWindow(MainWindow mainWindow) {
      this.mainWindow = mainWindow;
   }

   public void setInputPanels(String name, JPanel inputPanel) {
      inputPanels.put(name, inputPanel);
   }

   public JScrollPane getGraphicScrollPane() {
      return graphicScrollPane;
   }

   public void setGraphicScrollPane(JScrollPane graphicScrollPane) {
      this.graphicScrollPane = graphicScrollPane;
   }

   public int getColumnWidth() {
      return columnWidth;
   }

   public JTabbedPane getTabbedPane(String name) {
      return tabbedPanes.get(name);
   }

   public void setTabbedPane(String name, JTabbedPane tabbedPane) {
      tabbedPanes.put(name, tabbedPane);
   }

   private Double getRecomRatio() {
      //Get the mean recombination rate which is the number
      //of recombination
      String[] fieldNames = {"recom0", "recom1", "recom2", "recom3"};
      Double product = 0.0;
      Integer sum = 0;
      for (int i = 0; i < 4; i++) {
         product += i * (Integer) modelValues.get(getCurrentViewName()).get(fieldNames[i]);
         sum += (Integer) modelValues.get(getCurrentViewName()).get(fieldNames[i]);
      }
      Double recomRatio = product / sum;
      return recomRatio;
   }

   private Double[] calculateExpecteds() {
      Double recomRatio = getRecomRatio();
      Integer maxGen = (Integer) modelValues.get(getCurrentViewName()).get("generations");
      Integer popSize = (Integer) modelValues.get(getCurrentViewName()).get("popSize");
      Integer hapCount = (Integer) modelValues.get(getCurrentViewName()).get("noOfHaplotypes");
      Integer familySize = (Integer) modelValues.get(getCurrentViewName()).get("familySize");
      Integer ploidy = (Integer) modelValues.get(getCurrentViewName()).get("ploidy");
      //popSize is number of gametes not individuals
      popSize = popSize / ploidy;
      expecteds = new Double[maxGen + 1];
      Double expected = recomRatio;
      /*Integer selfing = (Integer) values.get("founders");
      if (selfing.equals(1)) {
      expected = recomRatio * p.getMeanHapFreq();
      }*/
      expecteds[2] = expected;
      Double drift = 1.0;
      Double hCount = hapCount * 1.0;
      Double rRatio = recomRatio * getMeanHapFreq();
      /*Effect of Family size
       * Ne = 4N/(var(g) + mg^2 - mg)
       * Where var(g) is variance of number of gametes and mg is mean number of gametes that contribute to each child
       * mg is 2 for a diploid organism.
       * Variance of g for a Poisson distributed family size in a static population is 2 * family size
       * method getVariance illustrates this but is not used by the program.
       * Uncomment command getVariance() from Class constructor to print out calculated values of
       * the variance of g for different family sizes
       */
      Double pSize = 4 * popSize / (2.0 * familySize + 2);

      //Correction to effective population size for genetic drift.
      //Ne declines by (2Ne-1)/2Ne at each generation (Sewall Wright Genetics 16, 97-159 1931).
      Double factor = (2 * pSize - 1) / (2 * pSize * 1.0);

      for (int i = 3; i <= maxGen; i++) {
         drift = drift * factor;
         expected = expected + drift * rRatio;
         expecteds[i] = expected;
      }
      return expecteds;
   }

   /** Instantiate all classes with names ending modelRegEx ("View.class");
    * Assumes constructor takes no parameters
    *
    * Strips "View" suffix from class name and adds remainder of name to
    * ArrayList<String> modelNames
    *
    * Loads all classes instantiated into HashMap<String, Object> viewClasses
    *
    * uses JavaClassLoader package from
    * http://www.javaworld.com/javaworld/javatips/jw-javatip70.html
    * Need to use this as java.lang methods classLoader methods do not like
    * working with jar files JavaClassLoader obtains classes as bytestreams
    */
   public void loadViewClasses() {
      //Get package name
      String packageName = Params.class.getPackage().getName();

      //Get the full absolute path to the Package
      ClassLoader loader = Params.class.getClassLoader();
      URL path = loader.getResource(packageName);
      String jarPath = path.toString();
      //trim path to remove package name that is within jar file
      int endIndex = jarPath.length() - packageName.length() - 2;
      String pathToJarfile = jarPath;
      //If programme runs in a jarfile path will start jar:file:
      //else path will start file
      //either of these need to be trimmed to start with the system dependednt
      //path start
      if (jarPath.startsWith("jar")) {
         pathToJarfile = jarPath.substring(9, endIndex);
      }
      else if (jarPath.startsWith("file")) {
         pathToJarfile = jarPath.substring(5, endIndex);
      }
      // get path including "jar:file:" and trailing "!/"

      String jp = jarPath.substring(0, endIndex + 2);
      //Instantiate the third party JarClassLoader
      //System.out.println("Path:  " + jcl);
      JarClassLoader jarLoader = new JarClassLoader(pathToJarfile);
      //Create regex to search for files ending in "Model.class"
      Pattern pattern = Pattern.compile(modelRegEx);
      Matcher m;

      JarFile jarfile = null;
      try {
         URL url = new URL(jp);
         //Use code from http://www.exampledepot.com/egs/java.net/JarUrl.html
         // to get the jar file and iterate over files in jar file looking
         //for files matching "Model.class"
         JarURLConnection conn = (JarURLConnection) url.openConnection();
         jarfile = conn.getJarFile();

         Enumeration e = jarfile.entries();
         while (e.hasMoreElements()) {
            JarEntry je = (JarEntry) e.nextElement();
            m = pattern.matcher(je.getName());

            if (m.find()) {
               String className = je.getName().substring(0, je.getName().length() - 6);
               className = className.replace("/", ".");
               Class c = jarLoader.loadClass(className, true);
               Object o = c.newInstance();

               //Add new class to hash map of model classes
               //String shortName = je.getName().substring(packageName.length() + 1, je.getName().length() - 6);
               String shortName = o.getClass().getSimpleName();
               shortName = shortName.substring(0, shortName.length() - 4);
               viewNames.add(shortName);
               viewClasses.put(shortName, o);
            }
         }
         jarfile.close();

      }
      catch (Exception e) {
         e.printStackTrace();
      }


   }
}
