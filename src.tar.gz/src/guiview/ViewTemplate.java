
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 *
 * @author harry
 */
public class ViewTemplate {

   protected String name;
   private JPanel card;
   private JPanel inputPanel;
   private JPanel breaksOutputPanel;
   private JPanel hapsOutputPanel;
   private JPanel hapsDistOutputPanel;
   private JPanel hapsLengthOutputPanel;
   protected Params p;

   public ViewTemplate(String name, Params p) {
      this.name = name;
      this.p = p;

      ViewPanel mp = p.getViewPanel();
      mp.setCard(name, getCard(name));
   }

   public ViewTemplate() {
      //create card and add to ModelPanel
   }

   public JPanel getCard(String name) {
      //Create the card.
      card = new JPanel();

      Dimension cardPanelSize = p.getCardPanelSize();
      card.setMinimumSize(cardPanelSize);
      //card.setPreferredSize(cardPanelSize);

      // Add a 5 pixel red border to the panel.
      card.setBorder(BorderFactory.createLineBorder(Color.RED, 5));

      //Create Tabbed Pane
      JTabbedPane tabbedPane = new JTabbedPane();

      tabbedPane.setPreferredSize(cardPanelSize);
      tabbedPane.setBorder(BorderFactory.createLineBorder(Color.CYAN, 5));

      //Populate with Input and Output Panels
      inputPanel = new JPanel(new BorderLayout());
      inputPanel.setPreferredSize(cardPanelSize);
      inputPanel.setBorder(BorderFactory.createLineBorder(Color.PINK, 5));
      tabbedPane.insertTab("INPUT", null, inputPanel, "Model input parameters", 0);

      breaksOutputPanel = new JPanel(new BorderLayout());
      breaksOutputPanel.setPreferredSize(cardPanelSize);
      breaksOutputPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 5));
      tabbedPane.insertTab("Breaks Output", null, breaksOutputPanel, "Break Points Distributions", 1);

      hapsOutputPanel = new JPanel(new BorderLayout());
      hapsOutputPanel.setPreferredSize(cardPanelSize);
      hapsOutputPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));
      tabbedPane.insertTab("Haplotypes Output", null, hapsOutputPanel, "Haplotype Frequencies", 2);
    
      hapsDistOutputPanel = new JPanel(new BorderLayout());
      hapsDistOutputPanel.setPreferredSize(cardPanelSize);
      hapsDistOutputPanel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA, 5));
      tabbedPane.insertTab("Haplotypes Distribution", null, hapsDistOutputPanel, "Haplotypes Distributions", 3);

      hapsLengthOutputPanel = new JPanel(new BorderLayout());
      hapsLengthOutputPanel.setPreferredSize(cardPanelSize);
      hapsLengthOutputPanel.setBorder(BorderFactory.createLineBorder(Color.GREEN, 5));
      tabbedPane.insertTab("Haplotypes Lengths", null, hapsLengthOutputPanel, "Haplotypes Lengths", 4);
    

      card.add(tabbedPane);
      //pass tabbed panes to Params
      p.setInputPanels(name, inputPanel);
      p.setTabbedPane(name, tabbedPane);

      return card;
   }

   public JPanel getInputPanel() {
      return inputPanel;
   }

   public JPanel getBreaksOutputPanel() {
      return breaksOutputPanel;
   }

   public JPanel getHapsOutputPanel() {
      return hapsOutputPanel;
   }




}
