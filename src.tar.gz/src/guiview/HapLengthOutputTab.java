
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.TreeMap;
import javax.swing.BoxLayout;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;

/**
 *
 * @author harry
 */
public class HapLengthOutputTab extends OutputTabTemplate implements Observer {

   private JPanel hapsLengthOutputPanel; //this panel
   private JPanel hapLengthChartContainer;
   private JPanel meanHapsGenerationsChartContainer;
   private GridBagLayout gbag; //Output layout manager
   private GridBagConstraints gbc; //output layout constraints
   private JTextArea taskOutput;
   private Integer noOfHaplotypes;
   private JPanel chartPanel;
   private JFormattedTextField binSizeField;
   private HashMap<Integer, String> hapUnits;

   public HapLengthOutputTab(Params p, String cardName) {
      super.cardName = cardName;
      super.p = p;
      //Get model parameters
      values = p.getModelValues(cardName);
      p.getTabbedPane(cardName).getComponentAt(4).setEnabled(false);
      hapsLengthOutputPanel = (JPanel) p.getTabbedPane(cardName).getComponentAt(4);
      //clear anything left by previous run
      hapsLengthOutputPanel.removeAll();

      //Get data object from model and add observer to be notified of changes
      da = p.getdArray();
      hapsLengthOutputPanel.setLayout(gbag);
      da.addObserver(this);
      //Set up gridbag layout
      gbag = new GridBagLayout();
      gbc = new GridBagConstraints();
      hapsLengthOutputPanel.setLayout(gbag);
      chartPanel = new JPanel();
      chartPanel.setLayout(new BoxLayout(chartPanel, BoxLayout.PAGE_AXIS));

      //Panel for Column chart of mean hap length forr each haplotype
      hapLengthChartContainer = new JPanel();
      hapLengthChartContainer.setPreferredSize(p.getMeanHapLengthBarChartSize());
   }

   //Listener on DataArray which signals when run complete
   public void update(Observable dArray, Object dA) {
      if (da == dArray) {
         if (dA.equals("jobDone")) {

            updatePlots(da.getBinSize());
         }
      }
   }

   private void updatePlots(Integer binSize) {
      noOfHaplotypes = (Integer) values.get("noOfHaplotypes");
      //ArrayList<ArrayList<Double>> chrMeanBreaks = da.getChrMeanBreaks();
      Double recomRatio = getRecomRatio();
      hapsLengthOutputPanel.removeAll();
      chartPanel.removeAll();

      HashMap<Integer, HashMap<Integer, Double>> meanHapLengths = da.getMeanHapLengthGenerations();
      HashMap<Integer, HashMap<Integer, Double>> stdHapLengths = da.getStdHapLengthGenerations();

      getHapsLengthPlot(meanHapLengths, stdHapLengths, noOfHaplotypes);
      for (int hap = 0; hap < noOfHaplotypes; hap++) {
         getHapsLengthPlot(meanHapLengths, stdHapLengths, hap);
      }
      //Dimension chartSize = p.getBreaksDistributionChartSize();

      chartPanel.setBorder(border);
      chartPanel.setVisible(true);
      // chartPanel.repaint();
      // chartPanel.setPreferredSize(chartSize);
      // chartPanel.revalidate();

      JScrollPane scrollPane = new JScrollPane(chartPanel);
      //scrollPane.add(chartPanel);
      scrollPane.setBorder(border);
      scrollPane.setViewportView(chartPanel);
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;

      gbc.insets = new Insets(5, 5, 5, 5);
      gbc.fill = GridBagConstraints.BOTH;
      hapsLengthOutputPanel.add(scrollPane, gbc);
      hapsLengthOutputPanel.revalidate();
      hapsLengthOutputPanel.repaint();
      hapsLengthOutputPanel.setVisible(true);


      hapsLengthOutputPanel.setEnabled(true);

   }

   public void getHapsLengthPlot(HashMap<Integer,HashMap<Integer, Double>> mean,
         HashMap<Integer,HashMap<Integer, Double>> std, Integer hap) {
      hap++;
      HashMap<String, String> legend = new HashMap<String, String>(3);
      if (hap.equals(noOfHaplotypes + 1)) {
         legend.put("title", "Mean and Standard Deviation of Length of all Haplotypes");
      }
      else {
         legend.put("title", "Mean and Standard Deviation of Length of Haplotype " + hap);

      }
      legend.put("category", "Generation");
      legend.put("value", "Mean hap Length");
      legend.put("setBaseShapesVisible", "false");
      legend.put("Xaxis", "Generation");
      legend.put("Yaxis", "Mean Hap Length (+/- SD of Replicates)");

      //Transfer data to DataSet object for use JFreeChart
      YIntervalSeriesCollection dataset = new YIntervalSeriesCollection();
      YIntervalSeries series1 = new YIntervalSeries("Expected");
      YIntervalSeries series2 = new YIntervalSeries("Haplotype Length");
      YIntervalSeries series3 = new YIntervalSeries("Haplotype Standard Deviation");
      /*     Integer modulus = list.size() / 10;
      if (modulus < 1) {
      modulus = 1;
      }*/
      expecteds = p.getExpecteds();
      Integer chrLength = (Integer) p.getModelValues(cardName).get("chrLength");
      TreeMap meanMap = new TreeMap(mean);
      //System.out.println("Hap: " + hap + "; Chr length: " + chrLength);

      Iterator iterator = meanMap.keySet().iterator();
      hap = hap - 1;
      while (iterator.hasNext()){
      //for (Integer gen = 2; gen < 10; gen++){
         Integer gen = (Integer) iterator.next();

           Double expected = chrLength / (expecteds[gen] + 1);
         series1.add(gen, expected, expected, expected);
         //Add observed values
           /* if (i % modulus == 0 || i == list.size() - 1) {
         series2.add(list.get(i).get(0), list.get(i).get(1), list.get(i).get(1) - chrStdDev.get(i).get(1), list.get(i).get(1) + chrStdDev.get(i).get(1));
         }
         else {*/
         series2.add(gen, mean.get(gen).get(hap), mean.get(gen).get(hap), mean.get(gen).get(hap));
         //}
         series3.add(gen, std.get(gen).get(hap), std.get(gen).get(hap), std.get(gen).get(hap));
      }

      //dataset.addSeries(series1);
      dataset.addSeries(series2);
      dataset.addSeries(series3);
      XYplot hapLengthPlot = new XYplot(p);
      chartPanel.add(hapLengthPlot.createErrorBarChart(dataset, legend));

   }
}

