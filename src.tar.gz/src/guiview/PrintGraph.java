/*
 * Code downloaded from http://dolf.trieschnigg.nl/jfreechart/
 * and amended by harry
 */
package guiview;

import java.awt.Rectangle;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import javax.swing.JFrame;
import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.SVGGraphics2D;
import org.jfree.chart.JFreeChart;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;

/**
 *
 * @author harry
 */
public class PrintGraph {

   private JFrame jFrame;

   public PrintGraph(JFrame jFrame) {
      this.jFrame = jFrame;

   }

   public void exportFigure(Params p, String chartName, File svgFile) {

     JFreeChart jfreechart = p.getjFreechart(chartName);
      // write it to file
      try {
         exportChartAsSVG(jfreechart,
               jFrame.getContentPane().getBounds(), svgFile);

         // TODO: notify the user the file has been saved (e.g. status bar)
         //System.out.println("Figured saved as " + svgFile.getAbsolutePath());

      }
      catch (IOException e) {
         System.err.println("Error saving file:\n" + e.getMessage());
      }
   }

   /**
    * Exports a JFreeChart to a SVG file.
    *
    * @param chart JFreeChart to export
    * @param bounds the dimensions of the viewport
    * @param svgFile the output file.
    * @throws IOException if writing the svgFile fails.
    */
   private void exportChartAsSVG(JFreeChart chart, Rectangle bounds, File svgFile) throws IOException {
      // Get a DOMImplementation and create an XML document
      DOMImplementation domImpl =
            GenericDOMImplementation.getDOMImplementation();
      Document document = domImpl.createDocument(null, "svg", null);

      // Create an instance of the SVG Generator
      SVGGraphics2D svgGenerator = new SVGGraphics2D(document);

      // draw the chart in the SVG generator
      chart.draw(svgGenerator, bounds);

      // Write svg file
      OutputStream outputStream = new FileOutputStream(svgFile);
      Writer out = new OutputStreamWriter(outputStream, "UTF-8");
      svgGenerator.stream(out, true /* use css */);
      outputStream.flush();
      outputStream.close();
   }
}
