
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Creates Frame for GUI and adds drop down menus
 */
package guiview;

import controller.MVController;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

//import haplotypesimulator.RunSimulation;
public class MainWindow extends JFrame implements ActionListener {

   private Params p;
   private ViewPanel vp;
   private final JButton jbtnStart;
   private final JButton jbtnCancel;
   private PrintGraph graphPrinter;
   //private Action exportFigure;
   private String newline = String.format("%n");
   // private HashMap<String, JFreeChart> jFreecharts;
   private JMenu fileSubmenu;
   private JFileChooser fc;
   private MVController mvc;
   private final String PRINT_TABLES = "Print Tables";
   static String separator = File.separator;

   //JFrame jfrm;
   public MainWindow(Params p, MVController mvc) {

      jbtnStart = new JButton("Start");
      jbtnCancel = new JButton("Cancel");
      this.p = p;
      this.mvc = mvc;
      //File chhoser for saving files
      String dir1 = System.getProperty("user.dir");
      try {
         dir1 = new File(".").getCanonicalPath();
      }
      catch (IOException ex) {
         Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
      }
      //Use a global file chooser so that it remembers file locations between accesses
      //pass file path as argument so that chooser opens from current location
      fc = new JFileChooser(dir1);


   }

   public void buildMainWindow() {

      // Create a new JFrame container.
      //JFrame jfrm = new JFrame("Haplotype Simulator");


      // Specify Gridbag layout manager.
      GridBagLayout gbag = new GridBagLayout();
      GridBagConstraints gbc = new GridBagConstraints();
      this.setLayout(gbag);
      //jfrm.setLayout(new BorderLayout());

      // Give the frame an initial size.
      this.setSize(p.getFrameSize());

      // Terminate the program when the user closes the application.
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      //Get Lowerpanel
      vp = p.getViewPanel();

      //Get static upper panel
      JPanel jpnlTop = getTopPanel();

      JMenuBar menuBar = getThisMenuBar();

      // Set coordinates in gridbag and Add the panels to the frame.
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.weightx = 1.0; //top panel resizes horizontally but not vertically
      gbc.weighty = 0.0;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      this.add(jpnlTop, gbc);
      gbc.weightx = 1.0; //lower panel resizes horizontally anf vertically
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.gridx = 0;
      gbc.gridy = 1;
      this.add(vp.getPanel(), gbc);
      this.setJMenuBar(menuBar);
      // Display the frame.
      this.setVisible(true);
      //initalise object for printing svg graphs
      graphPrinter = new PrintGraph(this);
   }

   private JPanel getTopPanel() {
      // Create the Top JPanel.
      JPanel jpnlTop = new JPanel();
      // Set the preferred size of the Top panel.
      jpnlTop.setPreferredSize(p.getTopPanelSize());

      // Make the panel opaque.
      jpnlTop.setOpaque(true);

      // Specify BorderLayout manager.
      jpnlTop.setLayout(new BorderLayout());

      // Add a 5 pixel blue border to the panel.
      jpnlTop.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));

      //get boxes with controls
      Box buttonBox = getTopPanelButtonBox();
      Box modelBox = getModelBox();

      // Add the control boxes to the panel.
      jpnlTop.add(buttonBox, BorderLayout.EAST);
      jpnlTop.add(modelBox, BorderLayout.WEST);

      //Add the opening screen
      CardLayout cl = (CardLayout) (vp.getPanel().getLayout());
      cl.show(vp.getPanel(), p.getDefaultViewName());
      //Pass cardname to params so appropriate set of values
      //can be passed to model
      p.setCurrentViewName(p.getDefaultViewName());

      return jpnlTop;

   }

   public void disableStartButton() {
      jbtnStart.setEnabled(false);
   }

   public void enableStartButton() {
      jbtnStart.setEnabled(true);
      ArrayList<String> jFreecharts = p.getjFreechartsKeySet();
      fileSubmenu.removeAll();

      for (String key : jFreecharts) {

         JMenuItem menuItem = new JMenuItem(key);
         menuItem.addActionListener(this);
         fileSubmenu.add(menuItem);
      }

   }

   private Box getTopPanelButtonBox() {

      // Make two buttons.
      Box buttonBox = Box.createHorizontalBox();
      buttonBox.add(jbtnStart);
      buttonBox.add(jbtnCancel);

      return buttonBox;

   }

   //Called by controller.MVController
   public void addButtonActionListeners(ActionListener al) {
      jbtnStart.setActionCommand("start");
      jbtnStart.addActionListener(al);
      jbtnCancel.setActionCommand("cancel");
      jbtnCancel.addActionListener(al);
   }

   //Get combo list of available models
   private Box getModelBox() {
      ArrayList<String> models = p.getViewNames();
      String[] modelList = new String[models.size()];
      modelList[0] = "Demonstration";
      int i = 1;
      for(String m : models) {        
         if (!m.contentEquals("IntercrossDemo")) {
            modelList[i] = m;
            i++;
         }
      }
      //String[] modelList = (String[])models.toArray();
      Box modelBox = Box.createVerticalBox();
      final JComboBox combo = new JComboBox(modelList);
      modelBox.add(combo);

      combo.addItemListener(new ItemListener() {

         //Event listener for changes to parameters on input panel
         public void itemStateChanged(ItemEvent evt) {
            CardLayout cl = (CardLayout) (vp.getPanel().getLayout());
            String item = (String) evt.getItem();
            if(item.equals("Demonstration")){
                item = "IntercrossDemo";
            }
            cl.show(vp.getPanel(), item);
            //Pass cardname to params so appropriate set of values
            //can be passed to model
            p.setCurrentViewName(item);
         }
      });

      return modelBox;
   }

// Returns just the class name -- no package info.
   protected String getClassName(Object o) {
      String classString = o.getClass().getName();
      int dotIndex = classString.lastIndexOf(".");
      return classString.substring(dotIndex + 1);
   }

   //Action for selection of Files.
   //Does not check what action was performed so may conflict with other action events
   public void actionPerformed(ActionEvent e) {
      // System.out.println("Class of action event: " + e.getSource().getClass().toString());
      JMenuItem source = (JMenuItem) (e.getSource());

      if (source.getText().equalsIgnoreCase(PRINT_TABLES)) {
         FileNameFilter txtFilter = new FileNameFilter();
         txtFilter.setFilterString(".txt");
         fc.addChoosableFileFilter(txtFilter);
         //fc.setAcceptAllFileFilterUsed(false);
         int returnVal = fc.showSaveDialog(source);
         if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            file = checkFileExtension(file, ".txt");

            //mvc.printTables calls printToFile method in haplotypesimulator.RunSimulation
            mvc.printTables(file.getAbsolutePath().toString());
         }
      }
      else {
         //Assume that a plot will be printed
         FileNameFilter svgFilter = new FileNameFilter();
         svgFilter.setFilterString(".svg");
         fc.addChoosableFileFilter(svgFilter);
         //fc.setAcceptAllFileFilterUsed(false);

         int returnVal = fc.showSaveDialog(fileSubmenu);
         if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            file = checkFileExtension(file, ".svg");

            //System.out.println("Printed file: " + file.getName().toString());
            graphPrinter.exportFigure(p, source.getText(), file);
         }
      }
   }

   private File checkFileExtension(File file, String extension) {
      //This should make sure that file has a .svg extension but although
      if (!file.getName().endsWith(extension)) {
         File newFile = new File(file.getAbsolutePath() + extension);
         return newFile;
      }
      return file;
   }

   private JMenuBar getThisMenuBar() {
      //Where the GUI is created:
      JMenuBar menuBar;

      JMenuItem menuItem;
      //JRadioButtonMenuItem rbMenuItem;
      //JCheckBoxMenuItem cbMenuItem;

      //Create the menu bar.
      menuBar =
            new JMenuBar();

      //Build the file menu for export of SVG files.
      JMenu fileMenu = new JMenu("File");
      //a submenu for each plot type
      fileMenu.addSeparator();
      fileSubmenu =
            new JMenu("Print Plot");
      fileSubmenu.setMnemonic(KeyEvent.VK_S);
      //fileSubmenu.addItemListener(this);
      //Items add to subMenu in enableStartButton
      fileMenu.add(fileSubmenu);
      menuItem = new JMenuItem(PRINT_TABLES);
      menuItem.addActionListener(this);
      fileMenu.add(menuItem);
      menuBar.add(fileMenu);
      return menuBar;



      /*     menu = new JMenu("A Menu");
      menu.setMnemonic(KeyEvent.VK_A);
      menu.getAccessibleContext().setAccessibleDescription(
      "The only menu in this program that has menu items");
      menuBar.add(menu);

      //a group of JMenuItems
      menuItem = new JMenuItem("A text-only menu item",
      KeyEvent.VK_T);
      menuItem.setAccelerator(KeyStroke.getKeyStroke(
      KeyEvent.VK_1, ActionEvent.ALT_MASK));
      menuItem.getAccessibleContext().setAccessibleDescription(
      "This doesn't really do anything");
      menu.add(menuItem);

      menuItem = new JMenuItem("Both text and icon",
      new ImageIcon("images/middle.gif"));
      menuItem.setMnemonic(KeyEvent.VK_B);
      menu.add(menuItem);

      menuItem = new JMenuItem(new ImageIcon("images/middle.gif"));
      menuItem.setMnemonic(KeyEvent.VK_D);
      menu.add(menuItem);

      //a group of radio button menu items
      menu.addSeparator();
      ButtonGroup group = new ButtonGroup();
      rbMenuItem = new JRadioButtonMenuItem("A radio button menu item");
      rbMenuItem.setSelected(true);
      rbMenuItem.setMnemonic(KeyEvent.VK_R);
      group.add(rbMenuItem);
      menu.add(rbMenuItem);

      rbMenuItem = new JRadioButtonMenuItem("Another one");
      rbMenuItem.setMnemonic(KeyEvent.VK_O);
      group.add(rbMenuItem);
      menu.add(rbMenuItem);

      //a group of check box menu items
      menu.addSeparator();
      cbMenuItem = new JCheckBoxMenuItem("A check box menu item");
      cbMenuItem.setMnemonic(KeyEvent.VK_C);
      menu.add(cbMenuItem);

      cbMenuItem = new JCheckBoxMenuItem("Another one");
      cbMenuItem.setMnemonic(KeyEvent.VK_H);
      menu.add(cbMenuItem);

      //a submenu
      menu.addSeparator();
      submenu = new JMenu("A submenu");
      submenu.setMnemonic(KeyEvent.VK_S);

      menuItem = new JMenuItem("An item in the submenu");
      menuItem.setAccelerator(KeyStroke.getKeyStroke(
      KeyEvent.VK_2, ActionEvent.ALT_MASK));
      submenu.add(menuItem);

      menuItem = new JMenuItem("Another item");
      submenu.add(menuItem);
      menu.add(submenu);

      //Build second menu in the menu bar.
      menu = new JMenu("Another Menu");
      menu.setMnemonic(KeyEvent.VK_N);
      menu.getAccessibleContext().setAccessibleDescription(
      "This menu does nothing");
      menuBar.add(menu);
      return menuBar;
       * */

   }
}

