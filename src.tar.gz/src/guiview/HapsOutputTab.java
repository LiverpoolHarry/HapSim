
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import org.jfree.data.statistics.DefaultStatisticalCategoryDataset;

/**
 *
 * @author harry
 */
public class HapsOutputTab extends OutputTabTemplate implements Observer {

   private JPanel hapsOutputPanel; //this panel
   private JPanel meanHapsDistributionChartContainer;
   private JPanel meanHapsGenerationsChartContainer;
   private GridBagLayout gbag; //Output layout manager
   private GridBagConstraints gbc; //output layout constraints
   private JTextArea taskOutput;

   public HapsOutputTab(Params p, String cardName) {

      super.cardName = cardName;
      super.p = p;
      //Get model parameters
      values = p.getModelValues(cardName);
      p.getTabbedPane(cardName).getComponentAt(2).setEnabled(false);
      hapsOutputPanel = (JPanel) p.getTabbedPane(cardName).getComponentAt(2);
      //clear anything left by previous run
      hapsOutputPanel.removeAll();

      //Get data object from model and add observer to be notified of changes
      da = p.getdArray();
      hapsOutputPanel.setLayout(gbag);
      da.addObserver(this);
      //Set up gridbag layout
      gbag = new GridBagLayout();
      gbc = new GridBagConstraints();
      hapsOutputPanel.setLayout(gbag);



      //Panel for Column chart of mean hap length forr each haplotype
      meanHapsDistributionChartContainer = new JPanel();
      meanHapsDistributionChartContainer.setPreferredSize(p.getMeanHapLengthBarChartSize());


   }

   //Listener on DataArray which signals when run complete
   public void update(Observable dArray, Object dA) {
      if (da == dArray) {
         if (dA.equals("jobDone")) {
            Integer hapCount = (Integer) values.get("noOfHaplotypes");

            getMeanHapsLengthPlot();
            getMeanFreqsPlot();
            p.getTabbedPane(cardName).getComponentAt(2).setEnabled(true);
            //switch to output panel at end of run unless a demo showing chromosome
            // diagrams
         }
      }
   }

   public void getMeanHapsLengthPlot() {


      Integer chrLength = (Integer) values.get("chrLength");

      HashMap<String, String> legend = new HashMap<String, String>(3);
      String plotTitle = "Mean Haplotype Lengths ";
      if(p.getCurrentViewName().contentEquals("Introgression")){
         plotTitle = "Mean Haplotype Lengths (Donor = haplotype 1)";
      }
      legend.put("title", plotTitle);
      legend.put("category", "Haplotype");
      legend.put("value", "Length \n (+/- Std Err of Replicates)");

      HashMap<String, Boolean> legendParams = new HashMap<String, Boolean>();
      legendParams.put("includeLegend", true);

      legend.put("setBaseShapesVisible", "false");
      legend.put("Xaxis", "Haplotypes");
      legend.put("Yaxis", "Mean Haps (Error bars = stdev)");

      HashMap<Integer, Double> meanHapLengths = da.getMeanHapLength();

      HashMap<Integer, Double> stdHapLengths = da.getStdHapLength();
      //Get standard error of replicates
      HashMap<Integer, Double> stdErrHapLengths = da.getStdErrHapLength();

      Integer hapCount = (Integer) values.get("noOfHaplotypes");
      //Transfer data to DataSet object for use JFreeChart
      DefaultStatisticalCategoryDataset dataset = new DefaultStatisticalCategoryDataset();
      Double error = 0.0;
      for (int i = 0; i < hapCount; i++) {
         Integer hap = i + 1;

         dataset.add(meanHapLengths.get(i), stdErrHapLengths.get(i), "Mean", hap.toString());
         dataset.add(Math.sqrt(stdHapLengths.get(i)), null, "Std Dev", hap.toString());
      }
      dataset.add(meanHapLengths.get(hapCount), stdErrHapLengths.get(hapCount), "Mean", "Mean");
      dataset.add(Math.sqrt(stdHapLengths.get(hapCount)), null, "Std Dev", "Mean");

      XYplot barChart = new XYplot(p);
      JPanel chartPanel = barChart.createBarChart(dataset, legend, legendParams);

      chartPanel.setPreferredSize(p.getMeanHapLengthBarChartSize());
      chartPanel.setBorder(border);
      chartPanel.setVisible(true);
      chartPanel.repaint();


      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;


      gbc.insets = new Insets(5, 5, 5, 5);
      gbc.fill = GridBagConstraints.BOTH;

      hapsOutputPanel.add(chartPanel, gbc);

   }

   public void getMeanFreqsPlot() {


      Integer chrLength = (Integer) values.get("chrLength");

      HashMap<String, String> legend = new HashMap<String, String>(3);
      String plotTitle = "Mean Haplotype Abundance ";
      if(p.getCurrentViewName().contentEquals("Introgression")){
         plotTitle = "Mean Haplotype Abundance (Donor = haplotype 1)";
      }

      legend.put("title", plotTitle);
      legend.put("category", "Haplotype");
      legend.put("value", "Frequency \n (+/-Std Err of Replicates)");

      HashMap<String, Boolean> legendParams = new HashMap<String, Boolean>();
      legendParams.put("includeLegend", false);
      legend.put("setBaseShapesVisible", "false");
      legend.put("Xaxis", "Haplotypes");
      legend.put("Yaxis", "Mean Haps (Error bars = stdev)");

      HashMap<Integer, Double> meanHapFreqs = da.getMeanHapFreqs();
      //HashMap<Integer, Double> stdErrHapLengths = da.getStdErrHapLength();
      HashMap<Integer, Double> stdErrHapFreqs = da.getStdErrHapFreqs();
      Integer hapCount = (Integer) values.get("noOfHaplotypes");
      //Transfer data to DataSet object for use JFreeChart
      DefaultStatisticalCategoryDataset dataset = new DefaultStatisticalCategoryDataset();
      Double error = 0.0;
      for (int i = 0; i < hapCount; i++) {
         Integer hap = i + 1;
         dataset.add(meanHapFreqs.get(i), stdErrHapFreqs.get(i), "", hap.toString());
      }

      XYplot barChart = new XYplot(p);
      JPanel chartPanel = barChart.createBarChart(dataset, legend, legendParams);

      chartPanel.setPreferredSize(p.getMeanHapLengthBarChartSize());
      chartPanel.setBorder(border);
      chartPanel.setVisible(true);
      chartPanel.repaint();


      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;


      gbc.insets = new Insets(5, 5, 5, 5);
      gbc.fill = GridBagConstraints.BOTH;

      hapsOutputPanel.add(chartPanel, gbc);

   }
}

