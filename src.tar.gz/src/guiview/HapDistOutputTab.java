
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.jfree.data.xy.IntervalXYDataset;

/**
 *
 * @author harry
 */
public class HapDistOutputTab extends OutputTabTemplate implements Observer {

   private JPanel hapsDistOutputPanel; //this panel
   private JPanel meanHapsDistributionChartContainer;
   private JPanel meanHapsGenerationsChartContainer;
   private GridBagLayout gbag; //Output layout manager
   private GridBagConstraints gbc; //output layout constraints
   private JTextArea taskOutput;
   private Integer noOfHaplotypes;
   private JPanel chartPanel;
   private JFormattedTextField binSizeField;
   private HashMap<Integer, String> hapUnits;

   public HapDistOutputTab(Params p, String cardName) {
      super.cardName = cardName;
      super.p = p;
      //Get model parameters
      values = p.getModelValues(cardName);
      p.getTabbedPane(cardName).getComponentAt(3).setEnabled(false);
      hapsDistOutputPanel = (JPanel) p.getTabbedPane(cardName).getComponentAt(3);
      //clear anything left by previous run
      hapsDistOutputPanel.removeAll();

      //Get data object from model and add observer to be notified of changes
      da = p.getdArray();
      hapsDistOutputPanel.setLayout(gbag);
      da.addObserver(this);
      //Set up gridbag layout
      gbag = new GridBagLayout();
      gbc = new GridBagConstraints();
      hapsDistOutputPanel.setLayout(gbag);
      chartPanel = new JPanel();
      chartPanel.setLayout(new BoxLayout(chartPanel, BoxLayout.PAGE_AXIS));

      //Panel for Column chart of mean hap length forr each haplotype
      meanHapsDistributionChartContainer = new JPanel();
      meanHapsDistributionChartContainer.setPreferredSize(p.getMeanHapLengthBarChartSize());
      hapUnits = new HashMap<Integer, String>(10);
      hapUnits.put(10000000, "10Mb");
      hapUnits.put(1000000, "1Mb");
      hapUnits.put(100000, "100Kb");
      hapUnits.put(10000, "10Kb");
      hapUnits.put(1000, "1Kb");
      hapUnits.put(100, "100bp");
      hapUnits.put(10, "10bp");

   }

   //Listener on DataArray which signals when run complete
   public void update(Observable dArray, Object dA) {
      if (da == dArray) {
         if (dA.equals("jobDone")) {

            updatePlots(da.getBinSize());
         }
      }
   }

   private void updatePlots(Integer binSize) {
      noOfHaplotypes = (Integer) values.get("noOfHaplotypes");
      //ArrayList<ArrayList<Double>> chrMeanBreaks = da.getChrMeanBreaks();
      Double recomRatio = getRecomRatio();
      hapsDistOutputPanel.removeAll();
      chartPanel.removeAll();

      chartPanel.add(getBinSizePanel(binSize));
      HashMap<Integer, HashMap<Integer, Double>> meanHapDistribution = da.getMeanHapDistribution();
      getHapsDistPlot(meanHapDistribution.get(noOfHaplotypes), noOfHaplotypes, binSize);
      for (int hap = 0; hap < noOfHaplotypes; hap++) {
         getHapsDistPlot(meanHapDistribution.get(hap), hap, binSize);
      }
      Dimension chartSize = new Dimension(meanHapDistribution.get(noOfHaplotypes).size() * 10, 600 * noOfHaplotypes);

     // chartPanel.setBorder(border);
     // chartPanel.setVisible(true);
     // chartPanel.repaint();
     // chartPanel.setPreferredSize(chartSize);
     // chartPanel.revalidate();

      JScrollPane scrollPane = new JScrollPane(chartPanel);
      //scrollPane.add(chartPanel);
      scrollPane.setBorder(border);
      scrollPane.setViewportView(chartPanel);
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;

      gbc.insets = new Insets(5, 5, 5, 5);
      gbc.fill = GridBagConstraints.BOTH;
      hapsDistOutputPanel.add(scrollPane, gbc);
      hapsDistOutputPanel.revalidate();
      hapsDistOutputPanel.repaint();
      hapsDistOutputPanel.setVisible(true);


      p.getTabbedPane(cardName).getComponentAt(3).setEnabled(true);

   }

   public void getHapsDistPlot(HashMap<Integer, Double> distPlot, Integer hap, Integer binSize) {
      hap++;
      HashMap<String, String> legend = new HashMap<String, String>(3);
      if (hap.equals(noOfHaplotypes + 1)) {
         legend.put("title", "Length Distribution For Sum of all Haplotypes  ");
      }
      else {
         legend.put("title", "Length Distribution For Haplotype " + hap);

      }
      legend.put("category", "Haplotype Length");
      legend.put("value", "Count");

      HashMap<String, Boolean> legendParams = new HashMap<String, Boolean>();
      legendParams.put("includeLegend", false);

      legend.put("setBaseShapesVisible", "false");
      String hapUnit = " ";
      if (hapUnits.containsKey(binSize)) {
         hapUnit = hapUnits.get(binSize);
      }
      else {
         hapUnit = binSize.toString() + " bp";
      }
      legend.put("Xaxis", "Haplotype Length (Interval size = " + hapUnit + ")");
      legend.put("Yaxis", "Count Haps");

      //Transfer data to DataSet object for use JFreeChart
      IntervalXYDataset series1 = createDataset(distPlot, "Simulated");

      Integer chrLength = (Integer) values.get("chrLength");

      Double meanBreaks = da.getMeanBreaks().get("mean") * binSize / chrLength;
      Double hapCount = da.getHapCounts().get(hap - 1);

      HashMap<Integer, Double> series2Data = getExponentialExpected(distPlot.size(), meanBreaks, hapCount);
      IntervalXYDataset series2 = createDataset(series2Data, "Expected (Exponential Distribution)");


      XYplot barChart = new XYplot(p);

      chartPanel.add(barChart.createOverlaidXYPlot(series1, series2, legend));
   }

   private JPanel getBinSizePanel(Integer binSize) {
      JPanel binSizePanel = new JPanel();
      JButton jbtnUpdate = new JButton("Update Interval Size");
      jbtnUpdate.addActionListener(new ButtonListener());
      // Set the preferred size of the Top panel.
      //binSizePanel.setPreferredSize(new Dimension());
      // Make the panel opaque.
      binSizePanel.setOpaque(true);

      // Specify BorderLayout manager.
      //.setLayout(new BorderLayout());

      // Add a 5 pixel blue border to the panel.
      binSizePanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));

      JLabel binSizeLabel = new JLabel("Change size of histogram interval (bp)");
      binSizeField = new JFormattedTextField(NumberFormat.getIntegerInstance());

      binSizeField.setSize(250, 15);
      binSizeField.setValue(binSize);

      binSizePanel.add(binSizeLabel);
      binSizePanel.add(binSizeField);
      binSizePanel.add(jbtnUpdate);
      binSizePanel.add(new JLabel("           "));//packing

      return binSizePanel;
   }

   //set up listener of update buttons
   public class ButtonListener implements ActionListener {

      public void actionPerformed(ActionEvent ae) {
         Long bs = (Long) binSizeField.getValue();
         int binS = bs.intValue();
         Integer binCount = (Integer) values.get("chrLength") / binS;
         if (checkBinCount(binCount)) {
            da.setHapDistribution(binS);
            updatePlots(binS);
         }
      }
   }

   private boolean checkBinCount(Integer binCount) {
      boolean returnValue = true;
      if (binCount > 300) {
         returnValue = false;
         JOptionPane.showMessageDialog(hapsDistOutputPanel,
               "The number of columns in the histogram (" + binCount + ") \n exceeds the maximum allowed (300)",
               "Fatal Error",
               JOptionPane.ERROR_MESSAGE);
      }
      return returnValue;
   }
}

