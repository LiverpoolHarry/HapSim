
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import dataAnalysis.DataArray;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

/**
 *
 * @author harry
 */
public class IntercrossDemoView extends ViewTemplate implements Observer {

   private JPanel inputPanel;
   private Graphics graphic;
   private HashMap<String, Object> values;
   private int downSet = 200;
   private DataArray dArray;
   private InputTab input;

   public IntercrossDemoView(String name, Params p) {
      super(name, p);
      //Get and set the card with tabbed panes
      //getCard is a method of the parent class that creates a card panel with two tabbed panes
      p.getViewPanel().setCard(name, getCard(name));
      //Pass the name of the model to params for incorporation in combo box list
      //MainWindow.p.setModelNames(name);
      //pass output panel up to Params
      p.setOutputPanels(name, getBreaksOutputPanel());
      setIntercrossDemoPanel();


   }

   public IntercrossDemoView() {
      name = "IntercrossDemo";
      p = Params.p;

      //Get and set the card with tabbed panes
      //getCard is a method of the parent class that creates a card panel with two tabbed panes
      p.getViewPanel().setCard(name, getCard(name));
      //pass output panel up to Params
      p.setOutputPanels(name, getBreaksOutputPanel());

      setIntercrossDemoPanel();


   }

   private void setIntercrossDemoPanel() {
      inputPanel = getInputPanel();
      inputPanel.setLayout(new BorderLayout());
      //Initialise class which defines text fields
      input = new InputTab(p, name);
      input.addObserver(this);
      //Add non standard text field to specify interval between generations
      Integer defaultDelay = 1;
      Integer minDelay = 0;
      Integer maxDelay = 500;
      input.addTextField("delay", "Number of seconds between displaying demonstration chromosomes",
            defaultDelay, "Delay between generations (s)", minDelay, maxDelay);

      //Modify defaults
      input.setDefaultValue("generations", 10);
      input.setDefaultValue("chrLength", 400);
      input.setDefaultValue("replicateCount", 1);
      input.setDefaultValue("delay", 0);
      input.setDefaultValue("ploidy", 2);

      //Modify some minimum and maximum permitted values
      input.setMinMaxValues("generations", 2, 10);
      input.setMinMaxValues("initialPopSize", 4, 200);
      input.setMinMaxValues("noOfHaplotypes", 2, 10);

      //List of names of fields required for this wimdow
      String[] fieldNames = {"generations", "initialPopSize", "noOfHaplotypes"};

      //Get the text fields and labels this will initialise HashMap of field values
      HashMap<String, JLabel> labels = input.getFieldLabels();
      HashMap<String, JFormattedTextField> textFields = input.getTextFields();



      //Header for text fields
      Box headerBox = Box.createVerticalBox();
      JLabel header = new JLabel("Parameters of Intercross Model");
      header.setFont(p.getHeaderFont());
      headerBox.add(header);
      JLabel warning = new JLabel("<html><p>This is a restricted version of the full programme, <br>" +
            "select a process to model in the combo box above.<br>" +
            "The full programmes have additional parameters <br>and can use a wider range of input values.</p></html>");
      headerBox.add(warning);

      //Put list of textfields into box layout
      Box inputBox = Box.createVerticalBox();
      inputBox.setBorder(BorderFactory.createEtchedBorder(0));
      Dimension boxSize = new Dimension(300, 300);
      inputBox.setBounds(5, 40, 300, 300);
      for (String fieldName : fieldNames) {
         inputBox.add(labels.get(fieldName));
         inputBox.add(textFields.get(fieldName));
      }

      //Get box layout containing recombination ratios
      JPanel ratioPanel = input.getRatioBox();
      Box ratioBox = Box.createVerticalBox();
      ratioPanel.setSize(boxSize);
      ratioBox.setSize(boxSize);
      ratioBox.setBounds(5, 320, 600, 300);
      ratioBox.add(ratioPanel);
      //Add boxes to JPanel
      Box fieldsBox = Box.createVerticalBox();

      fieldsBox.setBorder(BorderFactory.createLineBorder(Color.black));
      fieldsBox.add(headerBox);
      fieldsBox.add(inputBox);
      //fieldsBox.add(ratioBox);
      inputPanel.add(fieldsBox, BorderLayout.WEST);
      //set hash of default counts of each haplotype
      input.getHapFreqs();

      //Add a scrollPane for graphics of chromosomes
      String label = "<html>The programme simulates the process of haplotypes being divided into ever smaller fragments by recombination.<br><br>" +
            " Press Start to view a demonstration of the simulation process.<br><br>" +
            " Summary statistics of the simulated number of breaks between founder haplotypes are shown in the OUTPUT tab. <br><br>" +
            " Use the combo box to select a process to simulate</html>";
      JLabel instruction = new JLabel(label);
      //Forces label text to wrap
      instruction.setPreferredSize(new Dimension(1, 1));
      instruction.setFont(p.getHeaderFont());
      instruction.setVerticalAlignment(JLabel.TOP);

      //creates margin for label
      Border labelBorder = BorderFactory.createEmptyBorder(0, 20, 0, 20);

      instruction.setBorder(labelBorder);
      JScrollPane graphicScrollPane = new JScrollPane();
      graphicScrollPane.getViewport().setBackground(Color.LIGHT_GRAY);

      graphicScrollPane.setViewportView(instruction);
      p.setGraphicScrollPane(graphicScrollPane);
      inputPanel.add(graphicScrollPane);

   }

   //Observer for changes in number of haplotypes so that number of boxes
   //for haplotype frequencies can be changed.
   //Observes observable in InputTab
   public void update(Observable in, Object field) {
      if (in == input) {
         if (field.equals("noOfHaplotypesChanged")) {
            input.getHapFreqs();
         }
      }
   }
}
