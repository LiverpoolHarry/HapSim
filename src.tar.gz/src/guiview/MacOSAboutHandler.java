/*
Copied from http://java.sun.com/developer/technicalArticles/JavaLP/JavaToMac2/
generates a new box with the message but the default MacOSX about box also displays 
 and is much prettier. Need to find out how to get my text onto default box
 */
package guiview;

import com.apple.eawt.ApplicationAdapter;
import com.apple.eawt.ApplicationEvent;
import com.apple.eawt.Application;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MacOSAboutHandler extends Application {

   public MacOSAboutHandler() {
      addApplicationListener(new AboutBoxHandler());
   }

   class AboutBoxHandler extends ApplicationAdapter {

      public void handleAbout(ApplicationEvent event) {
         new AboutDialog(new JFrame()).show();
      }

      class AboutDialog {

         private JFrame jFrame;
         public AboutDialog(JFrame jFrame) {
            this.jFrame = jFrame;
            //jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JLabel message = new JLabel("<html>Haplotype Simulator Version 1.0 <br>" +
                                        "Developed by Harry Noyes, University of Liverpool <br>" +
                                        "www.genomics.liv.ac.uk/tryps </html>");
            jFrame.getContentPane().add(message, BorderLayout.CENTER);
            jFrame.pack();
            
         }

         public void show(){
            jFrame.setVisible(true);
         }
      }
   }
}
