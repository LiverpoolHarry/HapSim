
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Double buffering based on tutorial at
http://www.heatonresearch.com/articles/23/page2.html
 * suggestion to put images in array form
 * http://www.java-forums.org/awt-swing/19092-clear-graphics-objects-jpanel.html
 */
package guiview;

import dataAnalysis.DataArray;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author harry
 */
public class ChromosomeDemo extends JPanel implements Observer {

   private Params p;
   private ArrayList<Color> colors;
   private String generation;
   private ArrayList<String> chrosNames;
   private JPanel inputPanel;
   private Integer chrLength;
   private ArrayList<ArrayList<int[]>> demoDataArray;
   private JScrollPane graphicsScrollPane;
   private Dimension prefSize;
   private Integer preferedHeight;
   private DataArray da;

   public ChromosomeDemo(Params p) {
      this.p = p;
      this.setLayout(new FlowLayout());

      colors = new ArrayList<Color>(9);
      colors.add(Color.BLACK);
      colors.add(Color.RED);
      colors.add(Color.PINK);
      colors.add(Color.BLUE);
      colors.add(Color.CYAN);
      colors.add(Color.GREEN);
      colors.add(Color.MAGENTA);
      colors.add(Color.ORANGE);
      colors.add(Color.YELLOW);

      chrosNames = new ArrayList<String>();
      chrosNames.add("Parent 1");
      chrosNames.add("Parent 2");
      chrosNames.add("Child");
      inputPanel = p.getInputPanels(p.getCurrentViewName());
      graphicsScrollPane = p.getGraphicScrollPane();

      demoDataArray = new ArrayList<ArrayList<int[]>>();

      chrLength = (Integer) p.getModelValues(p.getCurrentViewName()).get("chrLength");

      //Add this as an observer to display a new chromsosome graphic each generation
      
      //Have to wait for da to be initialised by MVController
      // need to check that da has changed and not use old one;
      da = p.getdArray();
      da.addObserver(this);
   }

   /**
    * Monitors dataAnalysis.DataArray class where analysed data from model accumulates.
    * DataArray is Observable and this update responds to broadcasts from
    * updateChrMeanBreaks method which brodcasts after the data from each
    * generation has been added to ArrayList<ArrayList<int[]>> demoDataArray.
    * demoDataArray contains lists of breakpoints and haplotypes for the first two parental
    * chromosomes their child chromosomes
    *
    * The String dA is suffixed with the generation number which is extracted for
    *
    * @param dArray Observable instance of DataArray class
    * @param dA String which is broadcast by DataArray
    */
   public void update(Observable dArray, Object dA) {

      String flag = dA.toString();
      String demoData = "DemoData";
      if (flag.startsWith(demoData)) {
         //Add data from this generation to array for all generations
         demoDataArray.add(da.getDemoData());
         //extract the generation number from the Observer's string
         generation = flag.substring(demoData.length());
         //preferredHeight is for this JPanel but also the image that goes on it in the paint mehtod
         preferedHeight = java.lang.Math.max(100 + 95 * Integer.parseInt(generation), 700);
         prefSize = new Dimension(500, preferedHeight);
         this.setPreferredSize(prefSize);
         revalidate();
         repaint();
         //add the image on the panel to the scrollPane
         graphicsScrollPane.setViewportView(this);
         //M257 Unit 7 section 4.3 suggestion to allow system to generate image
         try {
            Thread.sleep(50);
         }
         catch (InterruptedException e) {
            System.exit(0);
         }

      }
   }

/**
 *
 * @param Graphics g inherited from super class
 */
   public void paint(Graphics g) {

      int lineWidth = 10;
      int xOffset = 70;
      int stringOffset = 10;
      int yOffset;
      int breakBarWidth = 3;
      int genNo = 2;
      yOffset = 20;

      //Create iamge offscreen and then add it to screen
      Image image = createImage(500, preferedHeight);
      Graphics imageG = image.getGraphics();

      //Put legend at top of image
      Font standardFont = imageG.getFont();
      Font headerFont = p.getHeaderFont();
      imageG.setFont(headerFont);
      imageG.drawString("Examples of recombination process", stringOffset, yOffset);
      yOffset += 20;

      imageG.setFont(standardFont);
      imageG.drawString("Generation number is number of child generation", stringOffset, yOffset);
      yOffset += 20;

      imageG.drawString("Child chromosome is drawn first from Parent 1 up to the first break", stringOffset, yOffset);
      yOffset += 20;

      imageG.drawString("then from Parent 2 and alternating at each break", stringOffset + 50, yOffset);
      yOffset += 20;

      imageG.drawString("A random example from each generation is shown", stringOffset, yOffset);


      Integer haplotypeCount = (Integer) p.getModelValues("IntercrossDemo").get("noOfHaplotypes");
      if (haplotypeCount > colors.size()) {
         yOffset += 20;
         imageG.drawString("Only " + colors.size() + " colours are available to illustrate the " +
               haplotypeCount + " haplotypes", stringOffset, yOffset);
      }
      yOffset += 40;

      //Iterate over array of data for each geneation
      for (ArrayList<int[]> demoData : demoDataArray) {
         //System.out.println("Demo data size: " + demoData.size());
         String gen = "Generation: " + genNo;

         imageG.drawString(gen, stringOffset, yOffset);
         yOffset += 10;
         genNo++;

         //Add the break positions
         imageG.drawString("Breaks", stringOffset, yOffset + 7);
         int[] breakPos = demoData.get(0);
         for (int j = 0; j < breakPos.length; j++) {
            if (breakPos[j] != 0 && breakPos[j] != chrLength) {
               imageG.fillRect(xOffset + breakPos[j], yOffset, breakBarWidth, lineWidth * 4);
            }
         }
         yOffset += 10;

         //Generate the graphics for the chromosomes
         int n = 0;
         for (int i = 1; i < demoData.size(); i += 2) {
            imageG.drawString(chrosNames.get(n), stringOffset, yOffset + 10);
            n++;
            int prePosition = 0;
            int[] positions = demoData.get(i);
            int[] haplotypes = demoData.get(i + 1);
            for (int j = 1; j < positions.length; j++) {
               int colorNo = haplotypes[j - 1] % colors.size();
               //System.out.println("J: " + j + " Mod: " + colorNo);
               imageG.setColor(colors.get(colorNo));
               imageG.fillRect(xOffset, yOffset, positions[j] - prePosition, lineWidth);
               xOffset += positions[j] - prePosition;
               prePosition = positions[j];
            }
            yOffset += 20;

         }
         yOffset += 20;
      }


      //float zero = 0;
      //Color transparent = new Color(zero, zero, zero);
      g.drawImage(image, 0, 0, null);
   }
}

