package guiview;

/* --------------------------------
 * XYLineAndShapeRendererDemo1.java
 * --------------------------------
 * (C) Copyright 2004-2009, by Object Refinery Limited.
 *
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.util.HashMap;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.StatisticalBarRenderer;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
//import org.jfree.data.xy.XYDataset;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.TextAnchor;
//import XYdata;

/**
 * A simple demonstration of the {@link XYLineAndShapeRenderer} class.
 */
public class XYplot {

   private Params p; //GUI parameters

   /**
    * Constructs the demo application.
    *
    * @param title  the frame title.
    */
   public XYplot(Params p) {
      this.p = p;
   }

   public ChartPanel createErrorBarChart(IntervalXYDataset dataset, HashMap<String, String> legend) {
      NumberAxis xAxis = new NumberAxis(legend.get("Xaxis"));
      NumberAxis yAxis = new NumberAxis(legend.get("Yaxis"));
      XYErrorRenderer renderer = new XYErrorRenderer();
      renderer.setBaseLinesVisible(true);
      renderer.setBaseShapesVisible(false);
      renderer.setSeriesShapesVisible(1, legend.get("setBaseShapesVisible").endsWith("true"));
      renderer.setSeriesShapesVisible(2, legend.get("setBaseShapesVisible").endsWith("true"));



      XYPlot plot = new XYPlot(dataset, xAxis, yAxis, renderer);

      plot.setDomainPannable(true);
      plot.setRangePannable(true);
      plot.setBackgroundPaint(Color.lightGray);
      plot.setDomainGridlinePaint(Color.white);
      plot.setRangeGridlinePaint(Color.white);
      ValueAxis domainAxis = plot.getDomainAxis();
      if (domainAxis instanceof NumberAxis) {
         NumberAxis axis = (NumberAxis) domainAxis;
         axis.setAutoRangeIncludesZero(false);
      }

      // plot.getLegendItems()

      JFreeChart chart = new JFreeChart(legend.get("title"), plot);
      ChartUtilities.applyCurrentTheme(chart);
      ChartPanel panel = new ChartPanel(chart);
     
      try {
         XYPlot printPlot = (XYPlot) plot.clone();
         addToPrintMenu(legend.get("title"), printPlot);
      }
      catch (CloneNotSupportedException ex) {
         Logger.getLogger(XYplot.class.getName()).log(Level.SEVERE, null, ex);
      }
      

      return panel;
   }

   private void addToPrintMenu(String title, XYPlot plot) {
      plot.setBackgroundPaint(null);
     
      Font labelFont = new Font("Arial", Font.PLAIN, 18);
      plot.getRangeAxis().setLabelFont(labelFont);
      plot.getDomainAxis().setLabelFont(labelFont);
      JFreeChart printChart = new JFreeChart(title, plot);
      ChartUtilities.applyCurrentTheme(printChart);

      p.setjFreecharts(title, printChart);

   }

   /**
    * Creates a sample vertical bar chart.
    *
    * @param dataset  the dataset.
    *
    * @return The chart.
    */
   public ChartPanel createBarChart(CategoryDataset dataset, HashMap<String, String> legend, HashMap<String, Boolean> legendParams) {

      // create the chart...
      JFreeChart chart = ChartFactory.createBarChart(
            legend.get("title"), // chart title
            legend.get("category"), // domain axis label
            legend.get("value"), // range axis label
            dataset, // data
            PlotOrientation.VERTICAL, // orientation
            legendParams.get("includeLegend"), // include legend
            true, // tooltips?
            false // URLs?
            );

      CategoryPlot plot = (CategoryPlot) chart.getPlot();

      // customise the range axis...
      NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
      rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
      rangeAxis.setAutoRangeIncludesZero(false);

      // customise the renderer...
      StatisticalBarRenderer renderer = new StatisticalBarRenderer();
      renderer.setDrawBarOutline(false);
      renderer.setErrorIndicatorPaint(Color.black);
      renderer.setIncludeBaseInRange(true);
      plot.setRenderer(renderer);

      // ensure the current theme is applied to the renderer just added
      ChartUtilities.applyCurrentTheme(chart);

      renderer.setBaseItemLabelGenerator(
            new StandardCategoryItemLabelGenerator());
      renderer.setBaseItemLabelsVisible(true);
      renderer.setBaseItemLabelPaint(Color.yellow);
      renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(
            ItemLabelAnchor.INSIDE6, TextAnchor.BOTTOM_CENTER));
      renderer.setMaximumBarWidth(0.10);

      // set up gradient paints for series...
      GradientPaint gp0 = new GradientPaint(0.0f, 0.0f, Color.blue,
            0.0f, 0.0f, new Color(0, 0, 64));
      GradientPaint gp1 = new GradientPaint(0.0f, 0.0f, Color.green,
            0.0f, 0.0f, new Color(0, 64, 0));
      renderer.setSeriesPaint(0, gp0);
      renderer.setSeriesPaint(1, gp1);

      // return chart;
      ChartPanel panel = new ChartPanel(chart);
      p.setjFreecharts(legend.get("title"), chart);
      return panel;


   }

   /**
    * Creates a sample chart.
    *
    * @param dataset  the dataset.
    *
    * @return The chart.

   protected ChartPanel createChart(CategoryDataset dataset, HashMap<String, String> legend, HashMap<String, Boolean> legendParams) {

   // create the chart...
   JFreeChart chart = ChartFactory.createBarChart(
   legend.get("title"), // chart title
   legend.get("category"), // domain axis label
   legend.get("value"), // range axis label
   dataset, // data
   PlotOrientation.VERTICAL, // orientation
   legendParams.get("includeLegend"), // include legend
   true, // tooltips?
   false // URLs?
   );

   CategoryPlot plot = (CategoryPlot) chart.getPlot();
   plot.setDomainGridlinesVisible(true);
   plot.setRangeCrosshairVisible(true);
   plot.setRangeCrosshairPaint(Color.blue);

   // set the range axis to display integers only...
   NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
   rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

   // disable bar outlines...
   BarRenderer renderer = (BarRenderer) plot.getRenderer();
   renderer.setDrawBarOutline(false);

   // set up gradient paints for series...
   GradientPaint gp0 = new GradientPaint(0.0f, 0.0f, Color.blue,
   0.0f, 0.0f, new Color(0, 0, 64));
   GradientPaint gp1 = new GradientPaint(0.0f, 0.0f, Color.green,
   0.0f, 0.0f, new Color(0, 64, 0));
   GradientPaint gp2 = new GradientPaint(0.0f, 0.0f, Color.red,
   0.0f, 0.0f, new Color(64, 0, 0));
   renderer.setSeriesPaint(0, gp0);
   renderer.setSeriesPaint(1, gp1);
   renderer.setSeriesPaint(2, gp2);
   renderer.setMaximumBarWidth(0.10);


   renderer.setLegendItemToolTipGenerator(
   new StandardCategorySeriesLabelGenerator("Tooltip: {0}"));

   CategoryAxis domainAxis = plot.getDomainAxis();

   domainAxis.setCategoryLabelPositions(
   CategoryLabelPositions.createUpRotationLabelPositions(
   Math.PI / 6.0));

   // return chart;
   ChartPanel panel = new ChartPanel(chart);
   p.setjFreecharts(legend.get("title"), chart);
   //panel.setPreferredSize(new Dimension(dataset.getRowCount() * 30, 400));
   return panel;
   }
    */
   /**
    * Creates an overlaid chart.
    *
    * @return The chart.
    */
   protected ChartPanel createOverlaidXYPlot(XYDataset data1, XYDataset data2, HashMap<String, String> legend) {

      //IntervalXYDataset data1 = createDataset1();
      XYItemRenderer renderer1 = new XYBarRenderer(0.20);
      ValueAxis rangeAxis = new NumberAxis(legend.get("Yaxis"));
      ValueAxis domainAxis = new NumberAxis(legend.get("Xaxis"));
      domainAxis.setLowerMargin(0.005);
      XYPlot plot = new XYPlot(data1, domainAxis, rangeAxis, renderer1);

      // add a second dataset and renderer...
      //XYDataset data2 = createDataset2();
      XYItemRenderer renderer2 = new StandardXYItemRenderer();
      plot.setDataset(1, data2);
      plot.setRenderer(1, renderer2);

      plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);

      // return a new chart containing the overlaid plot...
      JFreeChart chart = new JFreeChart(legend.get("title"),
            JFreeChart.DEFAULT_TITLE_FONT, plot, true);
      ChartUtilities.applyCurrentTheme(chart);
      ChartPanel panel = new ChartPanel(chart);
      p.setjFreecharts(legend.get("title"), chart);
      //panel.setPreferredSize(new Dimension(dataset.getRowCount() * 30, 400));
      return panel;

   }
}
