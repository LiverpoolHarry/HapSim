
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */


/*
 * Creates a JPanel with card layout with a card for
 * model in the ArrayList in Params.
 * Adding a new item to the list in Params will create a new card with that name
 */
package guiview;

import java.awt.CardLayout;
import java.util.HashMap;
import javax.swing.JPanel;

public class ViewPanel {

   private JPanel jpnl;
   private Params p;
   private HashMap<String, JPanel> cards;

   public ViewPanel(Params p) {
      this.p = p;
      jpnl = new JPanel();
      jpnl.setOpaque(true);
      jpnl.setLayout(new CardLayout());

      // HashMap of cards to be added to panel and accessed via
      //comboBox on top panel
      cards = new HashMap<String, JPanel>();      
   }

   public JPanel getPanel() {
      return jpnl;
   }

   public void setCard(String modelName, JPanel ioc) {
      cards.put(modelName, ioc);
      jpnl.add(ioc, modelName);
   }
}
