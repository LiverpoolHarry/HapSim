/*Sorts charts so that they are listed in alphanumeric order in menu
 * Adapted from:
 * http://stackoverflow.com/questions/5403334/how-to-sort-based-on-alphanumeric-values-using-java
 */
package guiview;

import java.util.Comparator;

/**
 *
 * @author harry
 */
public class ChartNameCompare implements Comparator<String> {

   @Override
   public int compare(String left, String right) {
      //System.err.println("Left: " + left);
      //System.err.println("Right: " + right);
      Integer leftInt = getInteger(left);
      Integer rightInt = getInteger(right);
      String leftStr = left.substring(0,left.lastIndexOf(" "));
      String rightStr = right.substring(0,right.lastIndexOf(" "));
      if(leftStr.contentEquals(rightStr)){
         return leftInt.compareTo(rightInt);
      }
      else{
         return leftStr.compareTo(rightStr);
      }
   }

   private Integer getInteger(String str) {
      Integer out;
      try {
         out = Integer.parseInt(str.substring(str.lastIndexOf(" ") + 1));
      }
      catch (NumberFormatException nfe) {
         out = 0;
      }
      return out;
   }
}

