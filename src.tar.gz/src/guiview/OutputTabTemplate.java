
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package guiview;

import dataAnalysis.DataArray;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.table.AbstractTableModel;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author harry
 */
public class OutputTabTemplate {

   protected Params p; //GUI parameters
   protected String cardName; //name of card on which this tab sits
   protected DataArray da; //Class in dataAnalysis package that holds simulated data
   protected JPanel tablePanel;
   protected Border border;//border of output plots and tables
   protected HashMap<String, Object> values; //Values of input parameters
   protected Double[] expecteds;//Array of theoretical numbers of break points

   public OutputTabTemplate() {


      Border etchBorder = BorderFactory.createEtchedBorder();
      Border lineBorder = BorderFactory.createLineBorder(Color.gray, 5);
      border = BorderFactory.createCompoundBorder(etchBorder, lineBorder);


   }

   //return Poisson probability for observed number of breaks and mean breaks
   private Double getPoisson(Integer key, Double mBreaks) {
      Double expected = java.lang.Math.exp((java.lang.Math.log(mBreaks) * key - mBreaks) - lnFactorial(key));
      return expected;
   }

   //returns ln of factorial which is fine for this purpose
   //Factorials much over twenty are too large for Java
   private Double lnFactorial(Integer n) {
      Double fact = java.lang.Math.log(1);
      for (Integer i = 1; i <= n; i++) {
         fact += java.lang.Math.log(i);

      }
      return fact;
   }

   protected Double getRecomRatio() {
      //Get the mean recombination rate which is the number
      //of recombination
      String[] fieldNames = {"recom0", "recom1", "recom2", "recom3"};
      Double product = 0.0;
      Integer sum = 0;
      for (int i = 0; i < 4; i++) {
         product += i * (Integer) values.get(fieldNames[i]);
         sum += (Integer) values.get(fieldNames[i]);
      }
      Double recomRatio = product / sum;
      return recomRatio;
   }

   protected HashMap<Integer, Double> getExponentialExpected(int count, Double mean, Double hapCount) {
      HashMap<Integer, Double> expExpect = new HashMap<Integer, Double>(count);
      for (Integer i = 0; i < count; i++) {
         Double expect = mean * Math.exp(-i * mean) * hapCount;
         expExpect.put(i, expect);
      }
      return expExpect;
   }

   /**
    * Creates a sample dataset.
    *
    * @return A sample dataset.
    */
   protected static IntervalXYDataset createDataset(HashMap<Integer, Double> hash, String seriesName) {
      XYSeries series = new XYSeries(seriesName);

      Map<Integer, Double> map = new TreeMap<Integer, Double>(hash);
      for (Map.Entry<Integer, Double> entry : map.entrySet()) {
         series.add(entry.getKey(), entry.getValue());
      }
      XYSeriesCollection dataset = new XYSeriesCollection(series);
      return dataset;
   }

   protected Double[] getExpecteds(Double recomRatio, Integer hapCount, ArrayList<ArrayList<Double>> chrMeanBreaks) {
      Integer maxGen = (Integer) values.get("generations");
      Integer popSize = (Integer) values.get("popSize");

      Integer familySize = (Integer) values.get("familySize");
      Integer ploidy = (Integer) values.get("ploidy");
      //popSize is number of gametes not individuals
      popSize = popSize / ploidy;
      expecteds = new Double[maxGen + 1];
      Double expected = recomRatio;
      Integer selfing = (Integer) values.get("founders");
      if (selfing.equals(1)) {
         expected = recomRatio * p.getMeanHapFreq();
      }
      expecteds[2] = expected;
      Double drift = 1.0;
      Double hCount = hapCount * 1.0;
      Double rRatio = recomRatio * p.getMeanHapFreq();
      /*Effect of Family size
       * Ne = 4N/(var(g) + mg^2 - mg)
       * Where var(g) is variance of number of gametes and mg is mean number of gametes that contribute to each child
       * mg is 2 for a diploid organism.
       * Variance of g for a Poisson distributed family size in a static population is 2 * family size
       * method getVariance illustrates this but is not used by the program.
       * Uncomment command getVariance() from Class constructor to print out calculated values of
       * the variance of g for different family sizes
       */
      Double pSize = 4 * popSize / (2.0 * familySize + 4 - 2);

      //Correction to effective population size for genetic drift.
      //Ne declines by (2Ne-1)/2Ne at each generation (Sewall Wright Genetics 16, 97-159 1931).
      Double factor = (2 * pSize - 1) / (2 * pSize * 1.0);

      for (int i = 3; i <= maxGen; i++) {
         drift = drift * factor;
         expected = expected + drift * rRatio;
         expecteds[i] = expected;
      }
      return expecteds;
   }

   private void getVariance() {
      // Values of poisson distribution with mean = 1
      HashMap<Integer, Double> poisson = new HashMap<Integer, Double>();
      poisson.put(0, 0.367879441171449);
      poisson.put(1, 0.367879441171449);
      poisson.put(2, 0.183939720585725);
      poisson.put(3, 0.0613132401952415);
      poisson.put(4, 0.0153283100488104);
      poisson.put(5, 0.00306566200976208);
      poisson.put(6, 0.000510943668293679);
      poisson.put(7, 7.29919526133828E-05);
      poisson.put(8, 9.12399407667284E-06);
      poisson.put(9, 1.01377711963032E-06);
      int gametes = 10000;//Number of gametes this only controls accuracy not final values
      //fS = family size
      System.out.println("Variance of numbers of gametes from each in population with different family sizes");
      for (int fS = 1; fS < 20; fS++) {
         Double sumOfSquares = 0.0;
         for (int i = 0; i < 10; i++) {
            //gametes/fS * poisson.get(i) is number of individuals that contribute i gametes to next generation
            // i * fS is the numebr of gametes that they contribute
            // 2 is the mean number of gametes contributed by each individual over whole population
            sumOfSquares += (gametes / fS) * poisson.get(i) * (2 - i * fS) * (2 - i * fS);
         }
         //As family size increase number of childless individuals increase.
         //These must be included with (0-2)^2 = 4 squares
         sumOfSquares += (gametes - (gametes / fS)) * 4;
         Double variance = sumOfSquares / gametes;
         //Print to log file
         System.out.println("Family Size: " + fS + "; Variance: " + variance);
      }

   }

   class MyTable extends AbstractTableModel {

      private String[] columnNames;
      private ArrayList<ArrayList<Double>> data;

      public MyTable(String[] columnNames, ArrayList<ArrayList<Double>> chrMeanBreaks) {
         this.columnNames = columnNames;
         this.data = chrMeanBreaks;
      }

      public int getColumnCount() {
         return columnNames.length;
      }

      public int getRowCount() {
         return data.size();
      }

      public String getColumnName(int col) {
         return columnNames[col];
      }

      public Object getValueAt(int row, int col) {

         return data.get(row).get(col);
      }

      /*
       * JTable uses this method to determine the default renderer/
       * editor for each cell.  If we didn't implement this method,
       * then the last column would contain text ("true"/"false"),
       * rather than a check box.
       */
      public Class getColumnClass(int c) {
         if (c == 0) {
            Integer i = 0;
            return i.getClass();
         }
         else {
            Double d = 1.1;
            return d.getClass();
         }

      }

      /*
       * Don't need to implement this method unless your table's
       * editable.
       */
      public boolean isCellEditable(int row, int col) {
         return false;
      }

      /*
       * Don't need to implement this method unless your table's
       * data can change.
       */
      public void setValueAt(Object value, int row, int col) {
      }
   }
}
    
