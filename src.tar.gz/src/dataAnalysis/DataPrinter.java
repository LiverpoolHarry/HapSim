
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package dataAnalysis;

import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;


import java.io.IOException;
//import java.lang.StringBuilder;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.Properties;
import haplotypesimulator.Params;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author harry
 */
public class DataPrinter {

   protected DataArray dataArray;
   private Boolean analyse;
   private ArrayList<HashMap<Integer, Integer>> haplotypeCounts;
   private ArrayList<HashMap<Integer, Integer>> positionCounts;
   public static final String separator = System.getProperty("separatorChar");
   private Properties config;
   private DecimalFormat df;
   private DecimalFormat integerF;
   private HashMap<String, BufferedWriter> bWriters;
   //private BufferedWriter analysisFile;
   //BufferedWriter logWriter;
   private Params p;
   //static BufferedWriter analysisFile;

   public DataPrinter(DataArray dataArray, Properties config, Params p) {
      this.dataArray = dataArray;
      this.config = config;
      this.p = p;
      df = new DecimalFormat("####0.000");
      integerF = new DecimalFormat("#,###");
      bWriters = new HashMap<String, BufferedWriter>(4);

   }

   public void printAnalysis(String startDate, String endDate, String filename) {
      try {
         File file = new File(filename);
         BufferedWriter out = getOutputFile(file);
         bWriters.put(filename, out);
         //Print out time stamp
         out.write("Job started at\t" + startDate);
         out.newLine();

         out.write("Job finished at\t" + endDate);
         out.newLine();

         out.write("Simulation type\t" + p.getModelName());
         out.newLine();

         out.write("Configuration parameters");
         out.newLine();

         //Print out the configuration parameters
         printParams(filename);
         out.newLine();
         out.newLine();


         //Print Mean haplotype lengths by haplotype
         HashMap<Integer, Double> meanHapLengths = dataArray.getMeanHapLength();
         HashMap<Integer, Double> stdErrHapLengths = dataArray.getStdErrHapLength();
         HashMap<Integer, Double> varHapLengths = dataArray.getStdHapLength();
         Integer hapCount = Integer.parseInt(config.getProperty("noOfHaplotypes"));
         Integer generations = Integer.parseInt(config.getProperty("generations"));
         out.write("Means of Haplotype lengths in final generation");
         out.newLine();
         out.write("Haplotype\tMean Length\tStandard deviation\tStandard error");
         out.newLine();
         for (int i = 0; i < hapCount; i++) {
            int hap = i + 1;
            out.write(hap + "\t" + integerF.format(meanHapLengths.get(i)) + "\t" + integerF.format(Math.sqrt(varHapLengths.get(i))) + "\t" + integerF.format(stdErrHapLengths.get(i)));
            out.newLine();
         }
         out.write("Mean\t" + integerF.format(meanHapLengths.get(hapCount)) + "\t" + integerF.format(Math.sqrt(varHapLengths.get(hapCount))) + "\t" + integerF.format(stdErrHapLengths.get(hapCount)));
         out.newLine();
         out.newLine();

         //Print haplotype frequencies
         HashMap<Integer, Double> meanHapFreqs = dataArray.getMeanHapFreqs();
         HashMap<Integer, Double> stdErrHapFreqs = dataArray.getStdErrHapFreqs();
         out.write("Haplotype lengths as proportion of total length at final generation");
         out.newLine();
         out.write("Haplotype\tProportion\tStandard error");
         out.newLine();

         for (int i = 0; i < hapCount; i++) {
            int hap = i + 1;
            out.write(hap + "\t" + df.format(meanHapFreqs.get(i)) + "\t" + df.format(stdErrHapFreqs.get(i)));
            out.newLine();
         }
         out.write("Mean\t" + df.format(meanHapFreqs.get(hapCount)) + "\t" + df.format(stdErrHapFreqs.get(hapCount)));
         out.newLine();
         out.newLine();

         //Print mean breaks and std devs
         ArrayList<ArrayList<Double>> meanBreaks = dataArray.getChrMeanBreaks();
         HashMap<Integer, HashMap<Integer, Double>> meanHapLengthsGen = dataArray.getMeanHapLengthGenerations();
         HashMap<Integer, HashMap<Integer, Double>> stdHapLengthsGen = dataArray.getStdHapLengthGenerations();

         //ArrayList<ArrayList<Double>> chrStdDev = dataArray.getChrStdDev();
         // HashMap<Integer, Double> stdDevBreaks = dataArray.getPosArrayStdDev();
         out.write("Numbers of breaks and haplotype mean lengths and standard deviation for each generation");
         out.newLine();
         StringBuilder header = new StringBuilder();
         header.append("Generation\tMean Number of Breaks\tVariance of Number of Breaks\tMean Haplotype Length");
         for (int n = 1; n <= hapCount; n++) {
            header.append("\t" + "Mean Length Hap " + n + "\t" + "Std Dev Hap " + n);
         }
         header.append("\t" + "Mean Length of All Haplotypes\tStandard  Deviation of all Haplotypes ");
         out.write(header.toString());
         out.newLine();
         for (int i = 0; i < meanBreaks.size(); i++) {
            StringBuilder breakCounts = new StringBuilder();
            ArrayList<Double> breaks = meanBreaks.get(i);
            for (int n = 0; n <= 3; n++) {
               breakCounts.append(df.format(breaks.get(n)) + "\t");
            }
            HashMap<Integer, Double> meanHapLens = meanHapLengthsGen.get((int) Math.round(breaks.get(0)));
            HashMap<Integer, Double> stdHapLens = stdHapLengthsGen.get((int) Math.round(breaks.get(0)));
            for (int n = 0; n <= hapCount; n++) {
               breakCounts.append(df.format(meanHapLens.get(n)) + "\t" + df.format(stdHapLens.get(n)) + "\t");
            }

            //String stdDev = df.format(stdDevBreaks.get(i));
            //breakCounts.append(stdDevBreaks.get(i).toString() + "\t");

            out.write(breakCounts.toString());
            out.newLine();

         }
         out.newLine();

         //Print haplotype length distribution
         HashMap<Integer, HashMap<Integer, Double>> meanHapDistribution = dataArray.getMeanHapDistribution();
         out.write("Frequency of haplotypes by length");
         out.newLine();
         out.write("Bin\t");
         for (int hap = 1; hap <= hapCount; hap++) {
            out.write("Haplotype " + hap + "\t");
         }
         out.write("Sum");
         out.newLine();
         for (int bin = 0; bin < meanHapDistribution.get(hapCount).size(); bin++) {
            out.write(bin + "\t");
            for (int hap = 0; hap <= hapCount; hap++) {
               out.write(meanHapDistribution.get(hap).get(bin) + "\t");
            }
            out.newLine();
         }

         out.newLine();

         //print numbers of chromosomes generated to get introgressed chromosomes for INtrogression model.
         if (p.getModelName().contains("Introgression")) {
            //HashMap<Integer, Double> meanCountIntrogressedChros = dataArray.getMeanCountIntrogressedChros();
            ///HashMap<Integer, Double> meanCountIntrogressedChrosGenerated = dataArray.getMeanCountIntrogressedChrosGenerated();
            ArrayList<ArrayList<Double>> iC = dataArray.getIntrogressedChros();
            out.write("Counts of chromosomes generated and chromomosomes with introgressed haplotype at peak Marker");
            out.newLine();
            out.write("Generation\tChromosomes generated\tchromomosomes with introgressed haplotype at peak Marker");
            out.newLine();

            for (ArrayList<Double> al : iC) {
               out.write(al.get(0) + "\t");
               out.write(al.get(1) + "\t");
               out.write(al.get(2).toString());
               out.newLine();
            }
            out.newLine();


         }

         out.close();
      }
      catch (IOException e) {

         System.out.println("IOException : " + e);

      }
   }

   public void setLogFile(String filename) {
      File logfile = new File(filename);
      BufferedWriter logWriter = getOutputFile(logfile);
      bWriters.put(filename, logWriter);
      printParams(filename);
      try {
         logWriter.close();
      }
      catch (IOException ex) {
         Logger.getLogger(DataPrinter.class.getName()).log(Level.SEVERE, null, ex);
      }

   }

   public void printLog(String filename, long elapsedTime, int replicate) {
      int secs = (int) (elapsedTime / 1000) % 60;
      int mins = (int) ((elapsedTime / (1000 * 60)) % 60);
      int hours = (int) ((elapsedTime / (1000 * 60 * 60)) % 24);
      String eTime = "; Elapsed Time: " + secs + "s";
      if (hours > 0) {
         eTime = "; Elapsed Time: " + hours + "h:" + mins + "m:" + secs + "s";
      }
      else if (mins > 0) {
         eTime = "; Elapsed Time: " + mins + "m:" + secs + "s";
      }
      try {
         File logfile = new File(filename);
         BufferedWriter logWriter = getOutputFile(logfile);
         logWriter.append("Replicate: " + replicate + eTime);
         logWriter.newLine();
         logWriter.close();
      }
      catch (IOException e) {
         System.err.println("IOException : " + e);
      }

   }

   //Called by RunSimulation to write config to Log as well as this class to write config to data file
   public void printParams(String filename) {
      BufferedWriter out = bWriters.get(filename);
      //Print out the configuration parameters
      Enumeration en = config.keys();
      int j = 0;
      int columns = 2; //Number of columns of config parameters to print
      StringBuilder configString = new StringBuilder();
      while (en.hasMoreElements()) {
         j++;


         String key = (String) en.nextElement();
         String value = config.get(key).toString();
         if (key.contentEquals("popSize")) {
            Integer val = Integer.parseInt(config.getProperty(key)) / Integer.parseInt(config.getProperty("ploidy"));
            //value = val.toString();
         }

         try{
            configString.append(key + "\t" + integerF.format(Integer.parseInt(value)) + "\t\t");
         }
         catch(NumberFormatException nfe){
                 configString.append(key + "\t" + value + "\t\t");
         }
         if(j % columns == 0){
            configString.append("\n");
         }
      }

      try {
         out.write(configString.toString());
      }
      catch (IOException e) {
         System.err.println("IOException : " + e);
      }
      //Log parameters to error log for trouble shooting
      System.err.println(configString.toString());

   }

   public BufferedWriter getOutputFile(File file) {
      BufferedWriter analysisFile = null;
      try {
         FileWriter fstream = new FileWriter(file.getAbsoluteFile(), true);

         analysisFile = new BufferedWriter(fstream);

      }
      catch (IOException e) {
         System.out.println("IOException : " + e);


      }
      return analysisFile;

   }
}


