/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAnalysis;

import javax.swing.JFrame;
import haplotypesimulator.Params;
import java.awt.BorderLayout;
//import java.util.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author harry
 */
public class ProgressMonitor implements Observer {

   private JFrame jfrm;
   private JPanel jpan;
   private JLabel repLabel;
   private JLabel genLabel;
   private JLabel elTimeLabel;
   private Params p;
   private DataArray da;
   private Timer timer;
   private long startTime;
   //private final Dimension frameSize = new Dimension(2000, 10);

   public ProgressMonitor(Params p, DataArray da) {
      this.p = p;
      this.da = da;
      da.addObserver(this);
      // Create a new JFrame container.
      jfrm = new JFrame("Progress");
      jfrm.setLayout(new BorderLayout());
      // Give the frame an initial size.
      jfrm.setSize(200, 100);
      jpan = new JPanel();

   }

   public void startProgressMonitor() {
      int rep = p.getCurrentReplicate();
      int gen = p.getGeneration();
      String replicates = "Replicate: " + rep;
      String generations = "Generation: " + gen;
      Date startT = new Date(0);
      repLabel = new JLabel(replicates);
      genLabel = new JLabel(generations);
      elTimeLabel = new JLabel("Elapsed Time: 0s");
      repLabel.setAlignmentX(repLabel.CENTER_ALIGNMENT);
      genLabel.setAlignmentX(genLabel.CENTER_ALIGNMENT);
      elTimeLabel.setAlignmentX(elTimeLabel.CENTER_ALIGNMENT);

      jpan.setLayout(new BoxLayout(jpan, BoxLayout.PAGE_AXIS));
      //Handle timer event.
      ActionListener timerAL = new ActionListener() {

         public void actionPerformed(ActionEvent ae) {
            updateLabel();
         }
      };


      jpan.add(repLabel);
      jpan.add(genLabel);
      jpan.add(elTimeLabel);

      jfrm.add(jpan);
      // Terminate the program when the user closes the application.
      jfrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      jfrm.setVisible(true);
      startTime = Calendar.getInstance().getTimeInMillis();

      timer = new Timer(1000, timerAL);
      //timer.setInitialDelay(5000);
      timer.start();



   }

   private void updateLabel() {

      int rep = p.getCurrentReplicate();
      String replicates = "Replicate: " + rep;
      String generations = "Generation: " + p.getGeneration();
      repLabel.setText(replicates);
      genLabel.setText(generations);
      long endTime = Calendar.getInstance().getTimeInMillis();
      long elapsedTime = endTime - startTime;

      //Date elTime = new Date(elapsedTime);
      int secs = (int) (elapsedTime / 1000) % 60;
      int mins = (int) ((elapsedTime / (1000 * 60)) % 60);
      int hours = (int) ((elapsedTime / (1000 * 60 * 60)) % 24);
      String eTime = "Elapsed Time: " + secs + "s";
      if (hours > 0) {
         eTime = "Elapsed Time: " + hours + "h:" + mins + "m:" + secs + "s";
      }
      else if (mins > 0) {
         eTime = "Elapsed Time: " + mins + "m:" + secs + "s";
      }
      elTimeLabel.setText(eTime);

   }

   //Listener on DataArray which signals when run complete
   public void update(Observable dArray, Object dA) {
      if (da == dArray) {
         //last generation display reports else update progress bar
         if (dA.equals("jobDone")) {

            jfrm.dispose();
            timer.stop();
            // return;

         }
      }
   }

   public void disposeWindow() {
      jfrm.dispose();
   }

   private void updateMonitor() {
      String replicates = "Replicate: " + p.getCurrentReplicate();
      String generations = "Generation: " + p.getGeneration();
      //System.out.println("Timer called");
      repLabel.setText(replicates);
      genLabel.setText(generations);
      /* jpan.removeAll();
      jpan.add(repLabel);
      jpan.add(genLabel);
       * */
      jpan.repaint();
      jfrm.repaint();
      jpan.revalidate();

   }
}
