
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package dataAnalysis;

/**
 * @param Holds arrays of arrays of  break point positions pending analysis
 * Observable based on http://www.javaworld.com/javaworld/jw-10-1996/jw-10-howto.html?page=3
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observable;
import org.jfree.data.category.DefaultCategoryDataset;
import haplotypesimulator.Params;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class DataArray extends Observable {

   private ArrayList<HashMap<Integer, Integer>> chrPosCounts; //counts of each number of breaks
   private ArrayList<HashMap<Integer, Integer>> replicateChrPosCounts; //counts of each number of breaks at end of each replicate
   private ArrayList<ArrayList<Double>> chrMeanBreaks; //generation (key), value is array of mean breaks 
   //and mean haplotype length fo use in output table
   //Mean breaks for each generation for each replicate geneneration is calculated from index and statistics interval
   private ArrayList<ArrayList<Double>> chrStdDev; //std error of data in chrMeanBreaks
   private ArrayList<ArrayList<ArrayList<Double>>> replicatesChrMeanBreaks;
   private HashMap<Integer, Integer> posArray; //histogram of break counts for most recent generation
   private HashMap<Integer, Double> posArrayStdDev; //histogram of break counts for most recent generation
   //private Integer currentReplicate;
   private HashMap<String, Object> dataStructures;
   private DefaultCategoryDataset breakCounts;
   // private HashMap<Integer, Double> meanHapLength;
   private HashMap<Integer, Double> hapCounts;
   private HashMap<Integer, Double> meanHapFreqs;
   private HashMap<Integer, Double> stdErrHapFreqs;
   // private HashMap<Integer, Double> stdHapLength;
   private HashMap<Integer, HashMap<Integer, Double>> stdHapLengthGenerations;
   private HashMap<Integer, HashMap<Integer, Double>> meanHapLengthGenerations;
   //  private HashMap<Integer, Double> stdErrHapLength;
   private HashMap<Integer, HashMap<Integer, Double>> meanHapDistribution;
   private HashMap<Integer, ArrayList<Integer>> hapLengths;
   private ArrayList<HashMap<Integer, Double>> meanHapFreqsReps;
   // meanHapLengthReps and stdHapLengthReps first index is replicate, second is generation, third is haplotype.
   // Value is mean haplotype length or standard deviation of haplotype length
   private HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> meanHapLengthReps;
   private HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> stdHapLengthReps;
   private ArrayList<HashMap<Integer, ArrayList<Integer>>> hapLengthsReps;
   private Integer replicateCount;
   private Integer noOfHaplotypes;
   private ArrayList<ArrayList<Double>> introgressedChros;
   private int binSize;
   private Params p;
   private Integer statisticsInterval;
   private ArrayList<HashMap<String, Double>> replicateMeanBreaks;//means of replicates
   private ArrayList<int[]> demoData;//two parents and one child for demo to illustrate recombination
   private HashMap<String, Double> meanBreaks;//mean breaks for last generation used for calculation of Poisson distribution in output

   //called by RunSimulation at initialisation
   public DataArray(Integer replicateCount) {
      this.replicateCount = replicateCount;
      chrPosCounts = new ArrayList<HashMap<Integer, Integer>>();
      replicateChrPosCounts = new ArrayList<HashMap<Integer, Integer>>();
      chrMeanBreaks = new ArrayList<ArrayList<Double>>();
      chrStdDev = new ArrayList<ArrayList<Double>>();
      dataStructures = new HashMap<String, Object>();
      replicateMeanBreaks = new ArrayList<HashMap<String, Double>>(replicateCount);
      meanBreaks = new HashMap<String, Double>();
      replicatesChrMeanBreaks = new ArrayList<ArrayList<ArrayList<Double>>>(replicateCount);
      posArray = new HashMap<Integer, Integer>();
      posArrayStdDev = new HashMap<Integer, Double>();
      chrPosCounts.add(0, posArray);
      binSize = 0;

      
   }

   //called by RunSimulation at initialisation
   public void setParams(Params p) {
      this.p = p;
      noOfHaplotypes = Integer.parseInt(p.getConfig().getProperty("noOfHaplotypes"));
      //currentReplicate = p.getCurrentReplicate();
      //stdErrHapLength = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      hapCounts = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      hapCounts = initialiseHash(hapCounts, noOfHaplotypes);
      meanHapLengthReps = initialiseDoubleHash();
      stdHapLengthReps = initialiseDoubleHash();
      /* stdHapLength = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      stdHapLength = initialiseHash(stdHapLength, noOfHaplotypes);
      meanHapLength = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      meanHapLength = initialiseHash(meanHapLength, noOfHaplotypes);*/
      hapLengths = new HashMap<Integer, ArrayList<Integer>>(noOfHaplotypes + 1);
      hapLengthsReps = new ArrayList<HashMap<Integer, ArrayList<Integer>>>(replicateCount);
      meanHapFreqsReps = new ArrayList<HashMap<Integer, Double>>(replicateCount);
      stdHapLengthGenerations = new HashMap<Integer, HashMap<Integer, Double>>(p.getMaxGeneration());
      meanHapLengthGenerations = new HashMap<Integer, HashMap<Integer, Double>>(p.getMaxGeneration());
      statisticsInterval = Integer.parseInt(p.getConfig().getProperty("statisticInterval"));
   }

   protected HashMap<Integer, Double> initialiseHash(HashMap<Integer, Double> hash, Integer count) {
      for (Integer i = 0; i <= count; i++) {
         hash.put(i, 0.0);
      }
      return hash;
   }

   protected HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> initialiseDoubleHash() {
      HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> hash = new HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>>(replicateCount);
      for (Integer r = 0; r <= replicateCount; r++) {
         hash.put(r, new HashMap<Integer, HashMap<Integer, Double>>(p.getMaxGeneration()));
      }
      return hash;
   }

   public String[] getColumnNames() {
      String[] colNames = new String[3];
      if (p.getModelName().contains("Introgression")) {
         colNames[0] = "Generation";
         colNames[1] = "Chr Passed";
         colNames[2] = "Total Chr";

      }
      else {
         Integer chrLength = Integer.parseInt(p.getConfig().getProperty("chrLength"));

         String colHead = "Mean Haplotype bp";
         if (chrLength > 1000000) {
            colHead = " Mean Haplotype Mbp";
         }
         else if (chrLength > 1000) {
            colHead = " Mean Haplotype Kbp";
         }
         colNames[0] = "Generation";
         colNames[1] = "Mean Breaks";
         colNames[2] = colHead;

      }
      return colNames;
   }

   public synchronized ArrayList<ArrayList<Double>> getChrMeanBreaks() {
      return chrMeanBreaks;
   }

   public HashMap<String, Object> getDataStructures() {
      return dataStructures;
   }

   public synchronized void updateMeanBreaksReplicates() {
      ArrayList<ArrayList<Double>> chrMeanBreaksClone = new ArrayList<ArrayList<Double>>();
      chrMeanBreaksClone = (ArrayList<ArrayList<Double>>) chrMeanBreaks.clone();
      replicatesChrMeanBreaks.add(chrMeanBreaksClone);
      chrMeanBreaks.clear();

      HashMap<String, Double> meanBreaksClone = (HashMap<String, Double>) meanBreaks.clone();
      replicateMeanBreaks.add(meanBreaksClone);

      HashMap<Integer, Integer> chrPosCountsClone = (HashMap<Integer, Integer>) chrPosCounts.get(0).clone();
      replicateChrPosCounts.add(chrPosCountsClone);
   }

   //called by RunSimulation at end of run method
   public synchronized void mergeReplicates() {
      //Get Mean break point count and haplotype length for each generation

      mergeReps();
      //Combine hashes from replicates into single average
      //Integer minkey = Collections.min(meanHapLengthReps.get(1).keySet());

      meanHapLengthGenerations = mergeReplicateHashes(meanHapLengthReps);

      //mean of variance is variance of means plus mean of variances
      //get mean of standard deviations

      stdHapLengthGenerations = mergeReplicateHashes(stdHapLengthReps);
      //add standard deviation of means
      stdHapLengthGenerations = addStdDevOfMeans(stdHapLengthReps);
      meanHapFreqs = getMeansOfHash(meanHapFreqsReps);
      stdErrHapFreqs = getVariance(meanHapFreqsReps, meanHapFreqs);
      setBinSize();
      setHapDistribution(binSize);
      //Get standard deviation of posArray
      setPosArrayStdDev();
      //This will be all zeros unless Introgression is used
      if (p.getModelName().contains("Introgression")) {
         HashMap<Integer, Double> meanCountIntrogressedChros = new HashMap<Integer, Double>(replicateCount);
         meanCountIntrogressedChros = getMeansOfArray(p.getCountIntrogressedChros(), meanCountIntrogressedChros);
         HashMap<Integer, Double> meanCountIntrogressedChrosGenerated = new HashMap<Integer, Double>(replicateCount);
         meanCountIntrogressedChrosGenerated = getMeansOfArray(p.getCountIntrogressedChrosGenerated(), meanCountIntrogressedChrosGenerated);
         introgressedChros = new ArrayList<ArrayList<Double>>(p.getMaxGeneration());
         Map<Integer, Double> map1 = new TreeMap<Integer, Double>(meanCountIntrogressedChros);
         for (Map.Entry<Integer, Double> entry : map1.entrySet()) {
            ArrayList<Double> al = new ArrayList<Double>(3);
            if (entry.getKey() > 1) {
               al.add(entry.getKey() * 1.0);
               al.add(entry.getValue());
               al.add(meanCountIntrogressedChrosGenerated.get(entry.getKey()));
               introgressedChros.add(al);
            }

         }
      }

      setChanged();
      notifyObservers("jobDone");
      notifyObservers("posCounts");
   }

   private HashMap<Integer, HashMap<Integer, Double>> addStdDevOfMeans(HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> hash) {
      HashMap<Integer, HashMap<Integer, Double>> outHash = new HashMap<Integer, HashMap<Integer, Double>>();
      //initiliase has to zeros
      Integer min = Collections.min(meanHapLengthReps.get(1).keySet());
    
      for (int i = min; i <= p.getMaxGeneration(); i += statisticsInterval) {
         outHash.put(i, new HashMap<Integer, Double>(noOfHaplotypes + 1));
         for (int j = 0; j <= noOfHaplotypes; j++) {
            outHash.get(i).put(j, 0.0);
         }
      }

      for (int i = 0; i < replicateCount; i++) {
         //pairs1 value is hash gen, haplotype, value
         HashMap<Integer, HashMap<Integer, Double>> genReps = hash.get(i);
         Iterator it1 = genReps.entrySet().iterator();
         while (it1.hasNext()) {
            //pairs1 value is generation
            Map.Entry pairs1 = (Map.Entry) it1.next();
            Integer gen = (Integer) pairs1.getKey();
            HashMap<Integer, Double> hapReps = (HashMap<Integer, Double>) pairs1.getValue();
            Iterator it2 = hapReps.entrySet().iterator();
            while (it2.hasNext()) {
               //pairs2 value is haplotype
               Map.Entry pairs2 = (Map.Entry) it2.next();
               Integer hap = (Integer) pairs2.getKey();
               Double val = (Double) pairs2.getValue();
               Double mean = meanHapLengthGenerations.get(gen).get(hap);
               val = (val - mean) * (val - mean);
               outHash.get(gen).put(hap, val + outHash.get(gen).get(hap));
            }
         }
      }

      //divide by number of replicates, sqroot and add to stdHapLengthGenerations
      Iterator it3 = outHash.entrySet().iterator();
      while (it3.hasNext()) {
         //pairs1 value is haplotype value
         Map.Entry pairs3 = (Map.Entry) it3.next();
         Integer gen = (Integer) pairs3.getKey();
         HashMap<Integer, Double> hapReps = (HashMap<Integer, Double>) pairs3.getValue();
         Iterator it4 = hapReps.entrySet().iterator();
         while (it4.hasNext()) {
            //pairs1 value is haplotype value
            Map.Entry pairs4 = (Map.Entry) it4.next();
            Integer key = (Integer) pairs4.getKey();
            Double val = (Double) pairs4.getValue();
            stdHapLengthGenerations.get(gen).put(key, Math.sqrt(val / replicateCount) + stdHapLengthGenerations.get(gen).get(key));
         }
      }
      return stdHapLengthGenerations;
   }

   private HashMap<Integer, HashMap<Integer, Double>> mergeReplicateHashes(HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> hash) {
      //Initialise hash with first replicate
      HashMap<Integer, HashMap<Integer, Double>> outHash = hash.get(1);
      //Add remaining replicates
      for (int i = 2; i <= replicateCount; i++) {
         //pairs1 value is hash gen, haplotype, value
         HashMap<Integer, HashMap<Integer, Double>> genReps = hash.get(i);
         Iterator it1 = genReps.entrySet().iterator();
         while (it1.hasNext()) {
            //pairs1 value is generation
            Map.Entry pairs1 = (Map.Entry) it1.next();
            Integer gen = (Integer) pairs1.getKey();
            HashMap<Integer, Double> hapReps = (HashMap<Integer, Double>) pairs1.getValue();
            Iterator it2 = hapReps.entrySet().iterator();
            while (it2.hasNext()) {
               //pairs2 value is haplotype
               Map.Entry pairs2 = (Map.Entry) it2.next();
               Integer key = (Integer) pairs2.getKey();
               Double val = (Double) pairs2.getValue();
               outHash.get(gen).put(key, val + outHash.get(gen).get(key));
            }
         }
      }

      //divide by number of replicates
      Iterator it3 = outHash.entrySet().iterator();
      while (it3.hasNext()) {
         //pairs1 value is generation
         Map.Entry pairs3 = (Map.Entry) it3.next();
         Integer gen = (Integer) pairs3.getKey();
         HashMap<Integer, Double> hapReps = (HashMap<Integer, Double>) pairs3.getValue();
         Iterator it4 = hapReps.entrySet().iterator();
         while (it4.hasNext()) {
            //pairs1 value is haplotype
            Map.Entry pairs4 = (Map.Entry) it4.next();
            Integer key = (Integer) pairs4.getKey();
            Double val = (Double) pairs4.getValue();
            outHash.get(gen).put(key, val / replicateCount);
         }
      }
      return outHash;
   }

   private HashMap<Integer, Double> getMeansOfArray(HashMap<Integer, ArrayList<Integer>> input, HashMap<Integer, Double> output) {
      for (Integer j = 0; j < input.get(0).size(); j++) {
         Double total = 0.0;
         for (int i = 0; i <= replicateCount; i++) {
            total += input.get(i).get(j);
         }
         output.put(j, total / replicateCount);
      }
      return output;
   }

   public void setHapDistribution(int binSize) {
       Integer binCount = (Integer) 1 + Integer.parseInt(p.getConfig().getProperty("chrLength")) / binSize;
      //meanHapDistribution has distributions for all haplotypes
      // create meanHapDistribution and initalise all values to zero
      meanHapDistribution = new HashMap<Integer, HashMap<Integer, Double>>(noOfHaplotypes + 1);
      for (Integer i = 0; i <= noOfHaplotypes; i++) {
         meanHapDistribution.put(i, initialiseHash(new HashMap<Integer, Double>(binCount), binCount));
      }
      //Get count of haplotypes in each bin from all replicates
      for (HashMap<Integer, ArrayList<Integer>> hlr : hapLengthsReps) {
         for (Integer i = 0; i <= noOfHaplotypes; i++) {
            for (Integer j : hlr.get(i)) {
               Integer bin = (Integer) j / binSize;
               meanHapDistribution.get(i).put(bin, meanHapDistribution.get(i).get(bin) + 1);
            }
         }
      }
      //Get mean of replicates
      hapCounts = initialiseHash(hapCounts, noOfHaplotypes);
      for (Integer i = 0; i <= noOfHaplotypes; i++) {
         Map<Integer, Double> map = new TreeMap<Integer, Double>(meanHapDistribution.get(i));
         for (Map.Entry<Integer, Double> entry : map.entrySet()) {
            meanHapDistribution.get(i).put(entry.getKey(), meanHapDistribution.get(i).get(entry.getKey()) / replicateCount);
            hapCounts.put(i, hapCounts.get(i) + meanHapDistribution.get(i).get(entry.getKey()));
         }
      }

      //Remove zero value cells from end of hashMap
      for (Integer i = 0; i <= noOfHaplotypes; i++) {
         HashMap<Integer, Double> hm = meanHapDistribution.get(i);
         Integer j = hm.size() - 1;
         while (hm.get(j) == 0.0 && j > 0) {
            hm.remove(j);
            j--;
         }
      }
   }

   private HashMap<Integer, Double> getMeansOfHash(ArrayList<HashMap<Integer, Double>> hash) {
      HashMap<Integer, Double> output = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      output = initialiseHash(output, noOfHaplotypes);
      //Last item holds mean
      for (HashMap<Integer, Double> hm : hash) {
         for (Integer k = 0; k <= noOfHaplotypes; k++) {
            output.put(k, output.get(k) + hm.get(k));
         }
      }
      for (Map.Entry<Integer, Double> entry : output.entrySet()) {
         output.put(entry.getKey(), entry.getValue() / replicateCount);
      }

      return output;
   }

   private HashMap<Integer, Double> getVariance(ArrayList<HashMap<Integer, Double>> repsHash, HashMap<Integer, Double> means) {
      HashMap<Integer, Double> varianceHash = new HashMap<Integer, Double>(noOfHaplotypes + 1);
      varianceHash = initialiseHash(varianceHash, noOfHaplotypes);
      for (HashMap<Integer, Double> hm : repsHash) {
         for (Integer k = 0; k <=
               noOfHaplotypes; k++) {
            varianceHash.put(k, varianceHash.get(k) + (hm.get(k) - means.get(k)) * (hm.get(k) - means.get(k)));
         }
      }
      for (Integer k = 0; k <=
            noOfHaplotypes; k++) {
         varianceHash.put(k, Math.sqrt(varianceHash.get(k) / replicateCount) / Math.sqrt(replicateCount));
      }

      return varianceHash;
   }

    private synchronized void mergeReps() {

      chrMeanBreaks.clear();
      chrMeanBreaks = replicatesChrMeanBreaks.get(0);

      //Integer replicateCount = p.getReplicateCount();
      //sum all data points
      for (int generation = 0; generation <
            replicatesChrMeanBreaks.get(0).size(); generation++) {
         ArrayList<Double> data = new ArrayList<Double>(chrMeanBreaks.get(generation).size());
         data.addAll(chrMeanBreaks.get(generation));//add first replicate

         for (int replicate = 1; replicate < replicatesChrMeanBreaks.size(); replicate++) {
            for (int dataPoint = 1; dataPoint <
                  replicatesChrMeanBreaks.get(replicate).get(generation).size(); dataPoint++) {
               Double value = data.get(dataPoint) + replicatesChrMeanBreaks.get(replicate).get(generation).get(dataPoint);
               data.set(dataPoint, value);
            }
         }

         //divide all data points by number of replicates
         for (int dataPoint = 1; dataPoint < data.size(); dataPoint++) {
            Double value = data.get(dataPoint) / replicateCount;
            data.set(dataPoint, value);
         }
         chrMeanBreaks.set(generation, data);
      }

      chrStdDev = setChrStdDev();

      //Get mean of break counts for final generation
      Double mean = 0.0;
      Double total = 0.0;
      for (int replicate = 0; replicate <
            replicateMeanBreaks.size(); replicate++) {
         mean += replicateMeanBreaks.get(replicate).get("mean");
         total += replicateMeanBreaks.get(replicate).get("total");
      }

      mean = mean / replicateCount;
      total = total / replicateCount;
      meanBreaks.put("mean", mean);
      meanBreaks.put("total", total);

      //Get mean values of histogram of breaks
      if (replicateCount.equals(1)) {
         posArray = replicateChrPosCounts.get(0);
      }
      else {
         HashMap<Integer, Integer> hist = new HashMap<Integer, Integer>();
         for (int replicate = 0; replicate <
               replicateMeanBreaks.size(); replicate++) {
            posArray = replicateChrPosCounts.get(replicate);
            for (Map.Entry<Integer, Integer> entry : posArray.entrySet()) {
               Integer key = entry.getKey();
               Integer value = entry.getValue();
               if (hist.containsKey(key)) {
                  hist.put(key, value + hist.get(key));
               }
               else {
                  hist.put(key, value);
               }
            }
         }
         posArray.clear();
         for (Map.Entry<Integer, Integer> entry : hist.entrySet()) {
            posArray.put(entry.getKey(), entry.getValue() / replicateCount);
         }
      }
   }

   private void setPosArrayStdDev() {
      posArrayStdDev.clear();
      //get total number of chromosomes for each number of breaks
      HashMap<Integer, Double> posArrayMeans = new HashMap<Integer, Double>();
      for (int replicate = 0; replicate <
            replicateCount; replicate++) {
         HashMap<Integer, Integer> hist = replicateChrPosCounts.get(replicate);
         for (Map.Entry<Integer, Integer> entry : hist.entrySet()) {
            Integer key = entry.getKey();
            Integer value = entry.getValue();
            if (posArrayMeans.containsKey(key)) {
               posArrayMeans.put(key, posArrayMeans.get(key) + value);
            }
            else {
               posArrayMeans.put(key, value * 1.00);
            }
         }
      }

       //get mean number of chromosomes for each number of breaks
      Set<Integer> keys = posArrayMeans.keySet();
      for (Integer key : keys) {
         Double mean = posArrayMeans.get(key) / replicateCount;
         posArrayMeans.put(key, mean);
      }

      //get sum of squared differences
      for (int replicate = 0; replicate < replicateCount; replicate++) {
         HashMap<Integer, Integer> hist = replicateChrPosCounts.get(replicate);

         for (Map.Entry<Integer, Integer> entry : hist.entrySet()) {
            Integer key = entry.getKey();
            Integer value = entry.getValue();
            Double difference = (value - posArrayMeans.get(key));
            difference =
                  difference * difference;
            //SDString.append(key + "; " + posArray.get(key) + "; " + posArrayMeans.get(key) + "; " + value + "\n");
            if (posArrayStdDev.containsKey(key)) {
               posArrayStdDev.put(key, posArrayStdDev.get(key) + difference);
            }
            else {
               posArrayStdDev.put(key, difference);
            }

         }

      }

      // divide sum of squared differences by replicateCount and squareroot
      keys = posArrayStdDev.keySet();
      for (Integer key : keys) {
         Double stdDev = Math.sqrt(posArrayStdDev.get(key) / replicateCount);
         posArrayStdDev.put(key, stdDev);
      }

   }

   private ArrayList<ArrayList<Double>> setChrStdDev() {
      ArrayList<ArrayList<Double>> out = new ArrayList<ArrayList<Double>>(replicatesChrMeanBreaks.get(0).size());
      // Integer replicateCount = p.getReplicateCount();
      //sum all data points
      for (int generation = 0; generation < replicatesChrMeanBreaks.get(0).size(); generation++) {
         ArrayList<Double> data = new ArrayList<Double>(replicatesChrMeanBreaks.get(0).get(generation).size());
         data.add(0, replicatesChrMeanBreaks.get(0).get(generation).get(0));//add generation number
         Double sumOfDifferences = 0.0;
         //start at one because generation is zero
         for (int dataPoint = 1; dataPoint < replicatesChrMeanBreaks.get(0).get(generation).size(); dataPoint++) {
            sumOfDifferences = 0.0;
            Double mean = chrMeanBreaks.get(generation).get(dataPoint);
            for (int replicate = 0; replicate < replicateCount; replicate++) {
               Double value = replicatesChrMeanBreaks.get(replicate).get(generation).get(dataPoint);
               sumOfDifferences += (value - mean) * (value - mean);
            }
            Double stdev = Math.sqrt(sumOfDifferences / replicateCount);
            data.add(dataPoint, stdev);
         }
         out.add(generation, data);
      }
      return out;
   }

   public synchronized void updateChrMeanBreaks(Integer gen, HashMap<String, Double> breaks) {
      String setName = "chrMeanBreaks";
      ArrayList breaksTime = new ArrayList<Double>(3);
      breaksTime.add(0, Double.parseDouble(gen.toString()));
      breaksTime.add(1, breaks.get("meanBreaks"));
      breaksTime.add(2, breaks.get("varBreaks"));
      breaksTime.add(3, breaks.get("meanHapLength"));

      chrMeanBreaks.add(breaksTime);
      dataStructures.put(setName, chrMeanBreaks);
   }

//posArray is <Number of breaks, Number of chromosomes with that number of breaks>
   public synchronized void addPosCounts(HashMap<Integer, Integer> posArray) {
      String setName = "posCounts";
      chrPosCounts.set(0, posArray);
   }

//Get the most recent entry in the poscount this should be fine if is only used at 
// end of run but could cause problems if used during run
   public HashMap<Integer, Integer> getLastPosCounts() {
      if (!chrPosCounts.isEmpty()) {
         posArray = chrPosCounts.get(0);
         return posArray;
      }
      else {
         //This needs fixing
         return null;
      }
   }

   private void setBinSize() {
      if (binSize < 1) {
         Double meanHapLen = meanHapLengthGenerations.get(p.getMaxGeneration()).get(noOfHaplotypes);
         if (meanHapLen > 1000000) {
            binSize = 1000000;
         }
         else if (meanHapLen > 100000) {
            binSize = 100000;
         }
         else if (meanHapLen > 10000) {
            binSize = 10000;
         }
         else if (meanHapLen > 1000) {
            binSize = 1000;
         }
         else if (meanHapLen > 100) {
            binSize = 100;
         }
         else {
            binSize = 10;
         }
      }
   }

   public void setMeanBreaks(String generation, HashMap<String, Double> breaks) {
      meanBreaks.put("generation", Double.parseDouble(generation));
      meanBreaks.put("mean", breaks.get("meanBreaks"));
      //meanBreaks.put("stdError", stdError);
      meanBreaks.put("total", breaks.get("totalBreaks"));
   }

   public ArrayList<int[]> getDemoData() {
      return demoData;
   }

   public synchronized void setDemoData(ArrayList<int[]> demoData, int gen) {
      this.demoData = demoData;
      String flag = "DemoData" + gen;
      setChanged();
      notifyObservers(flag);
   }

   public void setHapLengthsReps(HashMap<Integer, ArrayList<Integer>> hapLens) {
      hapLengthsReps.add(hapLens);
   }

   //meanHapLens is a hash of mean haplotype length for each haplotype
   //HashMap<Integer, HashMap<Integer,Double>> First index replicate, second generation third  index haplotype number
   public synchronized void setMeanHapLengthReps(HashMap<Integer, Double> meanHapLens, Integer gen) {
      meanHapLengthReps.get(p.getCurrentReplicate()).put(gen, meanHapLens);
   }

   public synchronized void setStdHapLengthReps(HashMap<Integer, Double> stdHapLens, Integer gen) {
      stdHapLengthReps.get(p.getCurrentReplicate()).put(gen, stdHapLens);
   }

   /*  HashMap<Integer, Double> thisGenStdHapLenRep = new HashMap<Integer, Double>(noOfHaplotypes);
   //HashMap<Integer, Double> thisGenStdStdHapLenRep = new HashMap<Integer, Double>(noOfHaplotypes);

   if (meanHapLengthReps.get(gen).isEmpty()) {
   thisGenStdHapLenRep = initialiseHash(thisGenStdHapLenRep, noOfHaplotypes);
   //thisGenStdStdHapLenRep = initialiseHash(thisGenStdStdHapLenRep, noOfHaplotypes);
   }
   else {
   thisGenStdHapLenRep = meanHapLengthReps.get(gen);
   }
   Iterator it = stdHapLens.entrySet().iterator();
   while (it.hasNext()) {
   Map.Entry pairs = (Map.Entry) it.next();
   Integer stdhap = (Integer) pairs.getKey();
   thisGenStdHapLenRep.put(stdhap, thisGenStdHapLenRep.get(stdhap) + (Double) pairs.getValue());
   }
   stdHapLengthReps.put(gen, thisGenStdHapLenRep);
   // stdStdHapLengthReps.clear();
   }*/
   public synchronized int getArraySize() {
      return chrPosCounts.size();
   }

   public HashMap<String, Double> getMeanBreaks() {
      return meanBreaks;
   }

   public void setMeanHapFreqsReps(HashMap<Integer, Double> hapFreqs) {
      this.meanHapFreqsReps.add(hapFreqs);
   }

   public HashMap<Integer, Double> getMeanHapLength() {
      return meanHapLengthGenerations.get(p.getMaxGeneration());
   }

   public HashMap<Integer, Double> getStdHapLength() {
      return stdHapLengthGenerations.get(p.getMaxGeneration());
   }

   public HashMap<Integer, Double> getStdErrHapLength() {
      HashMap<Integer, Double> stdErrHapLengths = new HashMap<Integer, Double>();
      Iterator it = stdHapLengthGenerations.get(p.getMaxGeneration()).entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry pairs = (Map.Entry) it.next();
         Integer key = (Integer) pairs.getKey();
         Double val = (Double) pairs.getValue();
         stdErrHapLengths.put(key, val / Math.sqrt(replicateCount));
      }
      return stdErrHapLengths;

   }

   public HashMap<Integer, Double> getMeanHapFreqs() {
      return meanHapFreqs;
   }

   public ArrayList<ArrayList<Double>> getChrStdDev() {
      return chrStdDev;
   }

   public HashMap<Integer, Double> getStdErrHapFreqs() {
      return stdErrHapFreqs;
   }

   public HashMap<Integer, HashMap<Integer, Double>> getMeanHapDistribution() {
      return meanHapDistribution;
   }

   public HashMap<Integer, Double> getHapCounts() {
      return hapCounts;
   }

   public HashMap<Integer, Double> getPosArrayStdDev() {
      return posArrayStdDev;
   }

   public Integer getBinSize() {
      return binSize;
   }

   public ArrayList<ArrayList<Double>> getIntrogressedChros() {
      return introgressedChros;
   }

   public HashMap<Integer, HashMap<Integer, Double>> getStdHapLengthGenerations() {
      return stdHapLengthGenerations;
   }

   public HashMap<Integer, HashMap<Integer, Double>> getMeanHapLengthGenerations() {
      return meanHapLengthGenerations;
   }
}
