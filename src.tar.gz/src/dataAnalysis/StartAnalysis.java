
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package dataAnalysis;

import java.util.ArrayList;
import haplotypesimulator.Params;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author harry
 */
public class StartAnalysis extends Thread {

   // private DataAnalyser da;
   private Params p;
   private final ArrayList<int[]> posArray;
   private final ArrayList<int[]> hapArray;
   private HashMap<Integer, Integer> hapLengthCounts;//Counts of haplotype lengths in bins.
   private DataArray da;
   private ArrayList<Integer> breakCounts;//breaks for each chromosome for calculating variance
   private HashMap<Integer, Integer> chromosomeCounts;
   private HashMap<Integer, Double> meanHapBreaks;//mean breaks for each haplotype

   private HashMap<Integer, Double> meanHapLengths;//hap lengths for each haplotype
   private HashMap<Integer, Double> stdHapLengths;//std dev ofhap lengths for each haplotype
   private HashMap<Integer, Double> hapFreqs;
   private HashMap<Integer, ArrayList<Integer>> hapLengths;
   private Integer noOfHaplotypes;
   private int gen;
   private int maxGen;

   public StartAnalysis(Params params, ArrayList<int[]> pA, ArrayList<int[]> hA, HashMap<Integer, Integer> chromosomeCounts, int gen) {
      this.p = params;
      this.chromosomeCounts = chromosomeCounts;
      this.gen = gen;
      posArray = pA;
      hapArray = hA;
      da = p.getDataArray();
      maxGen = Integer.parseInt(p.getConfig().getProperty("generations"));
      hapLengths = initialiseHapLengths();
   }

   public StartAnalysis(Params params, ArrayList<int[]> pA, ArrayList<int[]> demoData, int gen) {
      this.p = params;
      posArray = pA;
      this.gen = gen;
      hapArray = null;
      da = p.getDataArray();
      da.setDemoData(demoData, gen);
      maxGen = Integer.parseInt(p.getConfig().getProperty("generations"));
      hapLengths = initialiseHapLengths();
   }

   private HashMap<Integer, ArrayList<Integer>> initialiseHapLengths() {
      noOfHaplotypes = Integer.parseInt(p.getConfig().getProperty("noOfHaplotypes"));
      meanHapLengths = new HashMap<Integer, Double>(noOfHaplotypes);
      initialiseHash(meanHapLengths);
      stdHapLengths = new HashMap<Integer, Double>(noOfHaplotypes);
      initialiseHash(stdHapLengths);
      hapFreqs = new HashMap<Integer, Double>(noOfHaplotypes);
      initialiseHash(hapFreqs);
      hapLengths = new HashMap<Integer, ArrayList<Integer>>(noOfHaplotypes);
      for (Integer i = 0; i <= noOfHaplotypes; i++) {
         hapLengths.put(i, new ArrayList<Integer>());
      }
      return hapLengths;
   }

   private void initialiseHash(HashMap<Integer, Double> hash) {
      for (Integer i = 0; i <= noOfHaplotypes; i++) {
         hash.put(i, 0.0);
      }
   }

   @Override
   public void run() {
      breakCounts = new ArrayList<Integer>();
      HashMap<String, Double> breaks = getMeanBreakpoints();

      if (chromosomeCounts != null) {
         Double variance = getVariance();
         breaks.put("varParentChromosomeCount", variance);
      }

      da.updateChrMeanBreaks(gen, breaks);
      da.setMeanBreaks(Integer.toString(gen), breaks);
      getHaplotypeLengthStdDev();
      da.setMeanHapLengthReps(meanHapLengths, gen);
      da.setStdHapLengthReps(stdHapLengths, gen);


      if (chromosomeCounts != null) {
         if (maxGen == gen) {
            da.setHapLengthsReps(hapLengths);
            hapFreqs = getHapFrequencies(hapFreqs);
            da.setMeanHapFreqsReps(hapFreqs);
         }
      }
   }

   //variance of the number of child chromsomes that each parent chromosome has contributed to
   private Double getVariance() {
      //meanParentChros the number of parent chromosomes that have contributed to each child chros.
      //Will always be 2
      Integer meanParentChros = 2;
      Integer sum = 0;

      for (Integer i = 0; i < p.getPopSize(); i++) {
         sum += (chromosomeCounts.get(i) - meanParentChros) * (chromosomeCounts.get(i) - meanParentChros);
      }
      Double variance = 1.0 * sum / p.getPopSize();

      return variance;
   }

   private HashMap<Integer, Double> getHapFrequencies(HashMap<Integer, Double> hapFreqs) {
      for (int i = 0; i <= noOfHaplotypes; i++) {
         hapFreqs.put(i, hapFreqs.get(i) / hapFreqs.get(noOfHaplotypes));
      }
      return hapFreqs;
   }

   private void getHaplotypeLengthStdDev() {

      for (int i = 0; i <= noOfHaplotypes; i++) {
         Double var = 0.0;
         Double meanLength =  meanHapLengths.get(i);
         for (Integer h : hapLengths.get(i)) {
            var += (h - meanLength) * (h - meanLength);
         }
         var = 1.0 * (var / hapLengths.get(i).size());
         stdHapLengths.put(i, Math.sqrt(var));
      }
   }

   private void printPos() {
      int size = posArray.size();
      System.out.println("Printing positions for " + size + "chromosomes");

      for (int i = 0; i < size; i++) {
         StringBuilder posString = new StringBuilder();

         int prePos = -1;
         for (int j = 0; j < posArray.get(i).length; j++) {
            int pos = posArray.get(i)[j];
            int hap = hapArray.get(i)[j];
            if (pos > prePos) {
               prePos = pos;
               posString.append(pos + ":" + hap + ", ");
            }
         }
         System.out.println("Chr " + i + "; " + posString.toString());
      }


   }

   private HashMap<String, Double> getMeanBreakpoints() {
      Integer counter = gen;
      Double mBreaks = 0.0;
      Double totalBreaks = 0.0;
      HashMap<Integer, Integer> posCounts = new HashMap<Integer, Integer>();
      int size = posArray.size();
      // if (maxGen == gen) {
      // printPos();
      for (int i = 0; i < size; i++) {

         int breaks = 0;
         int start = 0;
         for (int j = 1; j < posArray.get(i).length; j++) {
            int pos = posArray.get(i)[j];

            //There are probably trailing empty cells in array which are set to 0 and must be ignored
            // so cannot just use posArray.get(i).length
            if (pos != 0) {
               breaks++;

               Integer hapLength = pos - start;
               int hap = hapArray.get(i)[j - 1];
               //Array for each haplotype and final array for all haplotypes
               hapLengths.get(hap).add(hapLength);
               hapLengths.get(noOfHaplotypes).add(hapLength);
               meanHapLengths.put(hap, meanHapLengths.get(hap) + hapLength);
               hapFreqs.put(hap, hapFreqs.get(hap) + hapLength);
               //For sanity check to see if sum of haplotype lengths  equals chromosome length
               meanHapLengths.put(noOfHaplotypes, meanHapLengths.get(noOfHaplotypes) + hapLength);
               hapFreqs.put(noOfHaplotypes, hapFreqs.get(noOfHaplotypes) + hapLength);
               //start = pos;
               }
            start = pos;
         }
         //subtract one because end position is not true break
         breaks--;
         posCounts = setPosCounts(posCounts, breaks);
         totalBreaks += breaks;
      }
      for(int i = 0; i <= noOfHaplotypes; i++ ){
         meanHapLengths.put(i, meanHapLengths.get(i) / hapLengths.get(i).size() );
      }
      // }
  /*    else {
      // System.out.println("Updating breaks count gen:" + gen);
      for (int i = 0; i < size; i++) {

      int breaks = 0;
      int start = 0;

      for (int j = 0; j < posArray.get(i).length; j++) {
      int pos = posArray.get(i)[j];
      //There are probably trailing empty cells in array which are set to 0 and must be ignored
      // so cannot just use posArray.get(i).length
      if (pos != 0) {
      breaks++;
      }
      }
      //subtract one because end position is not true break
      breaks--;
      posCounts = setPosCounts(posCounts, breaks);
      totalBreaks += breaks;
      }
      }*/
      Double meanBreaks = (totalBreaks / posArray.size());
      Double varBreaks = getVarOfBreaks(posCounts, meanBreaks);
      if (meanBreaks.isNaN()) {
         System.err.println("meanBreaks is NaN StartAnalysis getMeanBreakpoints() " +
               "posArray Size: " + posArray.size() + "; original size: " + size);
      }
      Integer chrLength = Integer.parseInt(p.getConfig().getProperty("chrLength"));
      int factor = 1;
      if (chrLength > 1000000) {
         factor = 1000000;
      }
      else if (chrLength > 1000) {
         factor = 1000;
      }
      Double meanHapLength = chrLength / ((meanBreaks + 1.0) * factor);

      da.addPosCounts(posCounts);
      HashMap<String, Double> breaksHash = new HashMap<String, Double>(3);

      breaksHash.put("meanBreaks", meanBreaks);
      breaksHash.put("totalBreaks", totalBreaks);
      breaksHash.put("meanHapLength", meanHapLength);
      breaksHash.put("varBreaks", varBreaks);
      //clean up to avoid memory leaks
      posArray.clear();
      //System.err.println("\tgetBreaks\t" + gen + "\t" + totalBreaks + "\t" + meanBreaks + "\t" + size);
      return breaksHash;

   }

   private HashMap<Integer, Integer> setPosCounts(HashMap<Integer, Integer> posCounts, Integer breaks) {
      if (posCounts.containsKey((Integer) breaks)) {
         posCounts.put(breaks, posCounts.get(breaks) + 1);
      }
      else {
         posCounts.put(breaks, 1);
      }

      breakCounts.add(breaks);

      return posCounts;
   }

   private Double getVarOfBreaks(HashMap<Integer, Integer> posCounts, Double meanBreaks) {
      Double varBreaks = 0.0;
      Integer breaksTotal = 0;
      Iterator it = posCounts.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry pairs = (Map.Entry) it.next();
         Integer breaks = (Integer) pairs.getKey();
         Integer breaksCount = (Integer) pairs.getValue();
         breaksTotal += breaksCount;
         varBreaks += breaksCount * (breaks - meanBreaks) * (breaks - meanBreaks);
         //System.err.println("\t" + gen + "\t" + breaksCount + "\t" + breaks);
      }
      varBreaks = varBreaks / breaksTotal;

      return varBreaks;
   }
}
