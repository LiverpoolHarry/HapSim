/*

Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package controller;

import guiview.MainWindow;
import guiview.Params;
import haplotypesimulator.RunSimulation;
import dataAnalysis.DataArray;
import guiview.ChromosomeDemo;
import guiview.BreaksOutputTab;
import guiview.HapDistOutputTab;
import guiview.HapLengthOutputTab;
import guiview.HapsOutputTab;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class MVController implements ActionListener {

   private final MainWindow mw;
   private RunSimulation rs;
   private DataArray da;
   private Params p;
   private String currentModelName;
   private ChromosomeDemo chrDemo;
   private int runCount = 1;

   public MVController() {


      //initialise Gui params and then gui
      p = new Params();
      mw = new MainWindow(p, this);
      // add button listeners with this controller as listener
      mw.addButtonActionListeners(this);

      //p.setMainWindow(mw);
      //Instantiate GUI for each model all classes with names
      //ending in Model.class

      p.loadViewClasses();

      //start gui
      SwingUtilities.invokeLater(new Runnable() {

         public void run() {
            mw.buildMainWindow();
         }
      });



   }

   //set up listener of start and cancel buttons in main window
   public void actionPerformed(ActionEvent ae) {
      String ac = ae.getActionCommand();
      char c = ac.charAt(0);
      switch (c) {
         case 's':
            runSimulation();
         case 'c':
            rs.cancelSimulation();
      }
   }

   //run simulation on model in response to start button in MainWindow
   private void runSimulation() {
      if (rs != null) {
         rs.disposeProgressMonitor();
      }
      currentModelName = p.getCurrentViewName();


      if (sanityChecks() == true) {

         p.setExpecteds();

         //Set up DataArray to hold output and add an observer
         Integer replicateCount = (Integer) p.getModelValues(currentModelName).get("replicateCount");
         da = new DataArray(replicateCount);
         p.setdArray(da);



         // start graphics of chromosomes
         if (currentModelName.equals("IntercrossDemo")) {
            new ChromosomeDemo(p);
            new BreaksOutputTab(p, currentModelName, mw);

         }
         //disable start button enabled again in BreaksOutputTab
         else {
            //Enable again for MainWindow
            mw.disableStartButton();
            //Initialise Output Panels
            new BreaksOutputTab(p, currentModelName, mw);
            new HapsOutputTab(p, currentModelName);
            new HapDistOutputTab(p, currentModelName);
            new HapLengthOutputTab(p, currentModelName);
            //Clear old chart plots from file menu
            p.clearJFreecharts();
         }
         //System.out.println("Starting run: " + runCount);
         runCount++;

         //initialise simulator
         rs = new RunSimulation(da, p.getModelValues(currentModelName), currentModelName);
         new Thread(rs).start();
      }

   }
   //Cancels simulation at end of current generation by
   //making the current generation final number of generations;

   private void cancelSimulation() {
      rs.cancelSimulation();
   }

   public void printTables(String filename) {
      rs.printToFile(filename);
   }

   private boolean sanityChecks() {
      boolean returnValue = true;
      Integer pop = (Integer) p.getModelValues(currentModelName).get("popSize");
      Integer hapCount = p.getInputTab().validateFreqs(currentModelName);
      Integer noHaps = (Integer) p.getModelValues(currentModelName).get("noOfHaplotypes");
      Integer selfing = (Integer) p.getModelValues(currentModelName).get("founders");
      if (!hapCount.equals(pop)) {
         returnValue = false;

         JOptionPane.showMessageDialog(mw,
               "The Counts of each founder haplotype (" + hapCount + ") \n do not match the number of chromosomes (" + pop + ")",
               "Fatal Error",
               JOptionPane.ERROR_MESSAGE);
      }
      Double expHapFreq = 1 - 1 / (noHaps * 1.0);
      //If this condition is true then there are equal numbers of each haplotype and it is legitimate to
      //prohibit selfing in F0. If there are variable frequencies of each haplotype then prohibiting selfing
      //will have the effect of equalising numbers of each haplotype which defeats the object
      if (!expHapFreq.equals(p.getMeanHapFreq()) && selfing.equals(0) && noHaps.equals(2)) {
         returnValue = false;
         System.out.println("Expected: " + expHapFreq + "; Observed: " + p.getMeanHapFreq());
         JOptionPane.showMessageDialog(mw,
               "If the number of chromsomes per haplotype are not all equal \n then selfing in the F0 must be allowed to maintain the required ratios.  ",
               "Fatal Error",
               JOptionPane.ERROR_MESSAGE);
      }
      if (currentModelName.contains("Introgression")) {
         Integer flankingMarker = (Integer) p.getModelValues(currentModelName).get("flankingMarker");
         Integer peakMarker = (Integer) p.getModelValues(currentModelName).get("peakMarker");
         Integer chrLength = (Integer) p.getModelValues(currentModelName).get("chrLength");
         if (flankingMarker + peakMarker > chrLength) {
            Integer markerSum = flankingMarker + peakMarker;
            returnValue = false;
            JOptionPane.showMessageDialog(mw,
                  "The sum of the flanking marker and the peak marker postiions " + markerSum + " exceeds the chromosome length " + chrLength + ". ",
                  "Fatal Error",
                  JOptionPane.ERROR_MESSAGE);

         }
      }


      return returnValue;
   }

   public void showErrorMessage (String message){

              JOptionPane.showMessageDialog(mw, message);

   }
}
