
/*
Copyright Harry Noyes 2011
This file is part of HaplotypeSimulator.

HaplotypeSimulator is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HaplotypeSimulator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HaplotypeSimulator.  If not, see <http://www.gnu.org/licenses/>.
 */
package controller;

import haplotypesimulator.RunSimulation;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import logging.StdOutErrLevel;
import logging.LoggingOutputStream;

public class Main {

   public static void main(String args[]) {

      //divert standard error and standard out to file
      setLogging();
      //If no arguments supplied start GUI
      //Any argument is assumed to be a config file name which will be used to instantiate
      // a command line file
      if (args.length == 0) {
         setMacMenuBar();
         new MVController();
      }
      else {
         RunSimulation rs = new RunSimulation(args[0]);
         Thread run = new Thread(rs);
         run.start();
         try {
            run.join();
         }
         catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
         }
      }
   }

   private static void setLogging() {
      // from http://blogs.oracle.com/nickstephen/entry/java_redirecting_system_out_and
      // initialize logging to go to rolling log file
      LogManager logManager = LogManager.getLogManager();
      logManager.reset();


      // log file max size 10K, 3 rolling files, append-on-open
      Handler fileHandler;
      try {
         fileHandler = new FileHandler("SimulatorLog.txt", 10000, 1, false);
         fileHandler.setFormatter(new SimpleFormatter());
         Logger.getLogger("").addHandler(fileHandler);

      }
      catch (IOException ex) {
         Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
      }
      catch (SecurityException ex) {
         Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
      }

      // preserve old stdout/stderr streams in case they might be useful
      PrintStream stdout = System.out;
      PrintStream stderr = System.err;
      

      // now rebind stdout/stderr to logger
      Logger logger;
      LoggingOutputStream los;

      /*logger = Logger.getLogger("stdout");
      los = new LoggingOutputStream(logger, StdOutErrLevel.STDOUT);
      System.setOut(new PrintStream(los, true));
      */
      logger = Logger.getLogger("stderr");
      los = new LoggingOutputStream(logger, StdOutErrLevel.STDERR);
      System.setErr(new PrintStream(los, true));

   }

   //For the benefit of mac users sets the menu bar name to the same as the window name
   private static void setMacMenuBar() {
      //code from http://stackoverflow.com/questions/307024/native-swing-menu-bar-support-for-macos-x-in-java
      //All mac os have an mrj version
      if (System.getProperty("mrj.version") != null) {
         try {
            System.setProperty("apple.laf.useScreenMenuBar", "true");
            System.setProperty("com.apple.mrj.application.apple.menu.about.name", "HaplotypeSimulator");
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
         }
         catch (ClassNotFoundException e) {
            System.err.println("ClassNotFoundException: " + e.getMessage());
         }
         catch (InstantiationException e) {
            System.err.println("InstantiationException: " + e.getMessage());
         }
         catch (IllegalAccessException e) {
            System.err.println("IllegalAccessException: " + e.getMessage());
         }
         catch (UnsupportedLookAndFeelException e) {
            System.err.println("UnsupportedLookAndFeelException: " + e.getMessage());
         }

       
      }
   }
}
